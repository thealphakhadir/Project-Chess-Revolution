package sagacious.analysis.api;

import sagacious.analysis.eval.FakePosition;
import sagacious.analysis.model.*;
import sagacious.analysis.search.*;
import sagacious.analysis.shared.AnalysisWorkerPool;
import sagacious.analysis.shared.BackupWorker;

import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

/**
 * MockSearchEngine implements all 6 methods, which doesn't match reality —
 * right now, per Part 2, requestBackupAnalysis (and everything else)
 * genuinely throws NotImplementedException. This test uses an engine that
 * implements only what reviewFullGame's fast pass + classification needs,
 * leaving requestBackupAnalysis as the real default stub, to check that a
 * *currently realistic* run doesn't silently lose deep-dive results.
 */
public class BackupStubRealismTest {
    static int pass = 0, fail = 0;

    static void check(String name, boolean cond) {
        if (cond) { pass++; System.out.println("PASS: " + name); }
        else { fail++; System.out.println("FAIL: " + name); }
    }

    static class EngineWithRealBackupStub implements SearchEngine {
        private static final Move DUMMY_MOVE = Move.of(new Square(4, 2), new Square(4, 4), PieceType.PAWN, false);

        @Override
        public RawSearchResult searchWithVerification(Position position, int depth, int alpha, int beta,
                                                        boolean isRoot, InterruptCheck checkInterrupt) {
            int cp = position.plyCount() == 3 ? 400 : 0; // one deliberate spike -> one critical moment
            return new RawSearchResult(DUMMY_MOVE, cp, false, null, List.of(), depth);
        }

        @Override
        public SearchResult enrichSearchResult(Position position, RawSearchResult rawResult, SearchConfig config, List<Ply> gameHistory) {
            return new SearchResult(rawResult, List.of(), List.of(),
                    new Explanation("x", List.of(), java.util.Map.of()), "commentary", null, 0.5);
        }

        @Override
        public Classification classifyMove(Position position, Move moveMade, int evalBefore, int evalAfter, GamePhase gamePhase) {
            return new Classification(Severity.GOOD, "fine", 0);
        }

        @Override
        public int getEvalAfterMove(Position position, Move move) {
            return 0;
        }
        // requestBackupAnalysis deliberately NOT overridden -> real NotImplementedException stub
    }

    /** A second variant: classifyMove/getEvalAfterMove ALSO left as real stubs, to check that path too. */
    static class EngineWithNoClassificationEither extends EngineWithRealBackupStub {
        @Override
        public Classification classifyMove(Position position, Move moveMade, int evalBefore, int evalAfter, GamePhase gamePhase) {
            throw new NotImplementedException("classifyMove — intentionally left as the real stub for this test");
        }

        @Override
        public int getEvalAfterMove(Position position, Move move) {
            throw new NotImplementedException("getEvalAfterMove — intentionally left as the real stub for this test");
        }
    }

    public static void main(String[] args) throws Exception {
        EngineWithRealBackupStub engine = new EngineWithRealBackupStub();
        AnalysisWorkerPool pool = new AnalysisWorkerPool(engine, 4);
        BackupWorker backupWorker = new BackupWorker(engine);
        ConstructiveAnalysis api = new ConstructiveAnalysis(engine, pool, backupWorker);

        MockGame game = new MockGame(6);
        AtomicReference<GameReviewResult> finalResult = new AtomicReference<>();
        CountDownLatch done = new CountDownLatch(1);

        AnalysisInput input = new AnalysisInput.FullGame(game, 1500);
        AnalysisCallbacks callbacks = new AnalysisCallbacks(null, null,
                result -> { finalResult.set((GameReviewResult) result); done.countDown(); });

        api.constructiveAnalysis(input, callbacks);
        check("game review completes even though backup engine is unimplemented", done.await(10, TimeUnit.SECONDS));

        GameReviewResult result = finalResult.get();
        check("result is non-null", result != null);
        if (result != null) {
            check("critical moment(s) were found", !result.criticalMoments().isEmpty());
            check("at least one deep dive was attempted", !result.deepDivesByPly().isEmpty());
            // THE KEY CHECK: does the primary engine's already-successful deep
            // search result survive, even though the backup corroboration
            // call fails with NotImplementedException?
            if (!result.deepDivesByPly().isEmpty()) {
                int firstKey = result.deepDivesByPly().keySet().iterator().next();
                check("deep dive result is present (not silently dropped) despite backup stub throwing",
                        result.deepDivesByPly().get(firstKey) != null);
                check("deep dive result is enriched (went through enrichSearchResult)",
                        result.deepDivesByPly().get(firstKey).explanation() != null);
            }
        }

        pool.close();
        backupWorker.close();

        // ---- Second case: classifyMove/getEvalAfterMove ALSO real stubs ----
        {
            EngineWithNoClassificationEither engine2 = new EngineWithNoClassificationEither();
            AnalysisWorkerPool pool2 = new AnalysisWorkerPool(engine2, 4);
            BackupWorker backupWorker2 = new BackupWorker(engine2);
            ConstructiveAnalysis api2 = new ConstructiveAnalysis(engine2, pool2, backupWorker2);

            MockGame game2 = new MockGame(4);
            AtomicReference<GameReviewResult> finalResult2 = new AtomicReference<>();
            CountDownLatch done2 = new CountDownLatch(1);
            AnalysisInput input2 = new AnalysisInput.FullGame(game2, 1500);
            AnalysisCallbacks callbacks2 = new AnalysisCallbacks(null, null,
                    reviewResult -> { finalResult2.set((GameReviewResult) reviewResult); done2.countDown(); });

            api2.constructiveAnalysis(input2, callbacks2);
            check("review completes even when classifyMove/getEvalAfterMove are also unimplemented",
                    done2.await(10, TimeUnit.SECONDS));
            check("perMoveReviews still populated despite classification stub throwing",
                    finalResult2.get() != null && finalResult2.get().perMoveReviews().size() == 4);
            check("classification is null (not a crash) when the stub isn't supplied",
                    finalResult2.get().perMoveReviews().get(0).classification() == null);

            pool2.close();
            backupWorker2.close();
        }

        System.out.println("\n" + pass + " passed, " + fail + " failed");
        if (fail > 0) System.exit(1);
    }
}
