package sagacious.analysis.api;

import sagacious.analysis.model.*;
import sagacious.analysis.search.*;

import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Deterministic, fast, synthetic SearchEngine used only to functionally
 * exercise the worker pool / Part 7 plumbing end-to-end. NOT part of the
 * Module 3 deliverable — the real implementation is Parts 1-6 of the
 * design doc's "search internals" contract.
 */
public class MockSearchEngine implements SearchEngine {
    public final AtomicInteger searchCalls = new AtomicInteger();
    public final AtomicInteger enrichCalls = new AtomicInteger();
    public final AtomicInteger backupCalls = new AtomicInteger();

    private static final Move DUMMY_MOVE = Move.of(new Square(4, 2), new Square(4, 4), PieceType.PAWN, false);

    /** Centipawn eval as a function of the position's ply count — deterministic and swingy enough to exercise critical-moment detection. */
    private int syntheticEvalFor(Position position) {
        int ply = position.plyCount();
        // A few deliberate big swings so identifyCriticalMoments has something to find.
        if (ply == 5) return 350;   // a spike
        if (ply == 6) return -20;   // and a crash right after -> big swing at ply 6
        return 10 * ply;
    }

    @Override
    public RawSearchResult searchWithVerification(Position position, int depth, int alpha, int beta,
                                                    boolean isRoot, InterruptCheck checkInterrupt) {
        searchCalls.incrementAndGet();
        int cp = syntheticEvalFor(position);
        return new RawSearchResult(DUMMY_MOVE, cp, false, null, List.of(new MultiPvLine(DUMMY_MOVE, cp)), depth);
    }

    @Override
    public SearchResult enrichSearchResult(Position position, RawSearchResult rawResult, SearchConfig config, List<Ply> gameHistory) {
        enrichCalls.incrementAndGet();
        Explanation explanation = new Explanation("synthetic summary", List.of("center-control"), java.util.Map.of("material", 0));
        return new SearchResult(rawResult, List.of(new AnnotatedMove(DUMMY_MOVE, "test", true)),
                List.of(), explanation, "synthetic commentary", null, 0.9);
    }

    @Override
    public Classification classifyMove(Position position, Move moveMade, int evalBefore, int evalAfter, GamePhase gamePhase) {
        int swing = evalBefore - evalAfter;
        if (swing >= 200) return new Classification(Severity.BLUNDER, "synthetic: big drop", swing);
        if (swing >= 80) return new Classification(Severity.MISTAKE, "synthetic: notable drop", swing);
        return new Classification(Severity.GOOD, "synthetic: fine", swing);
    }

    @Override
    public int getEvalAfterMove(Position position, Move move) {
        if (position.plyCount() == 10) return -150; // a real blunder the played move made, invisible to the engine-best-move timeline
        return syntheticEvalFor(position) - 5; // otherwise pretend the move played is always slightly worse than engine-best
    }

    @Override
    public SearchResult requestBackupAnalysis(String fen, SearchConfig config) {
        backupCalls.incrementAndGet();
        return new SearchResult(new RawSearchResult(DUMMY_MOVE, 0, false, null, List.of(), config.maxDepth()),
                List.of(), List.of(), null, "backup synthetic", null, 0.5);
    }
}
