package sagacious.analysis.api;

import sagacious.analysis.eval.FakePosition;
import sagacious.analysis.model.*;

import java.util.ArrayList;
import java.util.List;

public class MockGame implements Game {
    private final List<Ply> plies = new ArrayList<>();
    private static final String STARTPOS = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR";

    public MockGame(int numPlies) {
        for (int i = 1; i <= numPlies; i++) {
            Move move = Move.of(new Square(4, 2), new Square(4, 4), PieceType.PAWN, false);
            plies.add(new Ply(move, i));
        }
    }

    @Override
    public List<Ply> moves() {
        return plies;
    }

    @Override
    public Position getPositionBefore(Ply ply) {
        Color turn = (ply.moveNumber() % 2 == 1) ? Color.WHITE : Color.BLACK;
        return new FakePosition(STARTPOS, turn, ply.moveNumber());
    }

    @Override
    public List<Ply> movesUpTo(Ply ply) {
        List<Ply> result = new ArrayList<>();
        for (Ply p : plies) {
            if (p.moveNumber() >= ply.moveNumber()) break;
            result.add(p);
        }
        return result;
    }
}
