package sagacious.analysis.api;

import sagacious.analysis.config.RequestedTier;
import sagacious.analysis.eval.FakePosition;
import sagacious.analysis.model.Color;
import sagacious.analysis.search.Severity;
import sagacious.analysis.shared.AnalysisWorkerPool;
import sagacious.analysis.shared.BackupWorker;

import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;

public class ConstructiveAnalysisTest {
    static int pass = 0, fail = 0;

    static void check(String name, boolean cond) {
        if (cond) { pass++; System.out.println("PASS: " + name); }
        else { fail++; System.out.println("FAIL: " + name); }
    }

    public static void main(String[] args) throws Exception {
        MockSearchEngine engine = new MockSearchEngine();
        AnalysisWorkerPool pool = new AnalysisWorkerPool(engine, 4);
        BackupWorker backupWorker = new BackupWorker(engine);
        ConstructiveAnalysis api = new ConstructiveAnalysis(engine, pool, backupWorker);

        // ---- 1. SINGLE_POSITION: streams per-depth reports, completes with an enriched final report ----
        {
            FakePosition pos = new FakePosition("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR", Color.WHITE, 0);
            AtomicInteger streamCount = new AtomicInteger();
            AtomicReference<Report> finalReport = new AtomicReference<>();
            CountDownLatch done = new CountDownLatch(1);

            AnalysisInput input = new AnalysisInput.SinglePosition(pos, RequestedTier.FAST, null, null, null, null);
            AnalysisCallbacks callbacks = new AnalysisCallbacks(
                    report -> streamCount.incrementAndGet(),
                    null,
                    result -> { finalReport.set((Report) result); done.countDown(); }
            );

            api.constructiveAnalysis(input, callbacks);
            check("single-position analysis completes within 5s", done.await(5, TimeUnit.SECONDS));
            check("received at least one stream update", streamCount.get() > 0);
            check("stream updates == FAST tier maxDepth (10)", streamCount.get() == 10);
            check("final report is enriched", finalReport.get() != null && finalReport.get().isEnriched());
            check("final report has a best move", finalReport.get().bestMove() != null);
            check("final report has an eval bar", finalReport.get().evalBar() != null);
            check("final report has king safety bars", finalReport.get().kingSafetyBars() != null);
            check("uiSlot defaulted correctly", input instanceof AnalysisInput.SinglePosition p && p.uiSlot().equals("default-analysis-slot"));
        }

        // ---- 2. FULL_GAME: fast pass runs, critical moments found, deep dives happen only on flagged plies ----
        {
            MockGame game = new MockGame(15);
            AtomicInteger progressiveCount = new AtomicInteger();
            AtomicReference<GameReviewResult> finalResult = new AtomicReference<>();
            CountDownLatch done = new CountDownLatch(1);

            AnalysisInput input = new AnalysisInput.FullGame(game, 1500);
            AnalysisCallbacks callbacks = new AnalysisCallbacks(
                    null,
                    lightReport -> progressiveCount.incrementAndGet(),
                    result -> { finalResult.set((GameReviewResult) result); done.countDown(); }
            );

            int searchCallsBefore = engine.searchCalls.get();
            api.constructiveAnalysis(input, callbacks);
            check("full-game review completes within 10s", done.await(10, TimeUnit.SECONDS));
            check("progressive update fired once per ply (15)", progressiveCount.get() == 15);
            check("perMoveReviews has one entry per ply", finalResult.get().perMoveReviews().size() == 15);

            // Ply 6 has a big eval-timeline swing built into the mock engine (350 -> -20) -> should be a critical moment.
            boolean ply6Flagged = finalResult.get().criticalMoments().stream().anyMatch(m -> m.ply() == 5); // 0-indexed timeline position for ply 6
            check("eval-swing critical moment detected around ply 6", ply6Flagged);

            // Ply 10 has a blunder injected via getEvalAfterMove that's invisible to the eval timeline -> must still be deep-dived.
            Severity ply10Severity = finalResult.get().perMoveReviews().get(9).classification().severity();
            check("ply 10 classified as BLUNDER", ply10Severity == Severity.BLUNDER);
            check("ply 10 (blunder-only, not swing-flagged) still got a deep dive", finalResult.get().deepDivesByPly().containsKey(9));

            // Deep dives should be enriched (went through enrichSearchResult, not the fast skipEnrichment path).
            check("deep dive results are enriched",
                    finalResult.get().deepDivesByPly().values().stream().allMatch(sr -> sr.explanation() != null));

            check("backup worker was consulted at least once for corroboration", engine.backupCalls.get() > 0);
            check("deep dives are far fewer than total plies (not every move deep-dived)",
                    finalResult.get().deepDivesByPly().size() < 15);

            System.out.println("  (searchCalls during this phase: " + (engine.searchCalls.get() - searchCallsBefore) + ")");
        }

        // ---- 3. Cancellation: a session can be cancelled and the worker honors it ----
        {
            FakePosition pos = new FakePosition("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR", Color.WHITE, 0);
            SearchConfigSlowEngineHolder.install(); // no-op marker, kept simple: just check cancel() doesn't throw and future eventually completes/cancels cleanly
            AnalysisInput input = new AnalysisInput.SinglePosition(pos, RequestedTier.DEEP, null, null, null, null);
            AnalysisCallbacks callbacks = new AnalysisCallbacks(null, null, null);
            Cancellable handle = api.constructiveAnalysis(input, callbacks);
            handle.cancel();
            check("cancel() does not throw", true);
        }

        pool.close();
        backupWorker.close();

        System.out.println("\n" + pass + " passed, " + fail + " failed");
        if (fail > 0) System.exit(1);
    }

    /** Placeholder to keep test 3 self-contained without adding a slow mock engine variant. */
    static class SearchConfigSlowEngineHolder {
        static void install() {}
    }
}
