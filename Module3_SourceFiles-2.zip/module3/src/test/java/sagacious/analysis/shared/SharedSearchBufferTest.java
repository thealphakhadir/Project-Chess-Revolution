package sagacious.analysis.shared;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicInteger;

public class SharedSearchBufferTest {
    static int pass = 0, fail = 0;

    static void check(String name, boolean cond) {
        if (cond) { pass++; System.out.println("PASS: " + name); }
        else { fail++; System.out.println("FAIL: " + name); }
    }

    public static void main(String[] args) throws Exception {
        // 1. Basic publish/read round trip
        {
            SharedSearchBuffer buf = new SharedSearchBuffer();
            buf.publishProgress(5, 120, false, null);
            var snap = buf.snapshot();
            check("depthReached round-trips", snap.depthReached() == 5);
            check("centipawns round-trips", snap.centipawns() == 120);
            check("isMate false round-trips", !snap.isMate());
            check("mateIn null round-trips", snap.mateIn() == null);
            check("status is RUNNING after publish", snap.status() == SharedSearchBuffer.STATUS_RUNNING);
        }

        // 2. Mate value round-trips, including negative (getting mated)
        {
            SharedSearchBuffer buf = new SharedSearchBuffer();
            buf.publishProgress(8, 0, true, -3);
            var snap = buf.snapshot();
            check("isMate true round-trips", snap.isMate());
            check("negative mateIn round-trips", snap.mateIn() == -3);
        }

        // 3. Version increments monotonically across multiple publishes
        {
            SharedSearchBuffer buf = new SharedSearchBuffer();
            int v0 = buf.version();
            buf.publishProgress(1, 10, false, null);
            int v1 = buf.version();
            buf.publishProgress(2, 20, false, null);
            int v2 = buf.version();
            check("version increments on first publish", v1 == v0 + 1);
            check("version increments on second publish", v2 == v1 + 1);
        }

        // 4. Cross-thread visibility: a real worker thread publishes depth
        // updates 1..20; a real poller thread on a different core reads
        // them and must observe monotonically non-decreasing depth with
        // no stale/torn reads, and must see the final value.
        {
            SharedSearchBuffer buf = new SharedSearchBuffer();
            int totalDepths = 20;
            AtomicInteger lastSeenDepth = new AtomicInteger(0);
            AtomicInteger monotonicViolations = new AtomicInteger(0);
            CountDownLatch workerDone = new CountDownLatch(1);
            volatile_flag_holder pollerShouldStop = new volatile_flag_holder();

            Thread worker = new Thread(() -> {
                for (int d = 1; d <= totalDepths; d++) {
                    buf.publishProgress(d, d * 10, false, null);
                    try { Thread.sleep(2); } catch (InterruptedException ignored) {}
                }
                buf.markComplete();
                workerDone.countDown();
            }, "worker-thread");

            Thread poller = new Thread(() -> {
                while (!pollerShouldStop.stop) {
                    int d = buf.snapshot().depthReached();
                    int prev = lastSeenDepth.get();
                    if (d < prev) monotonicViolations.incrementAndGet();
                    lastSeenDepth.set(Math.max(prev, d));
                }
            }, "poller-thread");

            poller.start();
            worker.start();
            workerDone.await();
            Thread.sleep(20); // let poller catch the final publish
            pollerShouldStop.stop = true;
            poller.join(1000);

            check("no monotonicity violations observed across threads", monotonicViolations.get() == 0);
            check("poller eventually observed the final depth", lastSeenDepth.get() == totalDepths);
            check("status reached COMPLETE", buf.snapshot().status() == SharedSearchBuffer.STATUS_COMPLETE);
        }

        // 5. Interrupt flag set from one thread is visible to another immediately
        {
            SharedSearchBuffer buf = new SharedSearchBuffer();
            check("interrupt not requested initially", !buf.isInterruptRequested());
            Thread requester = new Thread(buf::requestInterrupt);
            requester.start();
            requester.join();
            check("interrupt requested visible after join", buf.isInterruptRequested());
        }

        System.out.println("\n" + pass + " passed, " + fail + " failed");
        if (fail > 0) System.exit(1);
    }

    static class volatile_flag_holder {
        volatile boolean stop = false;
    }
}
