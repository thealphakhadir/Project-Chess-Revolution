package sagacious.analysis.eval;

import sagacious.analysis.model.Move;
import sagacious.analysis.search.RawSearchResult;
import java.util.List;

public class EvalBarModuleTest {
    static int pass = 0, fail = 0;

    static void check(String name, boolean cond) {
        if (cond) { pass++; System.out.println("PASS: " + name); }
        else { fail++; System.out.println("FAIL: " + name); }
    }

    static void checkClose(String name, double actual, double expected, double tol) {
        check(name + " (actual=" + actual + ", expected=" + expected + ")", Math.abs(actual - expected) <= tol);
    }

    static RawSearchResult raw(int cp, boolean isMate, Integer mateIn, int depth) {
        return new RawSearchResult(null, cp, isMate, mateIn, List.of(), depth);
    }

    public static void main(String[] args) {
        // cp = 0 -> exactly 50/50, label "0.00" with no sign
        {
            EvalBar bar = EvalBarModule.generateEvalBar(raw(0, false, null, 15));
            checkClose("cp=0 whiteFillPercent", bar.whiteFillPercent(), 50.0, 1e-9);
            check("cp=0 label has no sign", bar.label().equals("0.00"));
            check("cp=0 not provisional at depth 15", !bar.provisional());
        }

        // cp = 100 -> hand-computed via logistic formula
        {
            double cp = 100;
            double winChance = 2.0 / (1.0 + Math.exp(-0.00368208 * cp)) - 1.0;
            double expectedFill = ((winChance + 1.0) / 2.0) * 100.0;
            EvalBar bar = EvalBarModule.generateEvalBar(raw(100, false, null, 15));
            checkClose("cp=100 whiteFillPercent matches hand calc", bar.whiteFillPercent(), expectedFill, 1e-9);
            check("cp=100 label is +1.00", bar.label().equals("+1.00"));
        }

        // cp = -100 -> symmetric around 50
        {
            EvalBar barPos = EvalBarModule.generateEvalBar(raw(100, false, null, 15));
            EvalBar barNeg = EvalBarModule.generateEvalBar(raw(-100, false, null, 15));
            checkClose("cp=-100 is mirror of cp=100 around 50", barNeg.whiteFillPercent(), 100 - barPos.whiteFillPercent(), 1e-9);
            check("cp=-100 label is -1.00", barNeg.label().equals("-1.00"));
        }

        // provisional flag
        {
            EvalBar shallow = EvalBarModule.generateEvalBar(raw(50, false, null, 5));
            EvalBar deep = EvalBarModule.generateEvalBar(raw(50, false, null, 20));
            check("depth 5 < threshold(12) -> provisional", shallow.provisional());
            check("depth 20 >= threshold(12) -> not provisional", !deep.provisional());
        }

        // mate handling
        {
            EvalBar whiteMates = EvalBarModule.generateEvalBar(raw(0, true, 3, 20));
            check("mateIn=+3 -> fillPercent 100", whiteMates.whiteFillPercent() == 100.0);
            check("mateIn=+3 -> label M3", whiteMates.label().equals("M3"));
            check("mate result -> numericValue null", whiteMates.numericValue() == null);

            EvalBar blackMates = EvalBarModule.generateEvalBar(raw(0, true, -2, 20));
            check("mateIn=-2 -> fillPercent 0", blackMates.whiteFillPercent() == 0.0);
            check("mateIn=-2 -> label M2 (abs value)", blackMates.label().equals("M2"));
        }

        // formatEvalLabel edge cases
        {
            check("formatEvalLabel(0) == \"0.00\"", EvalBarModule.formatEvalLabel(0).equals("0.00"));
            check("formatEvalLabel(-5) == \"-0.05\"", EvalBarModule.formatEvalLabel(-5).equals("-0.05"));
            check("formatEvalLabel(950) == \"+9.50\"", EvalBarModule.formatEvalLabel(950).equals("+9.50"));
        }

        // smoothBarTransition: at depth == CONFIDENCE_DEPTH_THRESHOLD, blendWeight=1 -> fully the new value
        {
            EvalBar prev = EvalBarModule.generateEvalBar(raw(0, false, null, 1));
            EvalBar next = EvalBarModule.generateEvalBar(raw(200, false, null, 12));
            EvalBar smoothed = EvalBarModule.smoothBarTransition(prev, next, 12);
            checkClose("blend at depth==threshold equals new bar fully", smoothed.whiteFillPercent(), next.whiteFillPercent(), 1e-9);
        }
        // at depth 0, blendWeight clamps to 0 -> fully the previous value
        {
            EvalBar prev = EvalBarModule.generateEvalBar(raw(0, false, null, 1));
            EvalBar next = EvalBarModule.generateEvalBar(raw(200, false, null, 1));
            EvalBar smoothed = EvalBarModule.smoothBarTransition(prev, next, 0);
            checkClose("blend at depth==0 equals previous bar fully", smoothed.whiteFillPercent(), prev.whiteFillPercent(), 1e-9);
        }

        System.out.println("\n" + pass + " passed, " + fail + " failed");
        if (fail > 0) System.exit(1);
    }
}
