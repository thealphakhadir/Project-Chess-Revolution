package sagacious.analysis.eval;

import sagacious.analysis.model.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Minimal Position implementation for functional testing only. Built from
 * FEN-style piece placement (just the first field) so test boards are easy
 * to write and hand-verify. This is NOT part of the Module 3 deliverable —
 * it stands in for Stub 1 (parseFen / the real board representation) so
 * Parts 3-7's pure logic can be exercised against real positions.
 */
public class FakePosition implements Position {
    private final PieceOnBoard[][] board = new PieceOnBoard[8][9]; // [file][rank], rank 1..8 used
    private final Color turn;
    private final int plyCount;

    public FakePosition(String placement, Color turn, int plyCount) {
        this.turn = turn;
        this.plyCount = plyCount;
        String[] rows = placement.split("/");
        for (int r = 0; r < 8; r++) {
            int rank = 8 - r;
            int file = 0;
            for (char ch : rows[r].toCharArray()) {
                if (Character.isDigit(ch)) {
                    file += (ch - '0');
                } else {
                    Color color = Character.isUpperCase(ch) ? Color.WHITE : Color.BLACK;
                    PieceType type = pieceTypeFor(Character.toUpperCase(ch));
                    board[file][rank] = new PieceOnBoard(type, color);
                    file++;
                }
            }
        }
    }

    private static PieceType pieceTypeFor(char c) {
        return switch (c) {
            case 'P' -> PieceType.PAWN;
            case 'N' -> PieceType.KNIGHT;
            case 'B' -> PieceType.BISHOP;
            case 'R' -> PieceType.ROOK;
            case 'Q' -> PieceType.QUEEN;
            case 'K' -> PieceType.KING;
            default -> throw new IllegalArgumentException("bad piece char " + c);
        };
    }

    @Override public String fen() { return "test-position"; }
    @Override public Color turnToMove() { return turn; }
    @Override public int plyCount() { return plyCount; }

    @Override
    public PieceOnBoard pieceAt(Square square) {
        if (!BoardMath.isValidSquare(square)) return null;
        return board[square.file()][square.rank()];
    }

    @Override
    public List<PlacedPiece> allPieces() {
        List<PlacedPiece> result = new ArrayList<>();
        for (int f = 0; f < 8; f++) {
            for (int r = 1; r <= 8; r++) {
                PieceOnBoard p = board[f][r];
                if (p != null) result.add(new PlacedPiece(p.type(), p.color(), new Square(f, r)));
            }
        }
        return result;
    }

    @Override
    public List<PieceAtSquare> piecesOf(Color color) {
        List<PieceAtSquare> result = new ArrayList<>();
        for (int f = 0; f < 8; f++) {
            for (int r = 1; r <= 8; r++) {
                PieceOnBoard p = board[f][r];
                if (p != null && p.color() == color) result.add(new PieceAtSquare(p.type(), new Square(f, r)));
            }
        }
        return result;
    }

    @Override
    public Square kingSquare(Color color) {
        for (int f = 0; f < 8; f++) {
            for (int r = 1; r <= 8; r++) {
                PieceOnBoard p = board[f][r];
                if (p != null && p.type() == PieceType.KING && p.color() == color) return new Square(f, r);
            }
        }
        throw new IllegalStateException("no king of color " + color + " on test board");
    }

    /** Simplified attack detection sufficient for the king-safety test cases (no pins/discoveries needed here). */
    @Override
    public boolean isSquareAttackedBy(Square square, Color byColor) {
        return !attackersOf(square, byColor).isEmpty();
    }

    @Override
    public List<PieceAtSquare> attackersOf(Square square, Color byColor) {
        List<PieceAtSquare> attackers = new ArrayList<>();
        for (int f = 0; f < 8; f++) {
            for (int r = 1; r <= 8; r++) {
                PieceOnBoard p = board[f][r];
                if (p == null || p.color() != byColor) continue;
                Square from = new Square(f, r);
                if (attacks(p.type(), byColor, from, square)) {
                    attackers.add(new PieceAtSquare(p.type(), from));
                }
            }
        }
        return attackers;
    }

    private boolean attacks(PieceType type, Color color, Square from, Square to) {
        int df = to.file() - from.file(), dr = to.rank() - from.rank();
        switch (type) {
            case PAWN -> {
                int dir = color == Color.WHITE ? 1 : -1;
                return dr == dir && Math.abs(df) == 1;
            }
            case KNIGHT -> {
                return (Math.abs(df) == 1 && Math.abs(dr) == 2) || (Math.abs(df) == 2 && Math.abs(dr) == 1);
            }
            case KING -> {
                return Math.max(Math.abs(df), Math.abs(dr)) == 1;
            }
            case BISHOP -> {
                return Math.abs(df) == Math.abs(dr) && df != 0 && clearDiagonal(from, to);
            }
            case ROOK -> {
                return (df == 0 || dr == 0) && (df != 0 || dr != 0) && clearStraight(from, to);
            }
            case QUEEN -> {
                boolean diag = Math.abs(df) == Math.abs(dr) && df != 0;
                boolean straight = (df == 0 || dr == 0) && (df != 0 || dr != 0);
                return (diag && clearDiagonal(from, to)) || (straight && clearStraight(from, to));
            }
        }
        return false;
    }

    private boolean clearDiagonal(Square from, Square to) {
        int sf = Integer.signum(to.file() - from.file());
        int sr = Integer.signum(to.rank() - from.rank());
        int f = from.file() + sf, r = from.rank() + sr;
        while (f != to.file() || r != to.rank()) {
            if (board[f][r] != null) return false;
            f += sf; r += sr;
        }
        return true;
    }

    private boolean clearStraight(Square from, Square to) {
        int sf = Integer.signum(to.file() - from.file());
        int sr = Integer.signum(to.rank() - from.rank());
        int f = from.file() + sf, r = from.rank() + sr;
        while (f != to.file() || r != to.rank()) {
            if (board[f][r] != null) return false;
            f += sf; r += sr;
        }
        return true;
    }
}
