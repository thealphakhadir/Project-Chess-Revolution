package sagacious.analysis.eval;

import sagacious.analysis.model.Color;
import sagacious.analysis.model.GamePhase;

public class KingSafetyModuleTest {
    static int pass = 0, fail = 0;

    static void check(String name, boolean cond) {
        if (cond) { pass++; System.out.println("PASS: " + name); }
        else { fail++; System.out.println("FAIL: " + name); }
    }

    static void checkClose(String name, double actual, double expected, double tol) {
        check(name + " (actual=" + actual + ", expected=" + expected + ")", Math.abs(actual - expected) <= tol);
    }

    public static void main(String[] args) {
        // Reference values computed by an independent Python port of Parts 4+5
        // (crosscheck/king_safety.py) run against the same five positions.

        {
            FakePosition pos = new FakePosition("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR", Color.WHITE, 0);
            GamePhase phase = GamePhaseModule.getGamePhase(pos);
            check("startpos phase == OPENING", phase == GamePhase.OPENING);
            checkClose("startpos white king safety", KingSafetyModule.calculateKingSafetyScore(pos, Color.WHITE, phase), 51.019047619047626, 1e-6);
            checkClose("startpos black king safety", KingSafetyModule.calculateKingSafetyScore(pos, Color.BLACK, phase), 51.019047619047626, 1e-6);
        }

        {
            FakePosition pos = new FakePosition("4k3/8/8/8/8/8/8/4K3", Color.WHITE, 40);
            GamePhase phase = GamePhaseModule.getGamePhase(pos);
            check("bare kings phase == ENDGAME", phase == GamePhase.ENDGAME);
            checkClose("bare kings white activity", KingSafetyModule.calculateKingSafetyScore(pos, Color.WHITE, phase), 25.0, 1e-6);
            checkClose("bare kings black activity", KingSafetyModule.calculateKingSafetyScore(pos, Color.BLACK, phase), 25.0, 1e-6);
        }

        {
            FakePosition pos = new FakePosition("r1bq1rk1/pppp1ppp/2n2n2/2b1p3/2B1P3/2N2N2/PPPP1PPP/R1BQ1RK1", Color.WHITE, 12);
            GamePhase phase = GamePhaseModule.getGamePhase(pos);
            check("castled position phase == MIDDLEGAME", phase == GamePhase.MIDDLEGAME);
            checkClose("castled white king safety", KingSafetyModule.calculateKingSafetyScore(pos, Color.WHITE, phase), 59.74523809523809, 1e-6);
            checkClose("castled black king safety", KingSafetyModule.calculateKingSafetyScore(pos, Color.BLACK, phase), 59.74523809523809, 1e-6);
        }

        {
            FakePosition pos = new FakePosition("rnb1kbnr/pppp1ppp/8/4p3/6Pq/5P2/PPPPP2P/RNBQKBNR", Color.WHITE, 6);
            GamePhase phase = GamePhaseModule.getGamePhase(pos);
            check("queen-near-king phase == OPENING", phase == GamePhase.OPENING);
            checkClose("queen-near-king white (exposed) is lower", KingSafetyModule.calculateKingSafetyScore(pos, Color.WHITE, phase), 37.37023809523809, 1e-6);
            checkClose("queen-near-king black is higher", KingSafetyModule.calculateKingSafetyScore(pos, Color.BLACK, phase), 46.36071428571428, 1e-6);
            check("exposed white king scores lower than black", 37.37023809523809 < 46.36071428571428);
        }

        {
            FakePosition pos = new FakePosition("8/8/4k3/8/3K4/8/8/8", Color.WHITE, 80);
            GamePhase phase = GamePhaseModule.getGamePhase(pos);
            check("king activity phase == ENDGAME", phase == GamePhase.ENDGAME);
            checkClose("more central white king scores higher", KingSafetyModule.calculateKingSafetyScore(pos, Color.WHITE, phase), 81.42857142857142, 1e-6);
            checkClose("less central black king scores lower", KingSafetyModule.calculateKingSafetyScore(pos, Color.BLACK, phase), 64.28571428571428, 1e-6);
        }

        // Directional sanity checks (robust even without exact reference values)
        {
            // Removing the pawn shield in front of a castled king should lower its
            // score — needs enough non-pawn material to stay out of ENDGAME phase,
            // since ENDGAME scores king activity/mobility instead of shelter.
            FakePosition shielded = new FakePosition("r1bq1rk1/5ppp/8/8/8/8/5PPP/R1BQ1RK1", Color.WHITE, 20);
            FakePosition exposed = new FakePosition("r1bq1rk1/8/8/8/8/8/5PPP/R1BQ1RK1", Color.WHITE, 20);
            GamePhase phaseS = GamePhaseModule.getGamePhase(shielded);
            GamePhase phaseE = GamePhaseModule.getGamePhase(exposed);
            check("shield sanity check positions are MIDDLEGAME not ENDGAME", phaseS == GamePhase.MIDDLEGAME && phaseE == GamePhase.MIDDLEGAME);
            double scoreShielded = KingSafetyModule.calculateKingSafetyScore(shielded, Color.BLACK, phaseS);
            double scoreExposed = KingSafetyModule.calculateKingSafetyScore(exposed, Color.BLACK, phaseE);
            check("stripped pawn shield lowers black king safety", scoreExposed < scoreShielded);
        }

        System.out.println("\n" + pass + " passed, " + fail + " failed");
        if (fail > 0) System.exit(1);
    }
}
