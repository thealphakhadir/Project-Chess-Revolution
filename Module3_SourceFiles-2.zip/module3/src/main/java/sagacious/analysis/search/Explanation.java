package sagacious.analysis.search;

import java.util.List;
import java.util.Map;

/**
 * evalBreakdown is left as a generic key->value map since the pseudocode
 * specifies it only as `Object` — the structural analyzer that will fill
 * this in (part of enrichSearchResult) can decide its own shape
 * (e.g. "material" -> 20, "kingSafety" -> -8, "pieceActivity" -> 12, ...).
 */
public record Explanation(String summary, List<String> conceptTags, Map<String, Object> evalBreakdown) {
}
