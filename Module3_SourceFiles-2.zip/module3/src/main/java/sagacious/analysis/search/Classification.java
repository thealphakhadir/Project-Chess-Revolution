package sagacious.analysis.search;

public record Classification(Severity severity, String reason, double swing) {
}
