package sagacious.analysis.search;

import sagacious.analysis.model.Move;
import sagacious.analysis.model.Position;
import sagacious.analysis.model.Ply;
import java.util.List;

/**
 * PART 2: EXTERNAL INTERFACE — TO BE SUPPLIED.
 *
 * These six methods are the only unimplemented pieces in this module.
 * Every other class in this codebase calls into a SearchEngine and
 * nothing else reaches toward board representation, search, or eval
 * internals directly. Implement this interface (board rep + NNUE eval +
 * pruning/verification search) and the rest of the module lights up.
 *
 * Each default method throws NotImplementedException so a caller gets a
 * loud, specific failure — naming exactly which piece is missing — rather
 * than a silent wrong answer, if something exercises this before the real
 * implementation lands.
 */
public interface SearchEngine {

    // ---- Stub 1 of 6 ----
    default Position parseFen(String fen) {
        throw new NotImplementedException("parseFen — board representation");
    }

    // ---- Stub 2 of 6 ----
    default RawSearchResult searchWithVerification(
            Position position, int depth, int alpha, int beta, boolean isRoot, InterruptCheck checkInterrupt) {
        throw new NotImplementedException("searchWithVerification — pruning/verification search core");
    }

    // ---- Stub 3 of 6 ----
    default SearchResult enrichSearchResult(
            Position position, RawSearchResult rawResult, SearchConfig config, List<Ply> gameHistory) {
        throw new NotImplementedException("enrichSearchResult — opening book, structural analyzer, " +
                "concept tagger, explanation generator, AI commentary, natural-move overlay");
    }

    // ---- Stub 4 of 6 ----
    default Classification classifyMove(
            Position position, Move moveMade, int evalBefore, int evalAfter, sagacious.analysis.model.GamePhase gamePhase) {
        throw new NotImplementedException("classifyMove — WDL conversion + backup-corroborated severity");
    }

    // ---- Stub 5 of 6 ----
    default int getEvalAfterMove(Position position, Move move) {
        throw new NotImplementedException("getEvalAfterMove — quick eval of the resulting position");
    }

    // ---- Stub 6 of 6 ----
    default SearchResult requestBackupAnalysis(String fen, SearchConfig config) {
        throw new NotImplementedException("requestBackupAnalysis — independent backup engine, deliberately " +
                "NOT sharing code with searchWithVerification");
    }
}
