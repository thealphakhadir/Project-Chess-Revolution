package sagacious.analysis.search;

import sagacious.analysis.model.Move;

public record AnnotatedMove(Move move, String purpose, boolean connectsToIdea) {
}
