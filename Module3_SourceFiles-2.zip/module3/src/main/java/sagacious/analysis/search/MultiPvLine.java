package sagacious.analysis.search;

import sagacious.analysis.model.Move;

public record MultiPvLine(Move move, int eval) {
}
