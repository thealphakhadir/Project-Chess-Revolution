package sagacious.analysis.search;

import sagacious.analysis.model.Move;

public record AlternateExplained(Move move, int evalGap, String whyWorse, boolean stillPlayable) {
}
