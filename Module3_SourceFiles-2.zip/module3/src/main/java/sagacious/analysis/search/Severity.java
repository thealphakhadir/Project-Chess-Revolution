package sagacious.analysis.search;

public enum Severity {
    BLUNDER, MISTAKE, INACCURACY, GOOD, BRILLIANT
}
