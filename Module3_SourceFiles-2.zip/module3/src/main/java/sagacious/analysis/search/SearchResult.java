package sagacious.analysis.search;

import sagacious.analysis.model.Move;
import java.util.List;

/**
 * TYPE SearchResult = RawSearchResult + { annotatedLine, alternatesExplained,
 * explanation, aiCommentary, naturalMoveOverlay, confidence }
 *
 * Composition (holds a RawSearchResult) rather than inheritance, since Java
 * records can't extend another record — accessors below flatten access so
 * callers can still write result.centipawns() etc. as the pseudocode does.
 *
 * naturalMoveOverlay is nullable and left as Object: the pseudocode leaves
 * its shape unspecified ("Object | NULL"), to be decided by enrichSearchResult.
 */
public record SearchResult(
        RawSearchResult raw,
        List<AnnotatedMove> annotatedLine,
        List<AlternateExplained> alternatesExplained,
        Explanation explanation,
        String aiCommentary,
        Object naturalMoveOverlay,
        double confidence
) implements SearchResultLike {

    public Move bestMove() { return raw.bestMove(); }
    @Override public int centipawns() { return raw.centipawns(); }
    @Override public boolean isMate() { return raw.isMate(); }
    @Override public Integer mateIn() { return raw.mateIn(); }
    public List<MultiPvLine> multiPV() { return raw.multiPV(); }
    @Override public int depthReached() { return raw.depthReached(); }
}
