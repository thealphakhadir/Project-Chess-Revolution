package sagacious.analysis.search;

/** Thrown by SearchEngine's default stub methods — see Part 2 of the design doc. */
public class NotImplementedException extends RuntimeException {
    private static final long serialVersionUID = 1L;

    public NotImplementedException(String what) {
        super("NOT_IMPLEMENTED: " + what);
    }
}
