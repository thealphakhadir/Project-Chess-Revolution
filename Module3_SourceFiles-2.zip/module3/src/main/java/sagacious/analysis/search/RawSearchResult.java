package sagacious.analysis.search;

import sagacious.analysis.model.Move;
import java.util.List;

/**
 * TYPE RawSearchResult = {
 *   bestMove, centipawns, isMate, mateIn, multiPV, depthReached
 * }
 * `mateIn` is signed: positive = side-to-move mates, negative = side-to-move gets mated.
 * `depthReached` is attached by the worker loop (AnalysisWorkerPool), not by searchWithVerification.
 */
public record RawSearchResult(
        Move bestMove,
        int centipawns,
        boolean isMate,
        Integer mateIn,
        List<MultiPvLine> multiPV,
        int depthReached
) implements SearchResultLike {
    /** Returns a copy with depthReached set — used by the worker loop after each iteration. */
    public RawSearchResult withDepthReached(int depth) {
        return new RawSearchResult(bestMove, centipawns, isMate, mateIn, multiPV, depth);
    }
}
