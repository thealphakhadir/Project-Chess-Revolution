package sagacious.analysis.search;

/** Passed into searchWithVerification so it can poll for cancellation/timeout mid-search. */
@FunctionalInterface
public interface InterruptCheck {
    /** True means "stop searching now and return your best result so far." */
    boolean shouldInterrupt();
}
