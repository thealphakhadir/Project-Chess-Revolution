package sagacious.analysis.search;

import sagacious.analysis.config.Tier;
import sagacious.analysis.model.Ply;
import java.util.List;

/**
 * Config bundle threaded through requestAnalysis / the worker loop /
 * searchWithVerification / enrichSearchResult. timeLimit is in
 * milliseconds; null means "no explicit limit, depth governs."
 */
public record SearchConfig(
        Tier tier,
        int maxDepth,
        Long timeLimitMs,
        Integer userElo,
        boolean skipEnrichment,
        List<Ply> gameHistory
) {
    public SearchConfig withSkipEnrichment(boolean skip) {
        return new SearchConfig(tier, maxDepth, timeLimitMs, userElo, skip, gameHistory);
    }

    public SearchConfig withMaxDepth(int depth) {
        return new SearchConfig(tier, depth, timeLimitMs, userElo, skipEnrichment, gameHistory);
    }
}
