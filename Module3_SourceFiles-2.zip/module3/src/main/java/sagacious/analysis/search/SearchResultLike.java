package sagacious.analysis.search;

import sagacious.analysis.model.Move;

/**
 * Part 3 says generateEvalBar "accepts RawSearchResult or SearchResult" —
 * Java has no duck typing, so both result types implement this common
 * view instead.
 */
public interface SearchResultLike {
    Move bestMove();
    int centipawns();
    boolean isMate();
    Integer mateIn();
    int depthReached();
}
