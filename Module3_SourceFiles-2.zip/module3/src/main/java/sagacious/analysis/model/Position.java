package sagacious.analysis.model;

import java.util.List;

/**
 * INTERFACE Position — the board representation this module is written
 * against. The real implementation lives wherever the board/move-generator
 * code lives (part of what "search internals" will bring, per Part 2 of
 * the design doc). Everything in this module calls only these methods —
 * adapt at the boundary if the real representation differs.
 */
public interface Position {
    String fen();
    Color turnToMove();
    int plyCount();

    /** Null if the square is empty. */
    PieceOnBoard pieceAt(Square square);

    List<PlacedPiece> allPieces();
    List<PieceAtSquare> piecesOf(Color color);
    Square kingSquare(Color color);
    boolean isSquareAttackedBy(Square square, Color byColor);
    List<PieceAtSquare> attackersOf(Square square, Color byColor);
}
