package sagacious.analysis.model;

import java.util.List;
import java.util.Map;

public final class BoardConstants {
    private BoardConstants() {}

    public static final List<Direction> ALL_8_DIRECTIONS = List.of(
            new Direction(1, 0), new Direction(-1, 0), new Direction(0, 1), new Direction(0, -1),
            new Direction(1, 1), new Direction(1, -1), new Direction(-1, 1), new Direction(-1, -1)
    );

    public static final List<Integer> ALL_RANKS = List.of(1, 2, 3, 4, 5, 6, 7, 8);

    public static final Map<PieceType, Integer> PIECE_VALUES = Map.of(
            PieceType.PAWN, 1,
            PieceType.KNIGHT, 3,
            PieceType.BISHOP, 3,
            PieceType.ROOK, 5,
            PieceType.QUEEN, 9,
            PieceType.KING, 0
    );
}
