package sagacious.analysis.model;

/**
 * TYPE Move = { from, to, piece, promotion: PieceType | NULL, isCapture: Boolean }
 * `promotion` is null when the move is not a promotion.
 */
public record Move(Square from, Square to, PieceType piece, PieceType promotion, boolean isCapture) {

    /** Convenience constructor for a non-promoting move. */
    public static Move of(Square from, Square to, PieceType piece, boolean isCapture) {
        return new Move(from, to, piece, null, isCapture);
    }

    public boolean isPromotion() {
        return promotion != null;
    }

    @Override
    public String toString() {
        String s = piece + " " + from + "-" + to;
        if (isCapture) s += "x";
        if (isPromotion()) s += "=" + promotion;
        return s;
    }
}
