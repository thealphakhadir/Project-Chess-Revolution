package sagacious.analysis.model;

import java.util.List;

/** INTERFACE Game — move history, as assumed by Part 7's reviewFullGame. */
public interface Game {
    List<Ply> moves();
    Position getPositionBefore(Ply ply);
    List<Ply> movesUpTo(Ply ply);
}
