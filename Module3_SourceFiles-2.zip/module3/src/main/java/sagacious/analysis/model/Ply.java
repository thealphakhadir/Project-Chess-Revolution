package sagacious.analysis.model;

/** TYPE Ply = { moveMade: Move, moveNumber: Integer } */
public record Ply(Move moveMade, int moveNumber) {
}
