package sagacious.analysis.model;

/** A (file, rank) step offset, e.g. one of the 8 king/queen directions. */
public record Direction(int df, int dr) {
}
