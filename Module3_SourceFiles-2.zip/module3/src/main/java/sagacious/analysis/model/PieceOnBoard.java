package sagacious.analysis.model;

/** Return shape for Position.pieceAt(square) — a piece's type and color, with no square attached. */
public record PieceOnBoard(PieceType type, Color color) {
}
