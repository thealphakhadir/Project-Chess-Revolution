package sagacious.analysis.model;

public enum GamePhase {
    OPENING, MIDDLEGAME, ENDGAME
}
