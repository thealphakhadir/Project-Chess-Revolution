package sagacious.analysis.model;

/** Return shape for Position.allPieces() / piecesOf(color) — a piece with its square. */
public record PlacedPiece(PieceType type, Color color, Square square) {
}
