package sagacious.analysis.model;

public enum PieceType {
    PAWN, KNIGHT, BISHOP, ROOK, QUEEN, KING
}
