package sagacious.analysis.model;

/**
 * A board square. file: 0-7 (a-h), rank: 1-8.
 * Matches pseudocode's TYPE Square = { file: Integer, rank: Integer }.
 */
public record Square(int file, int rank) {

    /** Matches pseudocode's squareKey(sq), used as a map key (e.g. CENTRAL_DISTANCE_TABLE). */
    public String key() {
        return file + "," + rank;
    }

    @Override
    public String toString() {
        return "" + (char) ('a' + file) + rank;
    }
}
