package sagacious.analysis.model;

/**
 * Return shape for Position.piecesOf(color) and Position.attackersOf(square, color) —
 * the color is already implied by the call, so only type + square travel with each entry.
 */
public record PieceAtSquare(PieceType type, Square square) {
}
