package sagacious.analysis.model;

/** Free functions from Part 1 of the design doc (board primitives). */
public final class BoardMath {
    private BoardMath() {}

    public static boolean isValidFile(int f) {
        return f >= 0 && f <= 7;
    }

    public static boolean isValidRank(int r) {
        return r >= 1 && r <= 8;
    }

    public static boolean isValidSquare(Square sq) {
        return isValidFile(sq.file()) && isValidRank(sq.rank());
    }

    public static int chebyshevDistance(Square a, Square b) {
        return Math.max(Math.abs(a.file() - b.file()), Math.abs(a.rank() - b.rank()));
    }

    public static double clamp(double value, double minVal, double maxVal) {
        return Math.max(minVal, Math.min(maxVal, value));
    }

    public static int clamp(int value, int minVal, int maxVal) {
        return Math.max(minVal, Math.min(maxVal, value));
    }

    public static double lerp(double a, double b, double t) {
        return a + (b - a) * t;
    }

    /** ELAPSED_MS(startTime) — startTime and the return value are both epoch millis. */
    public static long elapsedMs(long startTimeMs) {
        return System.currentTimeMillis() - startTimeMs;
    }
}
