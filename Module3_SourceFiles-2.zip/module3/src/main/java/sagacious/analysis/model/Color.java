package sagacious.analysis.model;

/** Side to move / piece color. */
public enum Color {
    WHITE, BLACK;

    /** Mirrors pseudocode's opponent(color). */
    public Color opponent() {
        return this == WHITE ? BLACK : WHITE;
    }
}
