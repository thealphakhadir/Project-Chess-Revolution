package sagacious.analysis.config;

import java.util.Map;

/** Part 6: TIER CONFIG (complete). */
public final class TierConfigs {
    private TierConfigs() {}

    public static final Map<Tier, TierConfig> TIER_CONFIGS = Map.of(
            Tier.FAST, new TierConfig(10),
            Tier.STANDARD, new TierConfig(18),
            Tier.DEEP, new TierConfig(30)
    );

    /**
     * getDeviceTier() — JS's navigator.hardwareConcurrency has no exact Java
     * equivalent; Runtime.availableProcessors() is the standard analogue
     * (logical cores available to the JVM).
     */
    public static DeviceTier getDeviceTier() {
        int cores = Runtime.getRuntime().availableProcessors();
        if (cores <= 0) cores = 4; // "OR 4" fallback from the pseudocode
        if (cores <= 2) return DeviceTier.LOW_END;
        if (cores <= 6) return DeviceTier.MID;
        return DeviceTier.HIGH_END;
    }

    public static Tier resolveTier(RequestedTier requestedTier) {
        if (requestedTier != RequestedTier.AUTO) {
            return requestedTier.asResolvedTier();
        }
        DeviceTier deviceTier = getDeviceTier();
        return switch (deviceTier) {
            case LOW_END -> Tier.FAST;
            case HIGH_END -> Tier.DEEP;
            case MID -> Tier.STANDARD;
        };
    }
}
