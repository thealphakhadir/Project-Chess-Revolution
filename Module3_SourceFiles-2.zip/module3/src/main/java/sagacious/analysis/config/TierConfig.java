package sagacious.analysis.config;

public record TierConfig(int maxDepth) {
}
