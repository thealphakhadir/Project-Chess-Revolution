package sagacious.analysis.config;

/** What a caller asks for. AUTO defers to resolveTier()'s device-based heuristic. */
public enum RequestedTier {
    AUTO, FAST, STANDARD, DEEP;

    public Tier asResolvedTier() {
        return switch (this) {
            case FAST -> Tier.FAST;
            case STANDARD -> Tier.STANDARD;
            case DEEP -> Tier.DEEP;
            case AUTO -> throw new IllegalStateException("AUTO has no direct Tier — call TierConfigs.resolveTier() instead");
        };
    }
}
