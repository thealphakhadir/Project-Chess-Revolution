package sagacious.analysis.config;

public enum DeviceTier {
    LOW_END, MID, HIGH_END
}
