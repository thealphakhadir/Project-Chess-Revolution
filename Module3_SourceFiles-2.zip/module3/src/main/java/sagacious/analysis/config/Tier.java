package sagacious.analysis.config;

public enum Tier {
    FAST, STANDARD, DEEP
}
