package sagacious.analysis.api;

import sagacious.analysis.config.Tier;
import sagacious.analysis.config.TierConfigs;
import sagacious.analysis.eval.EvalBar;
import sagacious.analysis.eval.EvalBarModule;
import sagacious.analysis.eval.GamePhaseModule;
import sagacious.analysis.eval.KingSafetyBars;
import sagacious.analysis.eval.KingSafetyModule;
import sagacious.analysis.model.*;
import sagacious.analysis.search.*;
import sagacious.analysis.shared.AnalysisWorkerPool;
import sagacious.analysis.shared.BackupWorker;
import sagacious.analysis.shared.SearchSession;

import java.util.*;
import java.util.concurrent.CompletableFuture;

/**
 * PART 7: CONSTRUCTIVE ANALYSIS — TOP-LEVEL API.
 *
 * constructiveAnalysis/mergeReport/buildLightweightReport/
 * identifyCriticalMoments/evalDeltaMagnitude are all given directly in the
 * source doc and are ported as-is (see each method's doc comment).
 *
 * requestAnalysis and reviewFullGame are CALLED by Part 7 but never
 * DEFINED anywhere in the source doc — this class implements both,
 * against Part 0's reconciliation notes rather than against literal
 * pseudocode (which doesn't exist for these two). That's flagged clearly
 * here and in each method's doc comment; treat these two as a first draft
 * to review, not a straight port like everything else in this file.
 */
public final class ConstructiveAnalysis {

    private final SearchEngine engine;
    private final AnalysisWorkerPool workerPool;
    private final BackupWorker backupWorker;

    public ConstructiveAnalysis(SearchEngine engine, AnalysisWorkerPool workerPool, BackupWorker backupWorker) {
        this.engine = engine;
        this.workerPool = workerPool;
        this.backupWorker = backupWorker;
    }

    // ------------------------------------------------------------
    // constructiveAnalysis(input, callbacks) — as given in Part 7.
    // ------------------------------------------------------------
    public Cancellable constructiveAnalysis(AnalysisInput input, AnalysisCallbacks callbacks) {
        if (input instanceof AnalysisInput.SinglePosition sp) {
            Tier tier = TierConfigs.resolveTier(sp.tier());
            SearchConfig config = new SearchConfig(
                    tier, TierConfigs.TIER_CONFIGS.get(tier).maxDepth(),
                    sp.timeLimitMs(), sp.userElo(), /* skipEnrichment */ false, sp.gameHistory()
            );
            return requestAnalysis(sp.position(), config,
                    /* onStreamUpdate */ raw -> {
                        if (callbacks.onStreamUpdate() == null) return;
                        Report report = mergeReport(raw,
                                EvalBarModule.generateEvalBar(raw),
                                KingSafetyModule.generateKingSafetyBars(sp.position()),
                                GamePhaseModule.getGamePhase(sp.position()));
                        callbacks.onStreamUpdate().accept(report);
                    },
                    /* onFinalResult */ result -> {
                        Report report = mergeReport(result,
                                EvalBarModule.generateEvalBar(result),
                                KingSafetyModule.generateKingSafetyBars(sp.position()),
                                GamePhaseModule.getGamePhase(sp.position()));
                        if (callbacks.onComplete() != null) callbacks.onComplete().accept(report);
                    });

        } else if (input instanceof AnalysisInput.FullGame fg) {
            return reviewFullGame(fg.game(), fg.userElo(), callbacks.onProgressiveUpdate(), callbacks.onComplete());
        } else {
            throw new IllegalArgumentException("constructiveAnalysis: unknown AnalysisInput variant " + input);
        }
    }

    /**
     * requestAnalysis — called by constructiveAnalysis but not defined in
     * the source doc. Per Part 0 note 2 ("exactly ONE path into the search
     * engine: through a worker"), this is the thin bridge from the
     * pseudocode's callback-based API onto AnalysisWorkerPool.submit().
     */
    private Cancellable requestAnalysis(Position position, SearchConfig config,
                                         java.util.function.Consumer<RawSearchResult> onStreamUpdate,
                                         java.util.function.Consumer<SearchResult> onFinalResult) {
        SearchSession session = workerPool.submit(position, config, onStreamUpdate);
        session.finalResult().whenComplete((result, error) -> {
            if (error == null && onFinalResult != null) onFinalResult.accept(result);
            // Errors are surfaced through session.finalResult() itself for
            // any caller awaiting the future directly; a silent swallow
            // here would hide search failures from a caller that only
            // wired up onFinalResult and not the future.
        });
        return session;
    }

    // ------------------------------------------------------------
    // mergeReport — as given in Part 7. See Report's doc comment for how
    // the enrichment-fields-during-streaming gap is resolved in Java.
    // ------------------------------------------------------------
    public static Report mergeReport(SearchResultLike result, EvalBar evalBar, KingSafetyBars kingSafetyBars, GamePhase gamePhase) {
        List<AnnotatedMove> annotatedLine = List.of();
        List<AlternateExplained> alternatesExplained = List.of();
        Explanation explanation = null;
        String aiCommentary = null;
        Object naturalMoveOverlay = null;
        double confidence = 0.0;

        if (result instanceof SearchResult sr) {
            annotatedLine = sr.annotatedLine() != null ? sr.annotatedLine() : List.of();
            alternatesExplained = sr.alternatesExplained() != null ? sr.alternatesExplained() : List.of();
            explanation = sr.explanation();
            aiCommentary = sr.aiCommentary();
            naturalMoveOverlay = sr.naturalMoveOverlay();
            confidence = sr.confidence();
        }

        return new Report(
                result.bestMove(),
                new EvalSummary(result.centipawns(), result.isMate(), result.mateIn()),
                evalBar,
                kingSafetyBars,
                gamePhase,
                annotatedLine,
                alternatesExplained,
                explanation,
                aiCommentary,
                naturalMoveOverlay,
                confidence,
                result.depthReached()
        );
    }

    // ------------------------------------------------------------
    // buildLightweightReport — as given in Part 7.
    // ------------------------------------------------------------
    public static LightweightReport buildLightweightReport(RawSearchResult rawResult, Position position, GamePhase gamePhase) {
        return new LightweightReport(
                EvalBarModule.generateEvalBar(rawResult),
                KingSafetyModule.generateKingSafetyBars(position),
                gamePhase,
                rawResult.bestMove(),
                rawResult.depthReached()
        );
    }

    // ------------------------------------------------------------
    // identifyCriticalMoments / evalDeltaMagnitude — as given in Part 7,
    // using the documented SAFETY_THRESHOLD default (see CriticalMomentConfig).
    // ------------------------------------------------------------
    public static List<CriticalMoment> identifyCriticalMoments(List<EvalBar> evalTimeline, List<KingSafetyBars> kingSafetyTimeline) {
        List<CriticalMoment> moments = new ArrayList<>();
        for (int i = 1; i < evalTimeline.size(); i++) {
            double evalSwing = evalDeltaMagnitude(evalTimeline.get(i), evalTimeline.get(i - 1));
            double safetySwing = Math.max(
                    Math.abs(kingSafetyTimeline.get(i).white().score() - kingSafetyTimeline.get(i - 1).white().score()),
                    Math.abs(kingSafetyTimeline.get(i).black().score() - kingSafetyTimeline.get(i - 1).black().score())
            );
            if (evalSwing > CriticalMomentConfig.EVAL_THRESHOLD || safetySwing > CriticalMomentConfig.SAFETY_THRESHOLD) {
                moments.add(new CriticalMoment(
                        i, evalSwing, safetySwing,
                        evalSwing > CriticalMomentConfig.EVAL_THRESHOLD ? MomentTrigger.EVAL_SWING : MomentTrigger.KING_SAFETY_SWING
                ));
            }
        }
        return moments;
    }

    public static double evalDeltaMagnitude(EvalBar barA, EvalBar barB) {
        if (barA.isMate() || barB.isMate()) return CriticalMomentConfig.EVAL_THRESHOLD + 1;
        return Math.abs(barA.numericValue() - barB.numericValue());
    }

    // ------------------------------------------------------------
    // reviewFullGame — called by Part 7 but never defined in the source
    // doc. Built against Part 0's reconciliation notes:
    //   - note 4: fast pass reuses the worker loop with skipEnrichment=true
    //     and a shallow (FAST tier) maxDepth.
    //   - note 2: still goes through the worker pool, never calls the
    //     search engine directly.
    //   - note 3 + classifyMove's own docstring ("backup-corroborated
    //     severity"): once critical moments are found, this issues a
    //     deeper, enriched, backup-cross-checked analysis for those
    //     specific plies only — not for every move, which would be far
    //     more search+enrichment+backup cost than a game review needs.
    // ------------------------------------------------------------
    public GameReviewSession reviewFullGame(Game game, Integer userElo,
                                             java.util.function.Consumer<LightweightReport> onProgressiveUpdate,
                                             java.util.function.Consumer<Object> onComplete) {
        GameReviewSession session = new GameReviewSession();
        List<Ply> allPlies = game.moves();

        CompletableFuture.runAsync(() -> {
            List<PerMoveReview> perMoveReviews = new ArrayList<>();
            List<EvalBar> evalTimeline = new ArrayList<>();
            List<KingSafetyBars> safetyTimeline = new ArrayList<>();

            Tier fastTier = Tier.FAST;
            int fastDepth = TierConfigs.TIER_CONFIGS.get(fastTier).maxDepth();

            // ---- Fast pass: one shallow, unenriched search per move ----
            for (Ply ply : allPlies) {
                if (session.isCancelled()) return;

                Position positionBefore = game.getPositionBefore(ply);
                SearchConfig fastConfig = new SearchConfig(fastTier, fastDepth, null, userElo, true, null);

                SearchSession moveSession = workerPool.submit(positionBefore, fastConfig, null);
                RawSearchResult rawResult;
                try {
                    rawResult = moveSession.finalResult().get().raw();
                } catch (Exception e) {
                    continue; // one move's search failing shouldn't abort the whole review
                }

                GamePhase gamePhase = GamePhaseModule.getGamePhase(positionBefore);
                LightweightReport lightReport = buildLightweightReport(rawResult, positionBefore, gamePhase);
                evalTimeline.add(lightReport.evalBar());
                safetyTimeline.add(lightReport.kingSafetyBars());

                int evalBefore = rawResult.centipawns();
                int evalAfter;
                Classification classification;
                try {
                    evalAfter = engine.getEvalAfterMove(positionBefore, ply.moveMade());
                    classification = engine.classifyMove(positionBefore, ply.moveMade(), evalBefore, evalAfter, gamePhase);
                } catch (NotImplementedException e) {
                    classification = null; // Stub 4/5 not supplied yet — review still proceeds without severity
                }

                PerMoveReview review = new PerMoveReview(ply, lightReport, classification);
                perMoveReviews.add(review);
                if (onProgressiveUpdate != null) onProgressiveUpdate.accept(lightReport);
            }

            // ---- Critical moments from the fast-pass timelines ----
            List<CriticalMoment> criticalMoments = identifyCriticalMoments(evalTimeline, safetyTimeline);

            // Also always deep-dive any move the (optional) classifier flagged
            // as a blunder, even if it didn't independently trip the eval/
            // safety swing thresholds above.
            Set<Integer> plyIndicesToDeepDive = new TreeSet<>();
            for (CriticalMoment m : criticalMoments) plyIndicesToDeepDive.add(m.ply());
            for (int i = 0; i < perMoveReviews.size(); i++) {
                Classification c = perMoveReviews.get(i).classification();
                if (c != null && c.severity() == Severity.BLUNDER) plyIndicesToDeepDive.add(i);
            }

            // ---- Deep, enriched, backup-corroborated dive on flagged plies only ----
            Map<Integer, SearchResult> deepDives = new HashMap<>();
            for (int plyIndex : plyIndicesToDeepDive) {
                if (session.isCancelled()) break;
                if (plyIndex < 0 || plyIndex >= allPlies.size()) continue;

                Position positionBefore = game.getPositionBefore(allPlies.get(plyIndex));
                Tier deepTier = Tier.DEEP;
                SearchConfig deepConfig = new SearchConfig(
                        deepTier, TierConfigs.TIER_CONFIGS.get(deepTier).maxDepth(),
                        null, userElo, /* skipEnrichment */ false, game.movesUpTo(allPlies.get(plyIndex)));

                SearchSession deepSession = workerPool.submit(positionBefore, deepConfig, null);
                try {
                    SearchResult deepResult = deepSession.finalResult().get();
                    // Cross-check severity with the independent backup engine
                    // (classifyMove's own docstring: "backup-corroborated
                    // severity") rather than trusting a single search line.
                    try {
                        backupWorker.requestBackupAnalysis(positionBefore.fen(), deepConfig).get();
                        // The backup result itself isn't merged into deepResult
                        // here (that corroboration logic is classifyMove's job,
                        // per Stub 4's own docstring) — fetching it up front
                        // just ensures it's warm/cached by the time a caller
                        // wants the corroborated classification.
                    } catch (Exception backupFailure) {
                        // CompletableFuture.get() wraps whatever the backup
                        // stub throws in ExecutionException — including
                        // NotImplementedException while stub 6 isn't supplied
                        // yet — so this must catch broadly, not just the
                        // unwrapped stub type. Any backup failure (not
                        // implemented, timed out, crashed) means: proceed with
                        // the primary engine's already-successful result alone,
                        // rather than losing it too.
                    }
                    deepDives.put(plyIndex, deepResult);
                } catch (Exception e) {
                    // A failed deep dive on one flagged ply shouldn't drop the
                    // rest of the review.
                }
            }

            GameReviewResult finalResult = new GameReviewResult(perMoveReviews, criticalMoments, deepDives);
            session.finalResult().complete(finalResult);
            if (onComplete != null) onComplete.accept(finalResult);

        }).exceptionally(e -> {
            session.finalResult().completeExceptionally(e);
            return null;
        });

        return session;
    }

    /** Handle for an in-flight or completed reviewFullGame() call. */
    public static final class GameReviewSession implements Cancellable {
        private final CompletableFuture<GameReviewResult> finalResult = new CompletableFuture<>();
        private volatile boolean cancelled = false;

        public CompletableFuture<GameReviewResult> finalResult() { return finalResult; }
        public boolean isCancelled() { return cancelled; }
        @Override public void cancel() { cancelled = true; }
    }
}
