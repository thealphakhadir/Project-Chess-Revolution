package sagacious.analysis.api;

import sagacious.analysis.eval.EvalBar;
import sagacious.analysis.eval.KingSafetyBars;
import sagacious.analysis.model.GamePhase;
import sagacious.analysis.model.Move;
import sagacious.analysis.search.*;

import java.util.List;

/**
 * mergeReport's output type. During streaming (per-depth updates, before
 * enrichSearchResult has run), the enrichment fields below are empty/null —
 * they only get populated in the final report once enrichment has run once,
 * per Part 0 note 1. This reflects a real timing gap in the source
 * pseudocode: mergeReport reads result.annotatedLine/explanation/etc, but
 * those fields only exist on the fully-enriched SearchResult, not on the
 * RawSearchResult each streaming tick actually carries.
 */
public record Report(
        Move bestMove,
        EvalSummary eval,
        EvalBar evalBar,
        KingSafetyBars kingSafetyBars,
        GamePhase gamePhase,
        List<AnnotatedMove> annotatedLine,
        List<AlternateExplained> alternatesExplained,
        Explanation explanation,
        String aiCommentary,
        Object naturalMoveOverlay,
        double confidence,
        int depthReached
) {
    /** True once this report reflects a fully-enriched SearchResult rather than an in-progress streaming tick. */
    public boolean isEnriched() {
        return explanation != null;
    }
}
