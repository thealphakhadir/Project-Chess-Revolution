package sagacious.analysis.api;

import sagacious.analysis.config.RequestedTier;
import sagacious.analysis.model.Game;
import sagacious.analysis.model.Ply;
import sagacious.analysis.model.Position;

import java.util.List;

/**
 * input.type: "SINGLE_POSITION" | "FULL_GAME" — modeled as a sealed
 * interface instead of a string tag, so the dispatch in
 * ConstructiveAnalysis.constructiveAnalysis() is exhaustive-checked by
 * the compiler rather than needing an "unknown input.type" else-throw.
 */
public sealed interface AnalysisInput permits AnalysisInput.SinglePosition, AnalysisInput.FullGame {

    record SinglePosition(
            Position position,
            RequestedTier tier,
            Long timeLimitMs,
            Integer userElo,
            List<Ply> gameHistory,
            String uiSlot
    ) implements AnalysisInput {
        public SinglePosition {
            if (uiSlot == null) uiSlot = "default-analysis-slot";
            if (tier == null) tier = RequestedTier.AUTO;
        }
    }

    record FullGame(Game game, Integer userElo) implements AnalysisInput {
    }
}
