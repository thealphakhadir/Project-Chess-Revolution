package sagacious.analysis.api;

/**
 * The source design doc's PART 7 is truncated exactly at this constant:
 *   CONST CRITICAL_MOMENT_CONFIG = { EVAL_THRESHOLD: 100, SAFETY_THRESHOLD
 * — no value or closing brace for SAFETY_THRESHOLD. EVAL_THRESHOLD: 100
 * (centipawns, i.e. one pawn) is given, so SAFETY_THRESHOLD below is a
 * documented placeholder, not a guess presented as spec: king safety
 * scores live on a 0-100 scale (same as the eval bar's fill percent), and
 * the gap between adjacent labelForSafety() bands is ~30 points (e.g.
 * "Safe">75, "Slightly exposed">45) — so a swing needs to be smaller than
 * a full band change to count as "critical" rather than merely "the label
 * changed." 15 was picked as roughly half that band width. Replace this
 * with a tuned value once real games make the right threshold clear.
 */
public final class CriticalMomentConfig {
    private CriticalMomentConfig() {}

    public static final double EVAL_THRESHOLD = 100;
    public static final double SAFETY_THRESHOLD = 15; // placeholder — see class doc
}
