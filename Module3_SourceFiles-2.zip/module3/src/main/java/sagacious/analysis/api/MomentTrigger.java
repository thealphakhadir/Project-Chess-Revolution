package sagacious.analysis.api;

public enum MomentTrigger {
    EVAL_SWING, KING_SAFETY_SWING
}
