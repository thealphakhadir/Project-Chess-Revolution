package sagacious.analysis.api;

public record EvalSummary(int centipawns, boolean isMate, Integer mateIn) {
}
