package sagacious.analysis.api;

import sagacious.analysis.search.SearchResult;
import java.util.List;
import java.util.Map;

/**
 * reviewFullGame's output. Not specified anywhere in the source design
 * doc — Part 7 calls reviewFullGame() but the doc never defines it. This
 * shape follows directly from Part 0's reconciliation notes: a fast pass
 * over every move (note 4, lightweight reports), critical moments pulled
 * from the resulting eval/safety timelines (Part 7's identifyCriticalMoments,
 * which IS defined), and — since classifyMove's own docstring says
 * "backup-corroborated severity" — a deeper, backup-cross-checked dive on
 * whichever moves turned out to matter, rather than paying full search+
 * enrichment+backup cost for every move in the game.
 */
public record GameReviewResult(
        List<PerMoveReview> perMoveReviews,
        List<CriticalMoment> criticalMoments,
        Map<Integer, SearchResult> deepDivesByPly // ply index -> full enriched+backup-corroborated analysis
) {
}
