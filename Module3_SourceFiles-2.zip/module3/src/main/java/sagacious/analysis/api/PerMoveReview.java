package sagacious.analysis.api;

import sagacious.analysis.model.Ply;
import sagacious.analysis.search.Classification;

public record PerMoveReview(Ply ply, LightweightReport report, Classification classification) {
}
