package sagacious.analysis.api;

import sagacious.analysis.eval.EvalBar;
import sagacious.analysis.eval.KingSafetyBars;
import sagacious.analysis.model.GamePhase;
import sagacious.analysis.model.Move;

/** "Used only by the fast game-review pass — no enrichment fields." */
public record LightweightReport(
        EvalBar evalBar,
        KingSafetyBars kingSafetyBars,
        GamePhase gamePhase,
        Move bestMove,
        int depthReached
) {
}
