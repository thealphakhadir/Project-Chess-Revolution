package sagacious.analysis.api;

import java.util.function.Consumer;

/**
 * callbacks: { onStreamUpdate, onProgressiveUpdate, onComplete }
 *
 * onStreamUpdate    — SINGLE_POSITION only, fired once per completed depth.
 * onProgressiveUpdate — FULL_GAME only, fired once per move during the fast pass.
 * onComplete        — both branches; carries a Report for SINGLE_POSITION,
 *                      a GameReviewResult for FULL_GAME. Typed Object because
 *                      the two branches genuinely return different shapes —
 *                      matching the pseudocode's callbacks.onComplete(report)
 *                      being reused across both without a shared result type.
 */
public record AnalysisCallbacks(
        Consumer<Report> onStreamUpdate,
        Consumer<LightweightReport> onProgressiveUpdate,
        Consumer<Object> onComplete
) {
}
