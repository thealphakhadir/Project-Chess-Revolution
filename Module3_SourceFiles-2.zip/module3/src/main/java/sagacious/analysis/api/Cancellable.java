package sagacious.analysis.api;

/** Common handle returned by constructiveAnalysis, whichever branch it took. */
public interface Cancellable {
    void cancel();
}
