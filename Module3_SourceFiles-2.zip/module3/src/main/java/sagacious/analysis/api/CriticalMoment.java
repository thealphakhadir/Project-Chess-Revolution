package sagacious.analysis.api;

public record CriticalMoment(int ply, double evalSwing, double safetySwing, MomentTrigger trigger) {
}
