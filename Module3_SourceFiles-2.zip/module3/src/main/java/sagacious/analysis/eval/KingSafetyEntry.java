package sagacious.analysis.eval;

public record KingSafetyEntry(double score, String label) {
}
