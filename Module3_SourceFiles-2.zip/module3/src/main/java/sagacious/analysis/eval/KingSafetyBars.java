package sagacious.analysis.eval;

import sagacious.analysis.model.GamePhase;

public record KingSafetyBars(KingSafetyEntry white, KingSafetyEntry black, GamePhase gamePhase) {
}
