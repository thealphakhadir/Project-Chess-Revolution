package sagacious.analysis.eval;

import sagacious.analysis.model.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * PART 4: KING SAFETY BAR MODULE (complete).
 *
 * One filled-in gap, flagged: ATTACKER_UNIT_WEIGHT / DEFENDER_UNIT_WEIGHT in
 * the source pseudocode have no entry for KING, but attackersOf()/the king
 * zone can in principle include the enemy king (kings can end up adjacent,
 * mostly in endgames — though calculateKingSafetyScore() routes ENDGAME
 * positions to calculateKingActivityScore() instead, so this only matters
 * for an unusual non-endgame position with kings already close together).
 * Both weight maps below default an unlisted piece type — i.e. KING — to
 * 0, so the score degrades gracefully instead of throwing.
 */
public final class KingSafetyModule {
    private KingSafetyModule() {}

    public static final double BASE_SAFETY_SCORE = 50;
    public static final double W_SHIELD = 4;
    public static final double W_OPEN_LINES = 6;
    public static final double W_ATTACK = 1;
    public static final double W_DEFEND = 0.6;
    public static final double W_TROPISM = 0.5;
    public static final double UNCASTLED_PENALTY = 12;

    private static final Map<PieceType, Double> ATTACKER_UNIT_WEIGHT = Map.of(
            PieceType.QUEEN, 4.0, PieceType.ROOK, 2.0, PieceType.BISHOP, 2.0,
            PieceType.KNIGHT, 2.0, PieceType.PAWN, 1.0
    );
    private static final Map<PieceType, Double> DEFENDER_UNIT_WEIGHT = Map.of(
            PieceType.QUEEN, 1.0, PieceType.ROOK, 1.0, PieceType.BISHOP, 1.5,
            PieceType.KNIGHT, 1.5, PieceType.PAWN, 2.0
    );

    private static double attackerWeight(PieceType type) {
        return ATTACKER_UNIT_WEIGHT.getOrDefault(type, 0.0);
    }
    private static double defenderWeight(PieceType type) {
        return DEFENDER_UNIT_WEIGHT.getOrDefault(type, 0.0);
    }

    // ------------------------------------------------------------
    public static double calculateKingSafetyScore(Position position, Color color, GamePhase gamePhase) {
        if (gamePhase == GamePhase.ENDGAME) {
            return calculateKingActivityScore(position, color);
        }

        double shieldRatio = evaluatePawnShieldIntegrity(position, color);
        double openLines = evaluateOpenLinesTowardKing(position, color);
        double attackerWeight = evaluateAttackerWeightNearKing(position, color);
        double defenderWeight = evaluateDefenderWeightNearKing(position, color);
        double tropism = evaluateEnemyPieceProximity(position, color);
        double exposurePenalty = isKingUncastledMidgame(position, color) ? UNCASTLED_PENALTY : 0;

        double rawScore = BASE_SAFETY_SCORE
                + (shieldRatio * 3 * W_SHIELD)
                - (openLines * W_OPEN_LINES)
                - (attackerWeight * W_ATTACK)
                + (defenderWeight * W_DEFEND)
                - (tropism * W_TROPISM)
                - exposurePenalty;

        return BoardMath.clamp(rawScore, 0, 100);
    }

    public static double evaluatePawnShieldIntegrity(Position position, Color color) {
        Square kingSq = position.kingSquare(color);
        List<Square> shieldSquares = getShieldSquares(kingSq, color);
        int intactCount = 0;
        for (Square sq : shieldSquares) {
            PieceOnBoard piece = position.pieceAt(sq);
            if (piece != null && piece.type() == PieceType.PAWN && piece.color() == color) {
                intactCount++;
            }
        }
        return intactCount / (double) Math.max(shieldSquares.size(), 1);
    }

    public static List<Square> getShieldSquares(Square kingSquare, Color color) {
        int direction = (color == Color.WHITE) ? 1 : -1;
        int rank = kingSquare.rank() + direction;
        List<Square> result = new java.util.ArrayList<>();
        for (int f : new int[]{kingSquare.file() - 1, kingSquare.file(), kingSquare.file() + 1}) {
            if (!BoardMath.isValidFile(f)) continue;
            if (!BoardMath.isValidRank(rank)) continue;
            result.add(new Square(f, rank));
        }
        return result;
    }

    public static double evaluateOpenLinesTowardKing(Position position, Color color) {
        Square kingSq = position.kingSquare(color);
        double openLineScore = 0;
        for (int file = kingSq.file() - 1; file <= kingSq.file() + 1; file++) {
            if (!BoardMath.isValidFile(file)) continue;
            int ownPawns = countPawnsOnFile(position, file, color);
            int enemyPawns = countPawnsOnFile(position, file, color.opponent());
            if (ownPawns == 0 && enemyPawns == 0) {
                openLineScore += 1.0;
            } else if (ownPawns == 0) {
                openLineScore += 0.5;
            }
        }
        double diagonalExposure = countOpenDiagonalsFromKing(position, kingSq);
        return openLineScore + (diagonalExposure * 0.5);
    }

    public static int countPawnsOnFile(Position position, int file, Color color) {
        int count = 0;
        for (int rank : BoardConstants.ALL_RANKS) {
            PieceOnBoard piece = position.pieceAt(new Square(file, rank));
            if (piece != null && piece.type() == PieceType.PAWN && piece.color() == color) {
                count++;
            }
        }
        return count;
    }

    public static double countOpenDiagonalsFromKing(Position position, Square kingSq) {
        int[][] diagonals = {{1, 1}, {1, -1}, {-1, 1}, {-1, -1}};
        int openCount = 0;
        for (int[] d : diagonals) {
            int df = d[0], dr = d[1];
            Square sq = kingSq;
            boolean blocked = false;
            for (int step = 1; step <= 2; step++) {
                sq = new Square(sq.file() + df, sq.rank() + dr);
                if (!BoardMath.isValidSquare(sq)) break;
                if (position.pieceAt(sq) != null) {
                    blocked = true;
                    break;
                }
            }
            if (!blocked) openCount++;
        }
        return openCount / 4.0;
    }

    public static List<Square> getKingZoneSquares(Square kingSquare) {
        List<Square> zone = new java.util.ArrayList<>();
        zone.add(kingSquare);
        for (Direction d : BoardConstants.ALL_8_DIRECTIONS) {
            Square sq = new Square(kingSquare.file() + d.df(), kingSquare.rank() + d.dr());
            if (BoardMath.isValidSquare(sq)) zone.add(sq);
        }
        return zone;
    }

    public static double evaluateAttackerWeightNearKing(Position position, Color color) {
        List<Square> zone = getKingZoneSquares(position.kingSquare(color));
        double total = 0;
        for (Square sq : zone) {
            for (PieceAtSquare attacker : position.attackersOf(sq, color.opponent())) {
                total += attackerWeight(attacker.type());
            }
        }
        return total;
    }

    public static double evaluateDefenderWeightNearKing(Position position, Color color) {
        List<Square> zone = getKingZoneSquares(position.kingSquare(color));
        double total = 0;
        for (Square sq : zone) {
            for (PieceAtSquare defender : position.attackersOf(sq, color)) {
                total += defenderWeight(defender.type());
            }
        }
        return total;
    }

    public static double evaluateEnemyPieceProximity(Position position, Color color) {
        Square kingSq = position.kingSquare(color);
        double total = 0;
        for (PieceAtSquare p : position.piecesOf(color.opponent())) {
            if (p.type() == PieceType.KING) continue;
            int d = BoardMath.chebyshevDistance(kingSq, p.square());
            if (d == 0) continue;
            total += BoardConstants.PIECE_VALUES.get(p.type()) / (double) d;
        }
        return total;
    }

    public static boolean isKingUncastledMidgame(Position position, Color color) {
        Square kingSq = position.kingSquare(color);
        Square homeSquare = (color == Color.WHITE) ? new Square(4, 1) : new Square(4, 8); // e1 / e8
        return kingSq.file() == homeSquare.file() && kingSq.rank() == homeSquare.rank();
    }

    // ------------------------------------------------------------
    public static double calculateKingActivityScore(Position position, Color color) {
        Square kingSq = position.kingSquare(color);
        double centralization = CentralDistanceTable.get(kingSq);
        double mobility = countKingLegalSquares(position, kingSq, color) / 8.0 * 100;
        return BoardMath.clamp((centralization * 0.6) + (mobility * 0.4), 0, 100);
    }

    public static int countKingLegalSquares(Position position, Square kingSq, Color color) {
        int count = 0;
        for (Direction d : BoardConstants.ALL_8_DIRECTIONS) {
            Square sq = new Square(kingSq.file() + d.df(), kingSq.rank() + d.dr());
            if (BoardMath.isValidSquare(sq) && isSquareSafeForKing(position, sq, color)) {
                count++;
            }
        }
        return count;
    }

    public static boolean isSquareSafeForKing(Position position, Square square, Color color) {
        PieceOnBoard occupant = position.pieceAt(square);
        if (occupant != null && occupant.color() == color) return false;
        return !position.isSquareAttackedBy(square, color.opponent());
    }

    // ------------------------------------------------------------
    public static KingSafetyBars generateKingSafetyBars(Position position) {
        GamePhase gamePhase = GamePhaseModule.getGamePhase(position);
        double whiteScore = calculateKingSafetyScore(position, Color.WHITE, gamePhase);
        double blackScore = calculateKingSafetyScore(position, Color.BLACK, gamePhase);
        return new KingSafetyBars(
                new KingSafetyEntry(whiteScore, labelForSafety(whiteScore, gamePhase)),
                new KingSafetyEntry(blackScore, labelForSafety(blackScore, gamePhase)),
                gamePhase
        );
    }

    public static String labelForSafety(double score, GamePhase gamePhase) {
        if (gamePhase == GamePhase.ENDGAME) {
            return score > 70 ? "Active" : score > 40 ? "Passive" : "Cut off";
        }
        return score > 75 ? "Safe" : score > 45 ? "Slightly exposed" : "In danger";
    }

    /** Precomputed CENTRAL_DISTANCE_TABLE, lazily built once and cached. */
    private static final class CentralDistanceTable {
        private static final Map<String, Double> TABLE = build();

        private static Map<String, Double> build() {
            Map<String, Double> table = new HashMap<>();
            for (int file = 0; file <= 7; file++) {
                for (int rank = 1; rank <= 8; rank++) {
                    double distFromCenter = Math.max(Math.abs(file - 3.5), Math.abs(rank - 4.5));
                    table.put(new Square(file, rank).key(), (3.5 - distFromCenter) / 3.5 * 100);
                }
            }
            return table;
        }

        static double get(Square sq) {
            return TABLE.get(sq.key());
        }
    }
}
