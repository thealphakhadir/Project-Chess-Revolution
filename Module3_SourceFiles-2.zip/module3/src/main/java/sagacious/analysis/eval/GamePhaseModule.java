package sagacious.analysis.eval;

import sagacious.analysis.model.GamePhase;
import sagacious.analysis.model.PieceType;
import sagacious.analysis.model.PlacedPiece;
import sagacious.analysis.model.Position;
import sagacious.analysis.model.BoardConstants;

/** PART 5: GAME PHASE MODULE (complete). */
public final class GamePhaseModule {
    private GamePhaseModule() {}

    public static final int ENDGAME_MAX_MATERIAL = 13;
    public static final int OPENING_MAX_PLY = 10;
    public static final int OPENING_MATERIAL_FLOOR = 60;

    public static GamePhase getGamePhase(Position position) {
        int nonPawnMaterial = sumNonPawnMaterial(position);
        if (position.plyCount() <= OPENING_MAX_PLY && nonPawnMaterial >= OPENING_MATERIAL_FLOOR) {
            return GamePhase.OPENING;
        } else if (nonPawnMaterial <= ENDGAME_MAX_MATERIAL) {
            return GamePhase.ENDGAME;
        } else {
            return GamePhase.MIDDLEGAME;
        }
    }

    public static int sumNonPawnMaterial(Position position) {
        int total = 0;
        for (PlacedPiece piece : position.allPieces()) {
            if (piece.type() != PieceType.PAWN && piece.type() != PieceType.KING) {
                total += BoardConstants.PIECE_VALUES.get(piece.type());
            }
        }
        return total;
    }
}
