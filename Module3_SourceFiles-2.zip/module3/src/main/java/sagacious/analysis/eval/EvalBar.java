package sagacious.analysis.eval;

public record EvalBar(
        double whiteFillPercent,
        double blackFillPercent,
        String label,
        boolean isMate,
        boolean provisional,
        Integer numericValue
) {
    public EvalBar withWhiteFillPercent(double newWhiteFillPercent) {
        return new EvalBar(newWhiteFillPercent, 100 - newWhiteFillPercent, label, isMate, provisional, numericValue);
    }
}
