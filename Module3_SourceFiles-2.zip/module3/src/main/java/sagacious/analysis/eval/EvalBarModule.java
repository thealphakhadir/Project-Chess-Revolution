package sagacious.analysis.eval;

import sagacious.analysis.model.BoardMath;
import sagacious.analysis.search.RawSearchResult;
import sagacious.analysis.search.SearchResultLike;
import sagacious.analysis.shared.SearchSession;

import java.util.List;
import java.util.Locale;
import java.util.function.Consumer;

/** PART 3: EVAL BAR MODULE (complete). */
public final class EvalBarModule {
    private EvalBarModule() {}

    public static final double LOGISTIC_K = 0.00368208;
    public static final int CONFIDENCE_DEPTH_THRESHOLD = 12;

    /** Accepts RawSearchResult or SearchResult — both implement SearchResultLike. */
    public static EvalBar generateEvalBar(SearchResultLike result) {
        double fillPercent;
        String label;
        Integer numericValue;

        if (result.isMate()) {
            fillPercent = (result.mateIn() != null && result.mateIn() > 0) ? 100.0 : 0.0;
            label = "M" + Math.abs(result.mateIn() == null ? 0 : result.mateIn());
            numericValue = null;
        } else {
            int cp = result.centipawns();
            double winChance = 2.0 / (1.0 + Math.exp(-LOGISTIC_K * cp)) - 1.0;
            fillPercent = ((winChance + 1.0) / 2.0) * 100.0;
            label = formatEvalLabel(cp);
            numericValue = cp;
        }

        return new EvalBar(
                fillPercent,
                100.0 - fillPercent,
                label,
                result.isMate(),
                result.depthReached() < CONFIDENCE_DEPTH_THRESHOLD,
                numericValue
        );
    }

    public static String formatEvalLabel(int centipawns) {
        double pawns = centipawns / 100.0;
        String sign = pawns > 0 ? "+" : (pawns < 0 ? "-" : "");
        return sign + String.format(Locale.ROOT, "%.2f", Math.abs(pawns));
    }

    /**
     * Replays (or live-drives, if called while the session is still running)
     * a smoothed eval bar for every depth recorded on the session so far.
     */
    public static void streamEvalBarUpdates(SearchSession searchSession, Consumer<EvalBar> onUpdate) {
        EvalBar previousBar = null;
        List<Integer> depths = searchSession.depthSequence();
        for (int depth : depths) {
            RawSearchResult partial = searchSession.getResultAtDepth(depth);
            if (partial == null) continue; // depth was recorded then evicted/raced — skip defensively
            EvalBar bar = generateEvalBar(partial);
            if (previousBar != null) {
                bar = smoothBarTransition(previousBar, bar, depth);
            }
            onUpdate.accept(bar);
            previousBar = bar;
        }
    }

    public static EvalBar smoothBarTransition(EvalBar previousBar, EvalBar newBar, int depth) {
        double blendWeight = BoardMath.clamp((double) depth / CONFIDENCE_DEPTH_THRESHOLD, 0.0, 1.0);
        double blendedWhite = BoardMath.lerp(previousBar.whiteFillPercent(), newBar.whiteFillPercent(), blendWeight);
        return newBar.withWhiteFillPercent(blendedWhite);
    }
}
