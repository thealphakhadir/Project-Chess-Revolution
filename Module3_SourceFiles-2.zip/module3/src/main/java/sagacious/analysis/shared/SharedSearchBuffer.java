package sagacious.analysis.shared;

import java.lang.invoke.MethodHandles;
import java.lang.invoke.VarHandle;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/**
 * A fixed-layout block of off-heap memory shared between the worker thread
 * running the depth-iteration search loop and whichever thread is polling
 * for progress (UI thread, watchdog, etc.) — the Java analogue of JS's
 * SharedArrayBuffer + Atomics pair used for the same job (streaming
 * per-depth search progress without per-tick message/object allocation).
 *
 * Every slot is a 4-byte int accessed through a VarHandle in volatile mode
 * (getVolatile/setVolatile/compareAndSet), giving the same guarantee
 * Atomics.load/store/compareExchange give in JS: lock-free, wait-free
 * reads and writes with full cross-thread visibility, no torn reads.
 *
 * This buffer is deliberately NOT used to carry the full RawSearchResult
 * (Move/multiPV are reference types with no fixed-width representation) —
 * it carries only the hot-path scalars a UI polls at high frequency
 * (depth, centipawns, mate flag, interrupt flag, a version counter). The
 * full result object still flows back through the ordinary onStreamUpdate
 * callback once per depth; the buffer exists so a poller that wants
 * sub-callback-latency progress (e.g. a 60fps eval bar) doesn't have to
 * wait on the callback thread at all.
 */
public final class SharedSearchBuffer {

    // Slot indices (each slot is 4 bytes / one int)
    private static final int SLOT_DEPTH_REACHED = 0;
    private static final int SLOT_CENTIPAWNS = 1;
    private static final int SLOT_IS_MATE = 2;
    private static final int SLOT_MATE_IN = 3;
    private static final int SLOT_INTERRUPT_REQUESTED = 4;
    private static final int SLOT_VERSION = 5;
    private static final int SLOT_STATUS = 6;
    private static final int SLOT_COUNT = 8; // includes one padding slot

    /** Status codes for SLOT_STATUS. */
    public static final int STATUS_IDLE = 0;
    public static final int STATUS_RUNNING = 1;
    public static final int STATUS_COMPLETE = 2;
    public static final int STATUS_INTERRUPTED = 3;
    public static final int STATUS_ERROR = 4;

    private static final int NO_MATE_SENTINEL = Integer.MIN_VALUE;

    private final ByteBuffer buffer;
    private final VarHandle intView;

    public SharedSearchBuffer() {
        this.buffer = ByteBuffer.allocateDirect(SLOT_COUNT * Integer.BYTES).order(ByteOrder.nativeOrder());
        this.intView = MethodHandles.byteBufferViewVarHandle(int[].class, ByteOrder.nativeOrder());
        reset();
    }

    public void reset() {
        setSlot(SLOT_DEPTH_REACHED, 0);
        setSlot(SLOT_CENTIPAWNS, 0);
        setSlot(SLOT_IS_MATE, 0);
        setSlot(SLOT_MATE_IN, NO_MATE_SENTINEL);
        setSlot(SLOT_INTERRUPT_REQUESTED, 0);
        setSlot(SLOT_VERSION, 0);
        setSlot(SLOT_STATUS, STATUS_IDLE);
    }

    private void setSlot(int slot, int value) {
        intView.setVolatile(buffer, slot * Integer.BYTES, value);
    }

    private int getSlot(int slot) {
        return (int) intView.getVolatile(buffer, slot * Integer.BYTES);
    }

    /** Called by the worker thread after each completed depth iteration. */
    public void publishProgress(int depthReached, int centipawns, boolean isMate, Integer mateIn) {
        setSlot(SLOT_DEPTH_REACHED, depthReached);
        setSlot(SLOT_CENTIPAWNS, centipawns);
        setSlot(SLOT_IS_MATE, isMate ? 1 : 0);
        setSlot(SLOT_MATE_IN, mateIn == null ? NO_MATE_SENTINEL : mateIn);
        setSlot(SLOT_STATUS, STATUS_RUNNING);
        // Version increments last, after all fields are visible — a reader
        // that observes a new version is guaranteed to see the fields above
        // it (this ordering plus volatile semantics is what stands in for
        // Atomics' happens-before guarantee here).
        intView.getAndAdd(buffer, SLOT_VERSION * Integer.BYTES, 1);
    }

    public void markComplete() {
        setSlot(SLOT_STATUS, STATUS_COMPLETE);
        intView.getAndAdd(buffer, SLOT_VERSION * Integer.BYTES, 1);
    }

    public void markError() {
        setSlot(SLOT_STATUS, STATUS_ERROR);
        intView.getAndAdd(buffer, SLOT_VERSION * Integer.BYTES, 1);
    }

    /** Called by the consumer thread (e.g. a watchdog) to request cancellation. */
    public void requestInterrupt() {
        setSlot(SLOT_INTERRUPT_REQUESTED, 1);
    }

    /** Passed to searchWithVerification as its InterruptCheck. */
    public boolean isInterruptRequested() {
        return getSlot(SLOT_INTERRUPT_REQUESTED) != 0;
    }

    public int version() {
        return getSlot(SLOT_VERSION);
    }

    public int status() {
        return getSlot(SLOT_STATUS);
    }

    /** A one-shot, allocation-free snapshot read of the current progress. */
    public Snapshot snapshot() {
        int mateInRaw = getSlot(SLOT_MATE_IN);
        return new Snapshot(
                getSlot(SLOT_DEPTH_REACHED),
                getSlot(SLOT_CENTIPAWNS),
                getSlot(SLOT_IS_MATE) != 0,
                mateInRaw == NO_MATE_SENTINEL ? null : mateInRaw,
                getSlot(SLOT_STATUS),
                getSlot(SLOT_VERSION)
        );
    }

    public record Snapshot(int depthReached, int centipawns, boolean isMate, Integer mateIn, int status, int version) {
    }
}
