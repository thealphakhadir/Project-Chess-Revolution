package sagacious.analysis.shared;

import sagacious.analysis.search.SearchConfig;
import sagacious.analysis.search.SearchEngine;
import sagacious.analysis.search.SearchResult;

import java.util.concurrent.*;

/**
 * Part 0, reconciliation note 3: backup/failover analysis runs in a
 * dedicated worker via message-passing, never as a direct function call
 * from the watchdog handler on the main thread — calling it directly
 * would block the main thread at exactly the moment it's recovering from
 * a hang, the one time it most needs to stay responsive.
 *
 * "Message-passing" here means: the submitting thread hands off a request
 * to this class's own single-thread executor and returns immediately: the
 * request only ever actually executes on that dedicated thread.
 */
public final class BackupWorker implements AutoCloseable {

    private final SearchEngine engine;
    private final ExecutorService executor;

    public BackupWorker(SearchEngine engine) {
        this.engine = engine;
        this.executor = Executors.newSingleThreadExecutor(runnable -> {
            Thread t = new Thread(runnable, "sagacious-backup-worker");
            t.setDaemon(true);
            return t;
        });
    }

    /**
     * Posts a backup-analysis request and returns immediately. Safe to call
     * from a watchdog/interrupt handler on the main thread — this method
     * never runs requestBackupAnalysis itself, it only enqueues a message
     * for the dedicated backup thread to pick up.
     */
    public CompletableFuture<SearchResult> requestBackupAnalysis(String fen, SearchConfig config) {
        CompletableFuture<SearchResult> future = new CompletableFuture<>();
        try {
            executor.submit(() -> {
                try {
                    future.complete(engine.requestBackupAnalysis(fen, config));
                } catch (Exception e) {
                    future.completeExceptionally(e);
                }
            });
        } catch (RejectedExecutionException e) {
            future.completeExceptionally(e);
        }
        return future;
    }

    @Override
    public void close() {
        executor.shutdown();
        try {
            if (!executor.awaitTermination(5, TimeUnit.SECONDS)) executor.shutdownNow();
        } catch (InterruptedException e) {
            executor.shutdownNow();
            Thread.currentThread().interrupt();
        }
    }
}
