package sagacious.analysis.shared;

import sagacious.analysis.model.Position;
import sagacious.analysis.search.*;

import java.util.concurrent.*;
import java.util.function.Consumer;

/**
 * Part 0, reconciliation notes 1 & 2:
 *   - analyzePosition_v2 is split into searchWithVerification (runs per
 *     depth inside this loop, drives STREAM_UPDATE) and enrichSearchResult
 *     (runs once after the depth loop ends).
 *   - Single-position analysis goes through this pool too — there is
 *     exactly ONE path into the search engine, through a worker. Calling
 *     searchWithVerification directly from anywhere else would reintroduce
 *     the exact main-thread freeze this design exists to prevent.
 *
 * "Worker" here is a task submitted to a dedicated ExecutorService — the
 * Java analogue of a JS Web Worker (a real OS thread, not the caller's
 * thread), which is the property that actually matters: the caller gets
 * control back immediately and consumes progress via callback / shared
 * buffer / future, never by blocking inline.
 */
public final class AnalysisWorkerPool implements AutoCloseable {

    private final SearchEngine engine;
    private final ExecutorService executor;

    public AnalysisWorkerPool(SearchEngine engine) {
        this(engine, Math.max(1, Runtime.getRuntime().availableProcessors() - 1));
    }

    public AnalysisWorkerPool(SearchEngine engine, int poolSize) {
        this.engine = engine;
        this.executor = Executors.newFixedThreadPool(Math.max(1, poolSize), runnable -> {
            Thread t = new Thread(runnable, "sagacious-analysis-worker");
            t.setDaemon(true);
            return t;
        });
    }

    /**
     * Submits one position for analysis. Returns immediately with a
     * SearchSession; the actual search runs on a worker thread.
     *
     * onStreamUpdate is invoked once per completed depth, on the worker
     * thread — matching Part 0 note 1 ("runs per depth iteration inside
     * the worker loop, drives STREAM_UPDATE"). Keep it fast/non-blocking;
     * if a consumer wants zero-latency polling instead, use
     * session.sharedBuffer() rather than relying on this callback.
     */
    public SearchSession submit(Position position, SearchConfig config, Consumer<RawSearchResult> onStreamUpdate) {
        SearchSession session = new SearchSession();

        executor.submit(() -> runSession(position, config, onStreamUpdate, session));

        return session;
    }

    private void runSession(Position position, SearchConfig config, Consumer<RawSearchResult> onStreamUpdate,
                             SearchSession session) {
        SharedSearchBuffer buffer = session.sharedBuffer();
        RawSearchResult lastResult = null;

        try {
            for (int depth = 1; depth <= config.maxDepth(); depth++) {
                if (buffer.isInterruptRequested()) break;
                if (config.timeLimitMs() != null &&
                        (System.currentTimeMillis() - session.startTimeMs()) >= config.timeLimitMs()) {
                    break;
                }

                RawSearchResult raw = engine.searchWithVerification(
                        position, depth, Integer.MIN_VALUE + 1, Integer.MAX_VALUE - 1,
                        /* isRoot */ true, buffer::isInterruptRequested);
                raw = raw.withDepthReached(depth);
                lastResult = raw;

                session.recordDepthResult(raw);
                buffer.publishProgress(raw.depthReached(), raw.centipawns(), raw.isMate(), raw.mateIn());
                if (onStreamUpdate != null) onStreamUpdate.accept(raw);

                if (raw.isMate()) break; // found forced mate — no need to search deeper
            }

            SearchResult finalResult;
            if (lastResult == null) {
                // Interrupted or timed out before depth 1 ever completed.
                buffer.markComplete();
                session.finalResult().completeExceptionally(
                        new IllegalStateException("Search produced no result (interrupted or timed out before depth 1)"));
                return;
            }

            if (config.skipEnrichment()) {
                // Part 0 note 4: fast-pass game review skips enrichment entirely.
                finalResult = new SearchResult(lastResult, java.util.List.of(), java.util.List.of(),
                        null, null, null, 0.0);
            } else {
                finalResult = engine.enrichSearchResult(position, lastResult, config, config.gameHistory());
            }

            buffer.markComplete();
            session.finalResult().complete(finalResult);

        } catch (Exception e) {
            buffer.markError();
            session.finalResult().completeExceptionally(e);
        }
    }

    @Override
    public void close() {
        executor.shutdown();
        try {
            if (!executor.awaitTermination(5, TimeUnit.SECONDS)) {
                executor.shutdownNow();
            }
        } catch (InterruptedException e) {
            executor.shutdownNow();
            Thread.currentThread().interrupt();
        }
    }
}
