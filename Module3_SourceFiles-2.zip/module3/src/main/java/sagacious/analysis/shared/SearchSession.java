package sagacious.analysis.shared;

import sagacious.analysis.search.RawSearchResult;
import sagacious.analysis.search.SearchResult;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.CompletableFuture;

/**
 * Handle for one in-flight (or completed) analysis, returned immediately
 * by AnalysisWorkerPool.submit(). Gives a caller three ways to consume
 * progress, matching the different consumers in the design doc:
 *
 *   1. sharedBuffer  — lock-free scalar polling (Part 3's high-frequency
 *      eval-bar-at-60fps case), no allocation, no callback-thread wait.
 *   2. depthSequence()/getResultAtDepth() — the query API Part 3's
 *      streamEvalBarUpdates() is written against, usable live or as a
 *      replay after the search finishes.
 *   3. finalResult — a CompletableFuture<SearchResult> for "just give me
 *      the finished, enriched result."
 */
public final class SearchSession implements sagacious.analysis.api.Cancellable {
    private final SharedSearchBuffer sharedBuffer = new SharedSearchBuffer();
    private final List<RawSearchResult> depthHistory = Collections.synchronizedList(new ArrayList<>());
    private final CompletableFuture<SearchResult> finalResult = new CompletableFuture<>();
    private final long startTimeMs = System.currentTimeMillis();

    public SharedSearchBuffer sharedBuffer() {
        return sharedBuffer;
    }

    public CompletableFuture<SearchResult> finalResult() {
        return finalResult;
    }

    public long startTimeMs() {
        return startTimeMs;
    }

    /** Called by the worker thread after each completed depth iteration. */
    void recordDepthResult(RawSearchResult result) {
        depthHistory.add(result);
    }

    /** searchSession.depthSequence from Part 3's streamEvalBarUpdates. */
    public List<Integer> depthSequence() {
        synchronized (depthHistory) {
            List<Integer> depths = new ArrayList<>(depthHistory.size());
            for (RawSearchResult r : depthHistory) depths.add(r.depthReached());
            return depths;
        }
    }

    /** searchSession.getResultAtDepth(depth) from Part 3's streamEvalBarUpdates. */
    public RawSearchResult getResultAtDepth(int depth) {
        synchronized (depthHistory) {
            for (RawSearchResult r : depthHistory) {
                if (r.depthReached() == depth) return r;
            }
        }
        return null;
    }

    /** Request cooperative cancellation — checked by searchWithVerification via InterruptCheck. */
    public void cancel() {
        sharedBuffer.requestInterrupt();
    }
}
