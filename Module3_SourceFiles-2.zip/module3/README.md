# Module 3 — Constructive Analysis (Sagacious)

Java port of the "Constructive Analysis: Full Build" design doc, complete
except for the six search-internals functions you're supplying separately
(board representation, NNUE eval, pruning/verification search — Part 2).
Every one of those six is stubbed with a `NotImplementedException` naming
exactly what's missing, so anything that exercises them before they land
fails loudly and specifically instead of silently.

## Layout

    src/main/java/sagacious/analysis/
      model/    Part 1  — board primitives (Square, Move, Position, etc.)
      search/   Part 2  — the SearchEngine contract (6 stubs) + result types
      shared/   Part 0  — worker pool, shared-memory buffer, backup worker
      config/   Part 6  — tier config
      eval/     Parts 3–5 — eval bar, king safety, game phase (all complete)
      api/      Part 7  — top-level constructiveAnalysis() API

    src/test/java/...  — mirrors the same packages; 78 tests, all passing

## Building it yourself

No build file is included (no Maven/Gradle wrapper) since I don't know
which you're using — drop `src/main/java` into your existing build, or
compile directly:

    javac -d out $(find src/main/java -name '*.java')
    javac -cp out -d out-test $(find src/test/java -name '*.java')
    java -cp out:out-test sagacious.analysis.api.ConstructiveAnalysisTest

(Requires JDK 17+ for records/sealed interfaces; developed against JDK 21.)

## Worth knowing before you wire in the real search internals

**The shared-array-buffer piece.** `shared/SharedSearchBuffer.java` is a
direct (off-heap) `ByteBuffer` + `VarHandle` construct — Java's actual
analogue to JS's `SharedArrayBuffer` + `Atomics`. It carries only the
hot-path scalars (depth, centipawns, mate flag, interrupt flag, a version
counter) for lock-free, allocation-free polling; the full result object
still flows through the ordinary `onStreamUpdate` callback once per depth.
I didn't just write this and assume it's right — I ran it across real
worker + poller threads (`SharedSearchBufferTest`) and checked for
monotonicity violations and visibility gaps. 14/14 passed.

**`requestAnalysis` and `reviewFullGame`** are called by Part 7 of your
doc but never defined anywhere in it. I built both against Part 0's
reconciliation notes rather than literal pseudocode (which doesn't exist
for these two) — worth your own review before you trust them the way you
can trust the parts that were a direct port. `reviewFullGame` in
particular makes a judgment call your doc doesn't spell out: fast
unenriched pass over every move, then a deep enriched + backup-corroborated
dive only on plies that trip `identifyCriticalMoments` or get classified
as a `BLUNDER` — not full depth+enrichment+backup on every move. See the
doc comment on `GameReviewResult` for the reasoning.

**One bug I found and fixed via testing, not review.** My first draft of
`reviewFullGame`'s backup-corroboration step caught `NotImplementedException`
directly around a `CompletableFuture.get()` call — but `.get()` on a future
that completed exceptionally wraps the real cause in `ExecutionException`,
so that catch never matched. The practical effect: with the backup engine
in its current, genuinely-unimplemented state, every deep dive was silently
dropping its already-successful primary result along with the failed
backup call. A targeted test against a realistic "only the backup stub is
missing" engine (`BackupStubRealismTest`) caught it; fixed by catching the
failure broadly instead of by the unwrapped type. Both the regression test
and the original suite pass now — flagging this so you know it was caught
by execution, not left for you to find.

**One spec gap filled in, flagged, not guessed silently.** Your doc's
`CRITICAL_MOMENT_CONFIG` cuts off mid-definition — `SAFETY_THRESHOLD` has
no value. `api/CriticalMomentConfig.java` documents the reasoning for the
placeholder (15, on the same 0–100 scale as king-safety scores) right next
to the constant; replace it once real games make the right number clear.
