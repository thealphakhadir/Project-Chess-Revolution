package org.openchess.explorer.eco;

import org.openchess.explorer.board.BoardAdapter;
import org.openchess.explorer.board.Move;
import org.openchess.explorer.model.OpeningRecord;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Real, board-position-based opening identification: every ECO line in the
 * book is replayed move-by-move through the rules engine at startup, and the
 * RESULTING POSITION (not the move text) is used as the lookup key. Two
 * openings — or two move orders into the same opening — that transpose into
 * an identical position end up under the same key here, which is what makes
 * opening ID actually transposition-aware rather than just matching move
 * sequences textually (see {@link EcoOpeningBook#identify} for the
 * text-based version, which this supersedes for identification but which
 * remains useful for "book move order" display).
 */
public final class TranspositionIndex {

    private static final Logger LOG = Logger.getLogger(TranspositionIndex.class.getName());

    private final Map<String, List<OpeningRecord>> byPositionKey;

    private TranspositionIndex(Map<String, List<OpeningRecord>> byPositionKey) {
        this.byPositionKey = byPositionKey;
    }

    public static TranspositionIndex build(EcoOpeningBook book, Supplier<BoardAdapter> startingPositionFactory) {
        Map<String, List<OpeningRecord>> map = new HashMap<>();
        int skipped = 0;
        for (OpeningRecord record : book.allRecords()) {
            if (record.plyLength() == 0) continue; // e.g. A00's "anything else" entry has no fixed line
            try {
                BoardAdapter b = startingPositionFactory.get();
                for (String san : record.sanLine()) {
                    Move m = b.findMoveBySan(san);
                    b = b.playMove(m);
                }
                map.computeIfAbsent(b.positionKey(), k -> new ArrayList<>()).add(record);
            } catch (RuntimeException e) {
                // Defensive: a malformed line in the source data (or a rules-engine edge
                // case) shouldn't take down startup. Skip that one record and keep going.
                skipped++;
                LOG.log(Level.FINE, "Skipped ECO line " + record.ecoCode() + " while building transposition index", e);
            }
        }
        if (skipped > 0) {
            LOG.log(Level.WARNING, "TranspositionIndex: skipped {0} ECO line(s) that failed to replay; "
                    + "those codes still work via direct lookup, just not via transposition matching.", skipped);
        }
        return new TranspositionIndex(map);
    }

    /** All openings on record whose defining line resolves to this exact board position, however it was reached. */
    public List<OpeningRecord> lookup(String positionKey) {
        return byPositionKey.getOrDefault(positionKey, List.of());
    }

    public int indexedPositionCount() { return byPositionKey.size(); }
}
