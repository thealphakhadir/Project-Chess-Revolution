package org.openchess.explorer.model;

import java.util.Collections;
import java.util.List;

/**
 * One entry from the ECO reference book (see {@code eco/EcoOpeningBook.java}),
 * sourced from the project's full ECO openings document (A00-E99).
 */
public final class OpeningRecord {

    private final String ecoCode;      // e.g. "C89"
    private final List<String> sanLine; // defining move sequence in SAN, e.g. [e4, e5, Nf3, ...]
    private final String name;         // e.g. "Ruy Lopez, Marshall Attack"
    private final String family;       // e.g. "Ruy Lopez, Marshall Attack" family header this code rolls up to

    public OpeningRecord(String ecoCode, List<String> sanLine, String name, String family) {
        this.ecoCode = ecoCode;
        this.sanLine = Collections.unmodifiableList(sanLine);
        this.name = name;
        this.family = family;
    }

    public String ecoCode() { return ecoCode; }
    public List<String> sanLine() { return sanLine; }
    public String name() { return name; }
    public String family() { return family; }
    public int plyLength() { return sanLine.size(); }

    @Override
    public String toString() {
        return ecoCode + " " + name;
    }
}
