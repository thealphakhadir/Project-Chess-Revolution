package org.openchess.explorer.model;

/**
 * Which statistics pool a query (or a merged result) draws from.
 * Mirrors the "Masters / Online / Personal" tab split found in real
 * opening explorers.
 */
public enum DataSourceType {
    /** Over-the-board games by titled/strong players ("more correct" theory). */
    MASTERS,
    /** Bulk online play (Lichess, Chess.com, etc.) — practical, huge sample size. */
    ONLINE,
    /** A specific player's own games — self-prep or opponent-prep. */
    PERSONAL
}
