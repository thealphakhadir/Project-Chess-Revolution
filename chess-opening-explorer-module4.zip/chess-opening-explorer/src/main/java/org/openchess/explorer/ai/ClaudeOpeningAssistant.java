package org.openchess.explorer.ai;

import org.openchess.explorer.model.DataSourceType;
import org.openchess.explorer.model.MoveStat;
import org.openchess.explorer.model.OpeningRecord;
import org.openchess.explorer.tree.PositionContext;
import org.openchess.explorer.util.Json;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.*;

/**
 * Claude AI integration: turns the explorer's structured data (opening ID,
 * move statistics, engine eval) into plain-English coaching commentary, and
 * answers free-form questions about the current position. Talks to the
 * Claude Messages API directly (https://api.anthropic.com/v1/messages) —
 * no SDK dependency, just {@code java.net.http}.
 *
 * Requires an API key: pass one to the constructor, or set the
 * {@code ANTHROPIC_API_KEY} environment variable (the same convention the
 * official SDKs use). Get a key at https://console.anthropic.com. Default
 * model is {@code claude-sonnet-5}; pass a different model string to the
 * constructor to change it (e.g. {@code claude-haiku-4-5-20251001} for
 * faster/cheaper short commentary). Model names and the request/response
 * shape are per Anthropic's published API docs as of this writing —
 * reconfirm against https://docs.claude.com/en/api/overview if this stops
 * working, since model lineups do change over time.
 */
public final class ClaudeOpeningAssistant {

    private static final String API_URL = "https://api.anthropic.com/v1/messages";
    private static final String ANTHROPIC_VERSION = "2023-06-01";
    private static final Duration TIMEOUT = Duration.ofSeconds(30);

    private final String apiKey;
    private final String model;
    private final HttpClient http;

    public ClaudeOpeningAssistant() {
        this(System.getenv("ANTHROPIC_API_KEY"), "claude-sonnet-5");
    }

    public ClaudeOpeningAssistant(String apiKey, String model) {
        if (apiKey == null || apiKey.isBlank()) {
            throw new IllegalStateException(
                    "No Anthropic API key found. Pass one explicitly or set ANTHROPIC_API_KEY.");
        }
        this.apiKey = apiKey;
        this.model = model;
        this.http = HttpClient.newBuilder().connectTimeout(TIMEOUT).build();
    }

    /** Plain-English explanation of an opening's typical plans, piece placement, and pawn structure. */
    public String explainOpening(OpeningRecord record) {
        String prompt = """
                You are a chess coach. In 3-5 sentences, explain the opening below to an
                improving club player: the key strategic ideas, typical plans for both
                sides, and one common trap or tactical motif to watch for. Be concrete,
                not generic.

                ECO code: %s
                Name: %s
                Moves: %s
                """.formatted(record.ecoCode(), record.name(), String.join(" ", record.sanLine()));
        return call(prompt);
    }

    /**
     * Explains the CURRENT candidate moves in plain English, referencing the
     * actual statistics passed in (so the model reasons about real numbers,
     * not invented ones) — e.g. why a move is popular despite a lower score,
     * or why masters prefer one line while online players prefer another.
     */
    public String explainCandidateMoves(PositionContext context, Map<DataSourceType, List<MoveStat>> statsBySource) {
        StringBuilder data = new StringBuilder();
        data.append("Position (FEN): ").append(context.position().toFen()).append("\n");
        context.identifiedOpening().ifPresent(o ->
                data.append("Identified opening: ").append(o.ecoCode()).append(" ").append(o.name()).append("\n"));
        if (context.isTransposition()) {
            data.append("Also reachable via transposition from: ");
            for (OpeningRecord r : context.alsoReachedByTransposition()) {
                data.append(r.ecoCode()).append(" ").append(r.name()).append("; ");
            }
            data.append("\n");
        }
        for (var entry : statsBySource.entrySet()) {
            data.append(entry.getKey()).append(" data:\n");
            for (MoveStat s : entry.getValue()) {
                data.append(String.format("  %s: %d games, W/D/B %.0f%%/%.0f%%/%.0f%%, avg rating %s%n",
                        s.sanMove(), s.totalGames(), s.whitePct(), s.drawPct(), s.blackPct(),
                        s.averageRating() == null ? "n/a" : String.format("%.0f", s.averageRating())));
            }
        }

        String prompt = """
                You are a chess coach reviewing real opening-database statistics with a
                student. Using ONLY the data below (do not invent numbers), write a short
                (4-6 sentence) practical take: which move(s) you'd recommend for a club
                player and why, noting any interesting gap between what's popular and
                what scores well, or between what masters play and what online players
                play, if the data shows one.

                %s
                """.formatted(data);
        return call(prompt);
    }

    /** Free-form Q&A about the current position — "why not Nc3 here?", "what's Black's plan?", etc. */
    public String answerQuestion(String question, PositionContext context) {
        String openingLine = context.identifiedOpening()
                .map(o -> o.ecoCode() + " " + o.name()).orElse("not a named ECO line");
        String prompt = """
                You are a chess coach. The student is looking at this position and asks
                a question. Answer concretely and concisely (this is a chat reply, not
                an essay).

                Position (FEN): %s
                Moves played: %s
                Opening: %s

                Student's question: %s
                """.formatted(context.position().toFen(), String.join(" ", context.sanPathFromStart()),
                openingLine, question);
        return call(prompt);
    }

    // ------------------------------------------------------------------

    private String call(String userPrompt) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("model", model);
        body.put("max_tokens", 700);
        body.put("messages", List.of(Map.of("role", "user", "content", userPrompt)));

        try {
            HttpRequest req = HttpRequest.newBuilder(URI.create(API_URL))
                    .timeout(TIMEOUT)
                    .header("x-api-key", apiKey)
                    .header("anthropic-version", ANTHROPIC_VERSION)
                    .header("content-type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(Json.writeObject(body)))
                    .build();
            HttpResponse<String> resp = http.send(req, HttpResponse.BodyHandlers.ofString());
            Map<String, Object> json = Json.parseObject(resp.body());
            if (resp.statusCode() != 200) {
                Map<String, Object> error = Json.mapVal(json, "error");
                String message = error == null ? resp.body() : Json.str(error, "message");
                throw new RuntimeException("Claude API error (" + resp.statusCode() + "): " + message);
            }
            List<Object> content = Json.listVal(json, "content");
            StringBuilder out = new StringBuilder();
            for (Object block : content) {
                @SuppressWarnings("unchecked")
                Map<String, Object> b = (Map<String, Object>) block;
                if ("text".equals(Json.str(b, "type"))) {
                    out.append(Json.str(b, "text"));
                }
            }
            return out.toString();
        } catch (IOException | InterruptedException e) {
            if (e instanceof InterruptedException) Thread.currentThread().interrupt();
            throw new RuntimeException("Failed to reach Claude API: " + e.getMessage(), e);
        }
    }
}
