package org.openchess.explorer.engine;

import org.openchess.explorer.board.BoardAdapter;
import org.openchess.explorer.model.EvaluationResult;

/**
 * Engine evaluation integration — lets the explorer show "objectively best"
 * alongside "popular / practically successful". Any UCI-compatible engine
 * (Stockfish, Leela via lc0, etc.) can sit behind this; see
 * {@link StockfishUciAdapter} for a ready implementation.
 */
public interface EngineAdapter extends AutoCloseable {

    /** Evaluate a position to a given search depth (plies), blocking until the engine reports "bestmove". */
    EvaluationResult evaluate(BoardAdapter position, int depth);

    String engineName();

    @Override
    void close();
}
