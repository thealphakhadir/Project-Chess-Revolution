package org.openchess.explorer.engine;

import org.openchess.explorer.board.BoardAdapter;
import org.openchess.explorer.board.Move;
import org.openchess.explorer.model.EvaluationResult;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Drives a Stockfish (or any UCI-compatible engine) process over stdin/stdout
 * for position evaluation. Stockfish itself is not bundled — point this at
 * a local binary (download from https://stockfishchess.org/download/, free
 * and open source) via the constructor path or the {@code STOCKFISH_PATH}
 * environment variable.
 *
 * Not thread-safe: one adapter drives one engine process; if you need
 * concurrent evaluations, construct one adapter per worker thread (they're
 * cheap to spin up, or pool them yourself).
 */
public final class StockfishUciAdapter implements EngineAdapter {

    private static final Pattern SCORE_CP = Pattern.compile("score cp (-?\\d+)");
    private static final Pattern SCORE_MATE = Pattern.compile("score mate (-?\\d+)");
    private static final Pattern DEPTH = Pattern.compile("(?:^|\\s)depth (\\d+)");
    private static final Pattern PV = Pattern.compile(" pv (.+)$");

    private final Process process;
    private final BufferedReader stdout;
    private final Writer stdin;
    private final String engineName;

    public static StockfishUciAdapter fromEnvOrPath(String fallbackPath) throws IOException {
        String path = System.getenv("STOCKFISH_PATH");
        return new StockfishUciAdapter(path != null ? path : fallbackPath);
    }

    public StockfishUciAdapter(String executablePath) throws IOException {
        ProcessBuilder pb = new ProcessBuilder(executablePath);
        pb.redirectErrorStream(true);
        this.process = pb.start();
        this.stdout = new BufferedReader(new InputStreamReader(process.getInputStream(), StandardCharsets.UTF_8));
        this.stdin = new OutputStreamWriter(process.getOutputStream(), StandardCharsets.UTF_8);
        send("uci");
        waitFor("uciok");
        send("isready");
        waitFor("readyok");
        this.engineName = executablePath;
    }

    @Override
    public String engineName() { return engineName; }

    @Override
    public EvaluationResult evaluate(BoardAdapter position, int depth) {
        try {
            send("position fen " + position.toFen());
            send("go depth " + depth);

            String lastInfoWithScore = null;
            int lastDepthSeen = 0;
            String line;
            while ((line = stdout.readLine()) != null) {
                if (line.startsWith("info") && (line.contains("score cp") || line.contains("score mate"))) {
                    Matcher dm = DEPTH.matcher(line);
                    int d = dm.find() ? Integer.parseInt(dm.group(1)) : lastDepthSeen;
                    if (d >= lastDepthSeen) {
                        lastDepthSeen = d;
                        lastInfoWithScore = line;
                    }
                }
                if (line.startsWith("bestmove")) break;
            }

            if (lastInfoWithScore == null) {
                return new EvaluationResult(0, null, 0, List.of(), engineName);
            }
            return parseInfoLine(lastInfoWithScore, position);
        } catch (IOException e) {
            throw new RuntimeException("Engine I/O failure: " + e.getMessage(), e);
        }
    }

    private EvaluationResult parseInfoLine(String infoLine, BoardAdapter fromPosition) {
        Integer mateIn = null;
        int cp = 0;
        Matcher mm = SCORE_MATE.matcher(infoLine);
        if (mm.find()) {
            mateIn = Integer.parseInt(mm.group(1));
        } else {
            Matcher cm = SCORE_CP.matcher(infoLine);
            if (cm.find()) cp = Integer.parseInt(cm.group(1));
        }
        Matcher dm = DEPTH.matcher(infoLine);
        int depth = dm.find() ? Integer.parseInt(dm.group(1)) : 0;

        List<String> pvSan = new ArrayList<>();
        Matcher pm = PV.matcher(infoLine);
        if (pm.find()) {
            String[] uciMoves = pm.group(1).trim().split("\\s+");
            BoardAdapter b = fromPosition;
            for (String uci : uciMoves) {
                Move match = findByUci(b, uci);
                if (match == null) break; // engine PV outran a rule we don't model (shouldn't happen for legal chess)
                b = b.playMove(match);
                pvSan.add(match.san());
            }
        }
        return new EvaluationResult(cp, mateIn, depth, pvSan, engineName);
    }

    private Move findByUci(BoardAdapter b, String uci) {
        for (Move m : b.legalMoves()) {
            if (m.uci().equalsIgnoreCase(uci)) return m;
        }
        return null;
    }

    private void send(String command) throws IOException {
        stdin.write(command);
        stdin.write("\n");
        stdin.flush();
    }

    private void waitFor(String token) throws IOException {
        String line;
        while ((line = stdout.readLine()) != null) {
            if (line.contains(token)) return;
        }
    }

    @Override
    public void close() {
        try {
            send("quit");
        } catch (IOException ignored) {
            // process may already be gone
        } finally {
            process.destroy();
        }
    }
}
