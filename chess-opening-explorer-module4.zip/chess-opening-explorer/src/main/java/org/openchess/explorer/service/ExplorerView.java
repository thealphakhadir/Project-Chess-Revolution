package org.openchess.explorer.service;

import org.openchess.explorer.model.DataSourceType;
import org.openchess.explorer.model.EvaluationResult;
import org.openchess.explorer.model.GameSample;
import org.openchess.explorer.tree.PositionContext;

import java.util.List;
import java.util.Map;

/**
 * Everything the explorer knows about one position, ready to hand to a UI:
 * opening identification, every candidate move with stats and repertoire
 * status, sample games, and (if an engine was configured) an evaluation.
 * AI commentary is deliberately NOT included here — see
 * {@link OpeningExplorerService#explainWithAi} — so that browsing positions
 * never silently triggers API calls; you ask for commentary explicitly.
 */
public final class ExplorerView {

    private final PositionContext positionContext;
    private final List<CandidateMoveView> candidateMoves;
    private final Map<DataSourceType, List<GameSample>> sampleGamesBySource;
    private final EvaluationResult engineEvaluation; // null if no engine configured/available

    public ExplorerView(PositionContext positionContext, List<CandidateMoveView> candidateMoves,
                         Map<DataSourceType, List<GameSample>> sampleGamesBySource, EvaluationResult engineEvaluation) {
        this.positionContext = positionContext;
        this.candidateMoves = candidateMoves;
        this.sampleGamesBySource = sampleGamesBySource;
        this.engineEvaluation = engineEvaluation;
    }

    public PositionContext positionContext() { return positionContext; }
    public List<CandidateMoveView> candidateMoves() { return candidateMoves; }
    public Map<DataSourceType, List<GameSample>> sampleGamesBySource() { return sampleGamesBySource; }
    public EvaluationResult engineEvaluation() { return engineEvaluation; }
}
