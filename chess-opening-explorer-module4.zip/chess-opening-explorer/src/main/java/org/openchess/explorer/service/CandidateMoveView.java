package org.openchess.explorer.service;

import org.openchess.explorer.model.DataSourceType;
import org.openchess.explorer.model.MoveStat;

import java.util.Map;

/** One legal move from the current position, annotated with stats and repertoire status for display. */
public final class CandidateMoveView {

    private final String san;
    private final String uci;
    private final Map<DataSourceType, MoveStat> statsBySource; // may be missing entries if a source had no data
    private final MoveStat merged; // blended across all queried sources, or null if none had data
    private final boolean inOwnRepertoire;
    private final String repertoireLabel; // which saved line this move belongs to, if any

    public CandidateMoveView(String san, String uci, Map<DataSourceType, MoveStat> statsBySource,
                              MoveStat merged, boolean inOwnRepertoire, String repertoireLabel) {
        this.san = san;
        this.uci = uci;
        this.statsBySource = statsBySource;
        this.merged = merged;
        this.inOwnRepertoire = inOwnRepertoire;
        this.repertoireLabel = repertoireLabel;
    }

    public String san() { return san; }
    public String uci() { return uci; }
    public Map<DataSourceType, MoveStat> statsBySource() { return statsBySource; }
    public MoveStat merged() { return merged; }
    public boolean inOwnRepertoire() { return inOwnRepertoire; }
    public String repertoireLabel() { return repertoireLabel; }

    public long popularityGames() { return merged == null ? 0 : merged.totalGames(); }
}
