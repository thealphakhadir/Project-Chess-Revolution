package org.openchess.explorer.model;

import java.time.YearMonth;
import java.util.EnumSet;
import java.util.Set;

/**
 * Filter criteria applied to a statistics query. Immutable; build via
 * {@link Builder}. Any provider is free to ignore a field it doesn't
 * support (e.g. a local PGN store might ignore rating buckets) — providers
 * document which filters they honor.
 */
public final class QueryFilter {

    public static final QueryFilter NONE = new Builder().build();

    private final Integer minRating;
    private final Integer maxRating;
    private final Set<TimeControl> timeControls;
    private final YearMonth since;
    private final YearMonth until;
    private final Color colorOfInterest; // which side's move stats we care about; null = both
    private final String ecoCodeFilter;  // restrict to a specific ECO code/prefix, null = no restriction
    private final String playerName;     // for PERSONAL source

    private QueryFilter(Builder b) {
        this.minRating = b.minRating;
        this.maxRating = b.maxRating;
        this.timeControls = b.timeControls.isEmpty()
                ? EnumSet.allOf(TimeControl.class)
                : EnumSet.copyOf(b.timeControls);
        this.since = b.since;
        this.until = b.until;
        this.colorOfInterest = b.colorOfInterest;
        this.ecoCodeFilter = b.ecoCodeFilter;
        this.playerName = b.playerName;
    }

    public Integer minRating() { return minRating; }
    public Integer maxRating() { return maxRating; }
    public Set<TimeControl> timeControls() { return timeControls; }
    public YearMonth since() { return since; }
    public YearMonth until() { return until; }
    public Color colorOfInterest() { return colorOfInterest; }
    public String ecoCodeFilter() { return ecoCodeFilter; }
    public String playerName() { return playerName; }

    public boolean hasRatingBounds() { return minRating != null || maxRating != null; }

    public static Builder builder() { return new Builder(); }

    public static final class Builder {
        private Integer minRating;
        private Integer maxRating;
        private final Set<TimeControl> timeControls = EnumSet.noneOf(TimeControl.class);
        private YearMonth since;
        private YearMonth until;
        private Color colorOfInterest;
        private String ecoCodeFilter;
        private String playerName;

        public Builder ratingRange(int min, int max) { this.minRating = min; this.maxRating = max; return this; }
        public Builder minRating(int min) { this.minRating = min; return this; }
        public Builder maxRating(int max) { this.maxRating = max; return this; }
        public Builder timeControl(TimeControl tc) { this.timeControls.add(tc); return this; }
        public Builder timeControls(Set<TimeControl> tcs) { this.timeControls.addAll(tcs); return this; }
        public Builder since(YearMonth ym) { this.since = ym; return this; }
        public Builder until(YearMonth ym) { this.until = ym; return this; }
        public Builder color(Color c) { this.colorOfInterest = c; return this; }
        public Builder ecoCode(String eco) { this.ecoCodeFilter = eco; return this; }
        public Builder player(String name) { this.playerName = name; return this; }

        public QueryFilter build() { return new QueryFilter(this); }
    }
}
