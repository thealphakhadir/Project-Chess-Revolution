package org.openchess.explorer.repertoire;

import org.openchess.explorer.model.Color;

import java.util.Collections;
import java.util.List;

/** One saved line in a personal repertoire: a move sequence the player intends to play, plus notes. */
public final class RepertoireEntry {

    private final String id;
    private final String label;         // e.g. "My Najdorf vs 6.Bg5"
    private final Color forColor;       // which side this line is prepared for
    private final List<String> sanMoves;
    private final String notes;

    public RepertoireEntry(String id, String label, Color forColor, List<String> sanMoves, String notes) {
        this.id = id;
        this.label = label;
        this.forColor = forColor;
        this.sanMoves = Collections.unmodifiableList(sanMoves);
        this.notes = notes;
    }

    public String id() { return id; }
    public String label() { return label; }
    public Color forColor() { return forColor; }
    public List<String> sanMoves() { return sanMoves; }
    public String notes() { return notes; }

    /** True if {@code playedSoFar} is consistent with (a prefix of, or equal to) this line. */
    public boolean matches(List<String> playedSoFar) {
        int n = Math.min(playedSoFar.size(), sanMoves.size());
        return sanMoves.subList(0, n).equals(playedSoFar.subList(0, n));
    }

    /** The next move this repertoire line recommends after {@code playedSoFar}, or null if past the end of the line. */
    public String nextMoveAfter(List<String> playedSoFar) {
        if (!matches(playedSoFar) || playedSoFar.size() >= sanMoves.size()) return null;
        return sanMoves.get(playedSoFar.size());
    }
}
