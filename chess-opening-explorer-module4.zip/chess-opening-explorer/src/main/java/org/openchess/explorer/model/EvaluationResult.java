package org.openchess.explorer.model;

import java.util.Collections;
import java.util.List;

/** Output of a UCI engine's analysis of a position (see the {@code engine} package). */
public final class EvaluationResult {

    private final int centipawns;      // from White's perspective; ignored if mateIn != null
    private final Integer mateIn;      // plies to mate, signed (negative = losing side is White), null if no mate seen
    private final int depth;
    private final List<String> principalVariationSan;
    private final String engineName;

    public EvaluationResult(int centipawns, Integer mateIn, int depth,
                             List<String> principalVariationSan, String engineName) {
        this.centipawns = centipawns;
        this.mateIn = mateIn;
        this.depth = depth;
        this.principalVariationSan = Collections.unmodifiableList(principalVariationSan);
        this.engineName = engineName;
    }

    public int centipawns() { return centipawns; }
    public Integer mateIn() { return mateIn; }
    public boolean isMateScore() { return mateIn != null; }
    public int depth() { return depth; }
    public List<String> principalVariationSan() { return principalVariationSan; }
    public String engineName() { return engineName; }

    public String humanScore() {
        if (mateIn != null) {
            return "#" + mateIn;
        }
        return String.format("%+.2f", centipawns / 100.0);
    }

    @Override
    public String toString() {
        return String.format("[%s d%d] %s  PV: %s", engineName, depth, humanScore(),
                String.join(" ", principalVariationSan));
    }
}
