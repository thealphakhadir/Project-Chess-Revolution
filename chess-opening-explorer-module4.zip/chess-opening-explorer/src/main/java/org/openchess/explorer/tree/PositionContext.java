package org.openchess.explorer.tree;

import org.openchess.explorer.board.BoardAdapter;
import org.openchess.explorer.board.Move;
import org.openchess.explorer.model.OpeningRecord;

import java.util.List;
import java.util.Optional;

/**
 * Everything the explorer knows about "where you are" before statistics
 * even enter the picture: the position itself, its identified opening
 * (transposition-aware), any other named openings that also transpose to
 * this exact position, openings still reachable from here, and the legal
 * moves to branch into next.
 */
public final class PositionContext {

    private final BoardAdapter position;
    private final List<String> sanPathFromStart;
    private final Optional<OpeningRecord> identifiedOpening;
    private final List<OpeningRecord> alsoReachedByTransposition; // same position, different named line(s)
    private final List<OpeningRecord> possibleContinuations;       // openings this line could still become
    private final List<Move> legalMoves;

    public PositionContext(BoardAdapter position, List<String> sanPathFromStart,
                            Optional<OpeningRecord> identifiedOpening,
                            List<OpeningRecord> alsoReachedByTransposition,
                            List<OpeningRecord> possibleContinuations,
                            List<Move> legalMoves) {
        this.position = position;
        this.sanPathFromStart = sanPathFromStart;
        this.identifiedOpening = identifiedOpening;
        this.alsoReachedByTransposition = alsoReachedByTransposition;
        this.possibleContinuations = possibleContinuations;
        this.legalMoves = legalMoves;
    }

    public BoardAdapter position() { return position; }
    public List<String> sanPathFromStart() { return sanPathFromStart; }
    public Optional<OpeningRecord> identifiedOpening() { return identifiedOpening; }
    public List<OpeningRecord> alsoReachedByTransposition() { return alsoReachedByTransposition; }
    public List<OpeningRecord> possibleContinuations() { return possibleContinuations; }
    public List<Move> legalMoves() { return legalMoves; }

    public boolean isTransposition() { return !alsoReachedByTransposition.isEmpty(); }
}
