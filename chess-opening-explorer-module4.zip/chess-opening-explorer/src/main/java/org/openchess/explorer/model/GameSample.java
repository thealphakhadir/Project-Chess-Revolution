package org.openchess.explorer.model;

/** A single real game that reached the queried position, for "sample games" panels. */
public final class GameSample {

    public enum Result { WHITE_WIN, DRAW, BLACK_WIN, ONGOING }

    private final String id;
    private final String white;
    private final String black;
    private final Integer whiteRating;
    private final Integer blackRating;
    private final Result result;
    private final String dateIso;
    private final String event;
    private final DataSourceType source;
    private final String pgnUrl; // may be null if the source doesn't expose a fetchable PGN

    public GameSample(String id, String white, String black, Integer whiteRating, Integer blackRating,
                       Result result, String dateIso, String event, DataSourceType source, String pgnUrl) {
        this.id = id;
        this.white = white;
        this.black = black;
        this.whiteRating = whiteRating;
        this.blackRating = blackRating;
        this.result = result;
        this.dateIso = dateIso;
        this.event = event;
        this.source = source;
        this.pgnUrl = pgnUrl;
    }

    public String id() { return id; }
    public String white() { return white; }
    public String black() { return black; }
    public Integer whiteRating() { return whiteRating; }
    public Integer blackRating() { return blackRating; }
    public Result result() { return result; }
    public String dateIso() { return dateIso; }
    public String event() { return event; }
    public DataSourceType source() { return source; }
    public String pgnUrl() { return pgnUrl; }

    @Override
    public String toString() {
        return String.format("%s vs %s (%s, %s) %s", white, black,
                event == null ? "?" : event, dateIso == null ? "?" : dateIso, result);
    }
}
