package org.openchess.explorer.eco;

import org.openchess.explorer.model.OpeningRecord;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

/**
 * ECO code / opening-name lookup, sourced from {@code eco/eco_openings.tsv} —
 * a machine-readable export of the same 500-code A00-E99 reference data as
 * the project's full "Complete Chess ECO Openings" document. If that
 * document is ever revised, regenerate this TSV from the same source rather
 * than hand-editing it (see {@code gen_tsv2.py} used to build it).
 *
 * This does line-sequence matching (does the position's move list match, or
 * extend, a known SAN line) rather than fully transposition-aware matching
 * by board position — see {@code tree.MoveTreeService} for the
 * position-key-based transposition merge, which calls back into this book
 * for every distinct move-order path into a position and reports all of
 * them, which is how transpositions get surfaced in practice.
 */
public final class EcoOpeningBook {

    private final List<OpeningRecord> records;

    private EcoOpeningBook(List<OpeningRecord> records) {
        this.records = records;
    }

    public static EcoOpeningBook loadDefault() {
        try (InputStream in = EcoOpeningBook.class.getResourceAsStream("/eco/eco_openings.tsv")) {
            if (in == null) {
                throw new IllegalStateException("eco_openings.tsv not found on classpath at /eco/eco_openings.tsv");
            }
            return load(in);
        } catch (IOException e) {
            throw new RuntimeException("Failed to load ECO opening book", e);
        }
    }

    public static EcoOpeningBook load(InputStream in) throws IOException {
        List<OpeningRecord> out = new ArrayList<>();
        try (BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            String header = r.readLine(); // skip header row
            String line;
            while ((line = r.readLine()) != null) {
                if (line.isBlank()) continue;
                String[] parts = line.split("\t", -1);
                String code = parts[0];
                List<String> san = parts[1].isBlank() ? List.of() : Arrays.asList(parts[1].split(" "));
                String name = parts[2];
                String family = parts.length > 3 ? parts[3] : name;
                out.add(new OpeningRecord(code, san, name, family));
            }
        }
        return new EcoOpeningBook(out);
    }

    public List<OpeningRecord> allRecords() { return Collections.unmodifiableList(records); }

    public Optional<OpeningRecord> byCode(String ecoCode) {
        return records.stream().filter(r -> r.ecoCode().equalsIgnoreCase(ecoCode)).findFirst();
    }

    /**
     * The most specific known opening reached by exactly this SAN move
     * order (the longest record line that is a prefix of, or equal to,
     * {@code playedSanMoves}).
     */
    public Optional<OpeningRecord> identify(List<String> playedSanMoves) {
        OpeningRecord best = null;
        for (OpeningRecord r : records) {
            int len = r.plyLength();
            if (len == 0 || len > playedSanMoves.size()) continue;
            if (r.sanLine().equals(playedSanMoves.subList(0, len))) {
                if (best == null || len > best.plyLength()) best = r;
            }
        }
        return Optional.ofNullable(best);
    }

    /**
     * Openings this exact move order could still transpose into: records
     * whose defining line starts with {@code playedSanMoves} but continues
     * further. Mirrors "possible openings a position can still transpose
     * into until the line becomes unique."
     */
    public List<OpeningRecord> possibleContinuations(List<String> playedSanMoves) {
        List<OpeningRecord> out = new ArrayList<>();
        for (OpeningRecord r : records) {
            int len = r.plyLength();
            if (len <= playedSanMoves.size()) continue;
            if (r.sanLine().subList(0, playedSanMoves.size()).equals(playedSanMoves)) {
                out.add(r);
            }
        }
        return out;
    }
}
