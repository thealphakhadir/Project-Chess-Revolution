package org.openchess.explorer.tree;

import org.openchess.explorer.board.BoardAdapter;
import org.openchess.explorer.board.Move;
import org.openchess.explorer.eco.EcoOpeningBook;
import org.openchess.explorer.eco.TranspositionIndex;
import org.openchess.explorer.model.OpeningRecord;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.function.Supplier;

/**
 * Move-tree navigation: from the starting position (or any FEN/move path
 * you hand it), walk forward one legal move at a time with no fixed depth
 * limit — this is plain recursive descent through {@link BoardAdapter},
 * so it supports arbitrarily deep exploration (40-50+ plies and beyond;
 * the only limit is how far real games/theory actually go, not the code).
 */
public final class MoveTreeService {

    private final EcoOpeningBook ecoBook;
    private final TranspositionIndex transpositionIndex;
    private final Supplier<BoardAdapter> startingPositionFactory;

    public MoveTreeService(EcoOpeningBook ecoBook, Supplier<BoardAdapter> startingPositionFactory) {
        this.ecoBook = ecoBook;
        this.startingPositionFactory = startingPositionFactory;
        this.transpositionIndex = TranspositionIndex.build(ecoBook, startingPositionFactory);
    }

    public BoardAdapter startingPosition() { return startingPositionFactory.get(); }

    /** Replay a sequence of SAN moves from the start and return the resulting position + opening context. */
    public PositionContext analyzeSanPath(List<String> sanMoves) {
        BoardAdapter b = startingPositionFactory.get();
        List<String> played = new ArrayList<>();
        for (String san : sanMoves) {
            Move m = b.findMoveBySan(san);
            b = b.playMove(m);
            played.add(m.san());
        }
        return analyze(b, played);
    }

    /** Analyze an already-reached position, given the SAN path that was used to get there (for book-order continuations). */
    public PositionContext analyze(BoardAdapter position, List<String> sanPathFromStart) {
        String key = position.positionKey();
        List<OpeningRecord> transpositionMatches = transpositionIndex.lookup(key);

        Optional<OpeningRecord> primary;
        List<OpeningRecord> alsoReached;
        if (!transpositionMatches.isEmpty()) {
            // prefer the deepest (most specific) record among those that truly reach this position
            OpeningRecord best = transpositionMatches.stream()
                    .max((a, c) -> Integer.compare(a.plyLength(), c.plyLength())).orElseThrow();
            primary = Optional.of(best);
            alsoReached = transpositionMatches.stream().filter(r -> r != best).toList();
        } else {
            // fall back to text-based prefix matching (still useful early in the game,
            // or for positions outside the 500-code book depth)
            primary = ecoBook.identify(sanPathFromStart);
            alsoReached = List.of();
        }

        List<OpeningRecord> continuations = ecoBook.possibleContinuations(sanPathFromStart);

        return new PositionContext(position, sanPathFromStart, primary, alsoReached, continuations, position.legalMoves());
    }

    /** Advance a PositionContext by one legal move (matched by SAN), for click-to-navigate UIs. */
    public PositionContext advance(PositionContext from, String sanMove) {
        Move m = from.position().findMoveBySan(sanMove);
        BoardAdapter next = from.position().playMove(m);
        List<String> path = new ArrayList<>(from.sanPathFromStart());
        path.add(m.san());
        return analyze(next, path);
    }

    public int transpositionIndexSize() { return transpositionIndex.indexedPositionCount(); }
}
