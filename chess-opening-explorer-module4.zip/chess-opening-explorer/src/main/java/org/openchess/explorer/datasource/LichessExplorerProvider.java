package org.openchess.explorer.datasource;

import org.openchess.explorer.board.BoardAdapter;
import org.openchess.explorer.model.*;
import org.openchess.explorer.util.Json;

import java.io.IOException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.*;

/**
 * Statistics from Lichess's public Opening Explorer API
 * (https://explorer.lichess.ovh) — no API key required. Covers both the
 * "Masters" tab (over-the-board games by titled players) and the "Online"
 * tab (all rated Lichess games) off the same service, since Lichess exposes
 * them as separate endpoints over the identical position-lookup model:
 *
 *   GET /masters?fen=...&topGames=N
 *   GET /lichess?fen=...&speeds=blitz,rapid&ratings=1600,2000&topGames=N
 *
 * Query is always by FEN of the exact target position, so transpositions
 * are merged for free — this is a live, position-indexed database, not a
 * move-sequence text match.
 *
 * This is a real, functioning implementation you can run today; it is also
 * the natural place to point at Chess.com's or your own crawled database
 * instead/in addition — implement {@link StatsProvider} the same way
 * against whatever endpoint or local store you use, and register it with
 * {@link AggregatingStatsProvider}.
 */
public final class LichessExplorerProvider implements StatsProvider {

    private static final String BASE = "https://explorer.lichess.ovh";
    private static final Duration TIMEOUT = Duration.ofSeconds(10);

    private final DataSourceType type; // MASTERS or ONLINE
    private final HttpClient http;

    public LichessExplorerProvider(DataSourceType type) {
        if (type != DataSourceType.MASTERS && type != DataSourceType.ONLINE) {
            throw new IllegalArgumentException("LichessExplorerProvider only serves MASTERS or ONLINE, got " + type);
        }
        this.type = type;
        this.http = HttpClient.newBuilder().connectTimeout(TIMEOUT).build();
    }

    @Override
    public DataSourceType sourceType() { return type; }

    @Override
    public String displayName() {
        return type == DataSourceType.MASTERS ? "Lichess Masters DB (OTB, titled players)" : "Lichess Online (all rated games)";
    }

    @Override
    public List<MoveStat> statsForPosition(BoardAdapter position, QueryFilter filter) {
        Map<String, Object> json = fetch(position, filter, 0);
        if (json == null) return List.of();
        List<MoveStat> out = new ArrayList<>();
        for (Object o : Json.listVal(json, "moves")) {
            @SuppressWarnings("unchecked")
            Map<String, Object> mv = (Map<String, Object>) o;
            String san = Json.str(mv, "san");
            String uci = Json.str(mv, "uci");
            long w = orZero(Json.longVal(mv, "white"));
            long d = orZero(Json.longVal(mv, "draws"));
            long b = orZero(Json.longVal(mv, "black"));
            Double avgRating = Json.doubleVal(mv, "averageRating");
            if (avgRating == null) avgRating = Json.doubleVal(mv, "averageOpponentRating");
            Integer perf = Json.intVal(mv, "performance");
            Map<String, Object> opening = Json.mapVal(mv, "opening");
            String eco = opening == null ? null : Json.str(opening, "eco");
            String name = opening == null ? null : Json.str(opening, "name");
            out.add(new MoveStat(san, uci, type, w, d, b, avgRating, null, perf, null, eco, name));
        }
        return out;
    }

    @Override
    public List<GameSample> sampleGames(BoardAdapter position, QueryFilter filter, int limit) {
        Map<String, Object> json = fetch(position, filter, limit);
        if (json == null) return List.of();
        List<GameSample> out = new ArrayList<>();
        List<Object> topGames = Json.listVal(json, "topGames");
        for (Object o : topGames) {
            @SuppressWarnings("unchecked")
            Map<String, Object> g = (Map<String, Object>) o;
            out.add(toGameSample(g));
            if (out.size() >= limit) break;
        }
        return out;
    }

    private GameSample toGameSample(Map<String, Object> g) {
        String id = Json.str(g, "id");
        Map<String, Object> white = Json.mapVal(g, "white");
        Map<String, Object> black = Json.mapVal(g, "black");
        String whiteName = white == null ? "?" : Json.str(white, "name");
        String blackName = black == null ? "?" : Json.str(black, "name");
        Integer whiteRating = white == null ? null : Json.intVal(white, "rating");
        Integer blackRating = black == null ? null : Json.intVal(black, "rating");
        String winner = Json.str(g, "winner");
        GameSample.Result result = "white".equals(winner) ? GameSample.Result.WHITE_WIN
                : "black".equals(winner) ? GameSample.Result.BLACK_WIN
                : winner == null ? GameSample.Result.DRAW : GameSample.Result.DRAW;
        String month = Json.str(g, "month");
        String year = Json.str(g, "year");
        String date = month != null ? month : year;
        String url = type == DataSourceType.MASTERS
                ? BASE + "/master/pgn/" + id
                : "https://lichess.org/" + id;
        return new GameSample(id, whiteName, blackName, whiteRating, blackRating, result, date, null, type, url);
    }

    private Map<String, Object> fetch(BoardAdapter position, QueryFilter filter, int topGames) {
        StringBuilder url = new StringBuilder(BASE)
                .append(type == DataSourceType.MASTERS ? "/masters" : "/lichess")
                .append("?fen=").append(encode(position.toFen()));

        if (type == DataSourceType.ONLINE) {
            if (filter != null && !filter.timeControls().isEmpty()
                    && filter.timeControls().size() < TimeControl.values().length) {
                StringBuilder speeds = new StringBuilder();
                for (TimeControl tc : filter.timeControls()) {
                    if (speeds.length() > 0) speeds.append(',');
                    speeds.append(tc.wireName());
                }
                url.append("&speeds=").append(encode(speeds.toString()));
            }
            if (filter != null && filter.hasRatingBounds()) {
                // Lichess buckets ratings at 0,1000,1200,1400,1600,1800,2000,2200,2500
                int[] buckets = {0, 1000, 1200, 1400, 1600, 1800, 2000, 2200, 2500};
                StringBuilder ratings = new StringBuilder();
                int min = filter.minRating() == null ? 0 : filter.minRating();
                int max = filter.maxRating() == null ? 3000 : filter.maxRating();
                for (int bucket : buckets) {
                    if (bucket >= min && bucket <= max) {
                        if (ratings.length() > 0) ratings.append(',');
                        ratings.append(bucket);
                    }
                }
                if (ratings.length() > 0) url.append("&ratings=").append(encode(ratings.toString()));
            }
            if (filter != null && filter.since() != null) {
                url.append("&since=").append(filter.since());
            }
            if (filter != null && filter.until() != null) {
                url.append("&until=").append(filter.until());
            }
        }
        if (topGames > 0) {
            url.append("&topGames=").append(Math.min(topGames, 15));
        }

        try {
            HttpRequest req = HttpRequest.newBuilder(URI.create(url.toString()))
                    .timeout(TIMEOUT)
                    .header("Accept", "application/json")
                    .GET()
                    .build();
            HttpResponse<String> resp = http.send(req, HttpResponse.BodyHandlers.ofString());
            if (resp.statusCode() != 200) return null;
            return Json.parseObject(resp.body());
        } catch (IOException | InterruptedException e) {
            if (e instanceof InterruptedException) Thread.currentThread().interrupt();
            return null; // degrade gracefully — caller treats this source as having no data right now
        }
    }

    private static long orZero(Long v) { return v == null ? 0L : v; }

    private static String encode(String s) { return URLEncoder.encode(s, StandardCharsets.UTF_8); }
}
