package org.openchess.explorer;

import org.openchess.explorer.ai.ClaudeOpeningAssistant;
import org.openchess.explorer.board.BoardAdapter;
import org.openchess.explorer.board.fallback.SimpleBoard;
import org.openchess.explorer.datasource.AggregatingStatsProvider;
import org.openchess.explorer.datasource.LichessExplorerProvider;
import org.openchess.explorer.datasource.StatsProvider;
import org.openchess.explorer.engine.EngineAdapter;
import org.openchess.explorer.engine.StockfishUciAdapter;
import org.openchess.explorer.eco.EcoOpeningBook;
import org.openchess.explorer.model.*;
import org.openchess.explorer.repertoire.RepertoireService;
import org.openchess.explorer.service.CandidateMoveView;
import org.openchess.explorer.service.ExplorerView;
import org.openchess.explorer.service.OpeningExplorerService;
import org.openchess.explorer.tree.MoveTreeService;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Scanner;

/**
 * Runnable demo / smoke test for Module 4. Not a UI — the real UI is
 * whatever the project's web app or Android app renders; this is a REPL so
 * you can sanity-check the whole pipeline (ECO ID, live stats, optional
 * engine, optional AI, repertoire) from a terminal in about ten seconds.
 *
 * Build & run:
 *   mvn package
 *   java -jar target/chess-opening-explorer.jar
 *
 * Optional environment variables:
 *   STOCKFISH_PATH     path to a local Stockfish binary — enables engine eval
 *   ANTHROPIC_API_KEY  Claude API key — enables "explain" / "ask" commands
 */
public final class Main {

    public static void main(String[] args) throws Exception {
        System.out.println("Loading ECO opening book...");
        EcoOpeningBook ecoBook = EcoOpeningBook.loadDefault();
        System.out.println("Loaded " + ecoBook.allRecords().size() + " ECO codes. Building transposition index...");
        MoveTreeService moveTree = new MoveTreeService(ecoBook, SimpleBoard::startingPosition);
        System.out.println("Transposition index ready (" + moveTree.transpositionIndexSize() + " distinct positions).");

        List<StatsProvider> providers = new ArrayList<>();
        providers.add(new LichessExplorerProvider(DataSourceType.MASTERS));
        providers.add(new LichessExplorerProvider(DataSourceType.ONLINE));
        AggregatingStatsProvider statsProvider = new AggregatingStatsProvider(providers);

        EngineAdapter engine = null;
        String stockfishPath = System.getenv("STOCKFISH_PATH");
        if (stockfishPath != null) {
            try {
                engine = new StockfishUciAdapter(stockfishPath);
                System.out.println("Engine connected: " + stockfishPath);
            } catch (Exception e) {
                System.out.println("Could not start Stockfish at " + stockfishPath + " (" + e.getMessage() + "); continuing without engine eval.");
            }
        } else {
            System.out.println("STOCKFISH_PATH not set — engine evaluation disabled. (Set it to a Stockfish binary to enable.)");
        }

        ClaudeOpeningAssistant ai = null;
        if (System.getenv("ANTHROPIC_API_KEY") != null) {
            ai = new ClaudeOpeningAssistant();
            System.out.println("Claude AI assistant enabled ('explain' / 'ask <question>' commands available).");
        } else {
            System.out.println("ANTHROPIC_API_KEY not set — AI commentary disabled.");
        }

        RepertoireService repertoire = new RepertoireService(Path.of("repertoire.json"));

        try (OpeningExplorerService explorer = new OpeningExplorerService(
                moveTree, SimpleBoard::fromFen, statsProvider, engine, ai, repertoire, 18)) {

            List<String> sanPath = new ArrayList<>();
            QueryFilter filter = QueryFilter.NONE;
            ExplorerView view = explorer.explore(sanPath, filter, Color.WHITE);

            Scanner scanner = new Scanner(System.in);
            printHelp();
            while (true) {
                printView(view);
                System.out.print("\n> ");
                if (!scanner.hasNextLine()) break;
                String input = scanner.nextLine().trim();
                if (input.isEmpty()) continue;

                try {
                    if (input.equalsIgnoreCase("quit") || input.equalsIgnoreCase("exit")) {
                        break;
                    } else if (input.equalsIgnoreCase("help")) {
                        printHelp();
                    } else if (input.equalsIgnoreCase("restart")) {
                        sanPath.clear();
                        view = explorer.explore(sanPath, filter, Color.WHITE);
                    } else if (input.startsWith("fen ")) {
                        view = explorer.exploreFen(input.substring(4).trim(), filter, Color.WHITE);
                        sanPath = new ArrayList<>(view.positionContext().sanPathFromStart());
                    } else if (input.equalsIgnoreCase("explain")) {
                        System.out.println("\n" + explorer.explainCurrentOpening(view));
                    } else if (input.equalsIgnoreCase("explain moves")) {
                        System.out.println("\n" + explorer.explainCandidateMoves(view));
                    } else if (input.startsWith("ask ")) {
                        System.out.println("\n" + explorer.askAboutPosition(view, input.substring(4).trim()));
                    } else {
                        // treat anything else as a SAN move to play
                        view = explorer.advance(view, input, filter, Color.WHITE);
                        sanPath.add(view.positionContext().sanPathFromStart().get(view.positionContext().sanPathFromStart().size() - 1));
                    }
                } catch (Exception e) {
                    System.out.println("(!) " + e.getMessage());
                }
            }
        }
        System.out.println("Goodbye.");
    }

    private static void printHelp() {
        System.out.println("""

                Commands:
                  <SAN move>       play a move, e.g. "e4" or "Nf3" or "O-O"
                  fen <FEN>        jump straight to a position
                  restart          back to the starting position
                  explain          AI: explain the current opening
                  explain moves    AI: explain the candidate moves given the live stats
                  ask <question>   AI: ask anything about this position
                  help             show this again
                  quit             exit
                """);
    }

    private static void printView(ExplorerView view) {
        var ctx = view.positionContext();
        System.out.println("\n" + boardAscii(ctx.position().toFen()));
        System.out.println("FEN: " + ctx.position().toFen());
        System.out.println("To move: " + ctx.position().sideToMove());

        ctx.identifiedOpening().ifPresentOrElse(
                o -> System.out.println("Opening: " + o.ecoCode() + " — " + o.name() + "  (family: " + o.family() + ")"),
                () -> System.out.println("Opening: (not a named ECO line)"));

        if (ctx.isTransposition()) {
            System.out.print("Also reachable via: ");
            ctx.alsoReachedByTransposition().forEach(o -> System.out.print(o.ecoCode() + " " + o.name() + "; "));
            System.out.println();
        }
        if (!ctx.possibleContinuations().isEmpty() && ctx.possibleContinuations().size() <= 8) {
            System.out.print("Could transpose into: ");
            ctx.possibleContinuations().forEach(o -> System.out.print(o.ecoCode() + " "));
            System.out.println();
        }

        if (view.engineEvaluation() != null) {
            System.out.println("Engine (" + view.engineEvaluation().engineName() + ", depth "
                    + view.engineEvaluation().depth() + "): " + view.engineEvaluation().humanScore()
                    + "  PV: " + String.join(" ", view.engineEvaluation().principalVariationSan()));
        }

        if (ctx.legalMoves().isEmpty()) {
            System.out.println(ctx.position().isCheckmate() ? "Checkmate." : "Stalemate.");
            return;
        }

        System.out.println(String.format(Locale.US, "%-8s %-8s %10s %8s %8s %8s %10s  %s",
                "Move", "Rep?", "Games", "White%", "Draw%", "Black%", "AvgRtg", "Sources"));
        for (CandidateMoveView c : view.candidateMoves()) {
            String games = c.merged() == null ? "-" : String.valueOf(c.merged().totalGames());
            String w = c.merged() == null ? "-" : String.format(Locale.US, "%.0f%%", c.merged().whitePct());
            String d = c.merged() == null ? "-" : String.format(Locale.US, "%.0f%%", c.merged().drawPct());
            String b = c.merged() == null ? "-" : String.format(Locale.US, "%.0f%%", c.merged().blackPct());
            String rtg = (c.merged() == null || c.merged().averageRating() == null) ? "-"
                    : String.format(Locale.US, "%.0f", c.merged().averageRating());
            String sources = String.join(",", c.statsBySource().keySet().stream().map(Enum::name).toList());
            System.out.println(String.format(Locale.US, "%-8s %-8s %10s %8s %8s %8s %10s  %s",
                    c.san(), c.inOwnRepertoire() ? "*" : "", games, w, d, b, rtg, sources));
        }
    }

    /** Small ASCII board render from a FEN's piece-placement field, for terminal sanity-checking. */
    private static String boardAscii(String fen) {
        String placement = fen.split(" ")[0];
        String[] ranks = placement.split("/");
        StringBuilder sb = new StringBuilder();
        for (int r = 0; r < 8; r++) {
            sb.append(8 - r).append(" ");
            for (char c : ranks[r].toCharArray()) {
                if (Character.isDigit(c)) {
                    sb.append(". ".repeat(c - '0'));
                } else {
                    sb.append(c).append(' ');
                }
            }
            sb.append('\n');
        }
        sb.append("  a b c d e f g h");
        return sb.toString();
    }
}
