package org.openchess.explorer.model;

/**
 * Aggregated statistics for a single candidate move from a single position,
 * as returned by one data source (see {@link DataSourceType}). When several
 * sources are merged, one MoveStat per source is kept rather than blended,
 * so the UI can still show "masters say X, the crowd says Y".
 */
public final class MoveStat {

    private final String sanMove;
    private final String uciMove;
    private final DataSourceType source;

    private final long whiteWins;
    private final long draws;
    private final long blackWins;

    private final Double averageRating;   // avg rating of players who played this move (nullable)
    private final Integer maxRating;      // strongest player rating seen playing this move (nullable)
    private final Integer performance;    // performance rating achieved after this move (nullable)
    private final String lastPlayedIso;   // ISO date of most recent game reaching this move (nullable)

    private final String openingEco;      // ECO code of the resulting position, if identified
    private final String openingName;     // opening name of the resulting position, if identified

    public MoveStat(String sanMove, String uciMove, DataSourceType source,
                     long whiteWins, long draws, long blackWins,
                     Double averageRating, Integer maxRating, Integer performance,
                     String lastPlayedIso, String openingEco, String openingName) {
        this.sanMove = sanMove;
        this.uciMove = uciMove;
        this.source = source;
        this.whiteWins = whiteWins;
        this.draws = draws;
        this.blackWins = blackWins;
        this.averageRating = averageRating;
        this.maxRating = maxRating;
        this.performance = performance;
        this.lastPlayedIso = lastPlayedIso;
        this.openingEco = openingEco;
        this.openingName = openingName;
    }

    public String sanMove() { return sanMove; }
    public String uciMove() { return uciMove; }
    public DataSourceType source() { return source; }
    public long whiteWins() { return whiteWins; }
    public long draws() { return draws; }
    public long blackWins() { return blackWins; }
    public long totalGames() { return whiteWins + draws + blackWins; }
    public Double averageRating() { return averageRating; }
    public Integer maxRating() { return maxRating; }
    public Integer performance() { return performance; }
    public String lastPlayedIso() { return lastPlayedIso; }
    public String openingEco() { return openingEco; }
    public String openingName() { return openingName; }

    public double whitePct() { return pct(whiteWins); }
    public double drawPct() { return pct(draws); }
    public double blackPct() { return pct(blackWins); }

    private double pct(long part) {
        long total = totalGames();
        return total == 0 ? 0.0 : (100.0 * part) / total;
    }

    /** Merge this stat with another for the SAME move from a DIFFERENT source into a combined pool. */
    public MoveStat mergedWith(MoveStat other) {
        if (!this.sanMove.equals(other.sanMove)) {
            throw new IllegalArgumentException("Cannot merge stats for different moves: "
                    + this.sanMove + " vs " + other.sanMove);
        }
        Double avgRating = averageOf(this.averageRating, other.averageRating);
        Integer maxR = maxOf(this.maxRating, other.maxRating);
        String lastPlayed = laterOf(this.lastPlayedIso, other.lastPlayedIso);
        return new MoveStat(sanMove, uciMove != null ? uciMove : other.uciMove, null,
                whiteWins + other.whiteWins, draws + other.draws, blackWins + other.blackWins,
                avgRating, maxR, null, lastPlayed,
                openingEco != null ? openingEco : other.openingEco,
                openingName != null ? openingName : other.openingName);
    }

    private static Double averageOf(Double a, Double b) {
        if (a == null) return b;
        if (b == null) return a;
        return (a + b) / 2.0;
    }

    private static Integer maxOf(Integer a, Integer b) {
        if (a == null) return b;
        if (b == null) return a;
        return Math.max(a, b);
    }

    private static String laterOf(String a, String b) {
        if (a == null) return b;
        if (b == null) return a;
        return a.compareTo(b) >= 0 ? a : b;
    }

    @Override
    public String toString() {
        return String.format("%s [%s] games=%d W/D/B=%.1f%%/%.1f%%/%.1f%% avgRating=%s",
                sanMove, source, totalGames(), whitePct(), drawPct(), blackPct(),
                averageRating == null ? "n/a" : String.format("%.0f", averageRating));
    }
}
