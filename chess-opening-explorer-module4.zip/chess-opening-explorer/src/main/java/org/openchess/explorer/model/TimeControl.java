package org.openchess.explorer.model;

/** Speed/time-control bucket, matching the categories real explorers filter on. */
public enum TimeControl {
    ULTRA_BULLET("ultraBullet"),
    BULLET("bullet"),
    BLITZ("blitz"),
    RAPID("rapid"),
    CLASSICAL("classical"),
    CORRESPONDENCE("correspondence");

    private final String wireName;

    TimeControl(String wireName) {
        this.wireName = wireName;
    }

    /** Name as used by data-source query params (e.g. Lichess's "speeds" filter). */
    public String wireName() {
        return wireName;
    }
}
