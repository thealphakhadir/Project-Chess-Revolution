package org.openchess.explorer.service;

import org.openchess.explorer.ai.ClaudeOpeningAssistant;
import org.openchess.explorer.board.BoardAdapter;
import org.openchess.explorer.board.Move;
import org.openchess.explorer.datasource.AggregatingStatsProvider;
import org.openchess.explorer.engine.EngineAdapter;
import org.openchess.explorer.model.*;
import org.openchess.explorer.repertoire.RepertoireService;
import org.openchess.explorer.tree.MoveTreeService;
import org.openchess.explorer.tree.PositionContext;

import java.util.*;
import java.util.function.Function;

/**
 * MODULE 4 — Opening Explorer.
 *
 * Top-level entry point tying together move-tree navigation, ECO opening
 * identification (transposition-aware), multi-source statistics, engine
 * evaluation, sample games, and personal-repertoire annotation. This is
 * the class the rest of the application (web/desktop UI, Android app, CLI)
 * should talk to; everything else in this module is a supporting service
 * this class composes.
 *
 * Engine and AI integrations are optional — pass {@code null} for either if
 * you don't have Stockfish or an Anthropic API key configured, and this
 * class degrades gracefully (no evaluation shown / AI methods throw only
 * when actually called).
 */
public final class OpeningExplorerService implements AutoCloseable {

    private final MoveTreeService moveTree;
    private final Function<String, BoardAdapter> fenParser;
    private final AggregatingStatsProvider statsProvider;
    private final EngineAdapter engine;              // nullable
    private final ClaudeOpeningAssistant aiAssistant; // nullable
    private final RepertoireService repertoire;       // nullable
    private final int defaultEngineDepth;

    public OpeningExplorerService(MoveTreeService moveTree, Function<String, BoardAdapter> fenParser,
                                   AggregatingStatsProvider statsProvider, EngineAdapter engine,
                                   ClaudeOpeningAssistant aiAssistant, RepertoireService repertoire,
                                   int defaultEngineDepth) {
        this.moveTree = moveTree;
        this.fenParser = fenParser;
        this.statsProvider = statsProvider;
        this.engine = engine;
        this.aiAssistant = aiAssistant;
        this.repertoire = repertoire;
        this.defaultEngineDepth = defaultEngineDepth;
    }

    public BoardAdapter startingPosition() { return moveTree.startingPosition(); }

    /** Explore the position reached by these SAN moves from the start (interactive navigation from move 1). */
    public ExplorerView explore(List<String> sanMovesFromStart, QueryFilter filter, Color repertoireColor) {
        PositionContext ctx = moveTree.analyzeSanPath(sanMovesFromStart);
        return buildView(ctx, filter, repertoireColor);
    }

    /**
     * Explore an arbitrary FEN directly ("search by position" / paste-a-FEN entry point).
     * Opening identification here relies solely on the transposition index (matched by
     * board position), since there's no known move-order path to text-match against.
     */
    public ExplorerView exploreFen(String fen, QueryFilter filter, Color repertoireColor) {
        BoardAdapter board = fenParser.apply(fen);
        PositionContext ctx = moveTree.analyze(board, List.of());
        return buildView(ctx, filter, repertoireColor);
    }

    /** Advance an existing view by one move (click-to-navigate) and re-run the full analysis on the result. */
    public ExplorerView advance(ExplorerView from, String sanMove, QueryFilter filter, Color repertoireColor) {
        PositionContext next = moveTree.advance(from.positionContext(), sanMove);
        return buildView(next, filter, repertoireColor);
    }

    private ExplorerView buildView(PositionContext ctx, QueryFilter filter, Color repertoireColor) {
        Map<DataSourceType, List<MoveStat>> statsBySource = statsProvider.statsBySource(ctx.position(), filter);
        Map<DataSourceType, List<GameSample>> samplesBySource = statsProvider.samplesBySource(ctx.position(), filter, 10);

        Set<String> repertoireNext = repertoire == null ? Set.of()
                : repertoire.recommendedNextMoves(ctx.sanPathFromStart(), repertoireColor);
        Map<String, String> repertoireLabelByMove = new HashMap<>();
        if (repertoire != null) {
            for (var entry : repertoire.matching(ctx.sanPathFromStart(), repertoireColor)) {
                String next = entry.nextMoveAfter(ctx.sanPathFromStart());
                if (next != null) repertoireLabelByMove.putIfAbsent(next, entry.label());
            }
        }

        List<CandidateMoveView> candidates = new ArrayList<>();
        for (Move legal : ctx.legalMoves()) {
            Map<DataSourceType, MoveStat> perSource = new EnumMap<>(DataSourceType.class);
            MoveStat merged = null;
            for (var e : statsBySource.entrySet()) {
                for (MoveStat s : e.getValue()) {
                    if (s.sanMove().equals(legal.san())) {
                        perSource.put(e.getKey(), s);
                        merged = merged == null ? s : merged.mergedWith(s);
                    }
                }
            }
            boolean inRepertoire = repertoireNext.contains(legal.san());
            candidates.add(new CandidateMoveView(legal.san(), legal.uci(), perSource, merged,
                    inRepertoire, repertoireLabelByMove.get(legal.san())));
        }
        // most-played first, like every real explorer's default sort
        candidates.sort((a, b) -> Long.compare(b.popularityGames(), a.popularityGames()));

        EvaluationResult eval = engine == null ? null : engine.evaluate(ctx.position(), defaultEngineDepth);

        return new ExplorerView(ctx, candidates, samplesBySource, eval);
    }

    // ------------------------------------------------------------- AI

    public String explainCurrentOpening(ExplorerView view) {
        requireAi();
        return view.positionContext().identifiedOpening()
                .map(aiAssistant::explainOpening)
                .orElse("This position isn't a named ECO line yet (still early or off known theory) — "
                        + "nothing to explain from the opening book.");
    }

    public String explainCandidateMoves(ExplorerView view) {
        requireAi();
        Map<DataSourceType, List<MoveStat>> bySource = new EnumMap<>(DataSourceType.class);
        for (CandidateMoveView c : view.candidateMoves()) {
            for (var e : c.statsBySource().entrySet()) {
                bySource.computeIfAbsent(e.getKey(), k -> new ArrayList<>()).add(e.getValue());
            }
        }
        return aiAssistant.explainCandidateMoves(view.positionContext(), bySource);
    }

    public String askAboutPosition(ExplorerView view, String question) {
        requireAi();
        return aiAssistant.answerQuestion(question, view.positionContext());
    }

    private void requireAi() {
        if (aiAssistant == null) {
            throw new IllegalStateException("No ClaudeOpeningAssistant configured for this service instance.");
        }
    }

    // --------------------------------------------------------- lifecycle

    @Override
    public void close() {
        statsProvider.close();
        if (engine != null) engine.close();
    }
}
