package org.openchess.explorer.board.fallback;

import org.openchess.explorer.board.BoardAdapter;
import org.openchess.explorer.board.Move;
import org.openchess.explorer.board.PieceType;
import org.openchess.explorer.model.Color;

import java.util.ArrayList;
import java.util.List;

/**
 * Reference implementation of {@link BoardAdapter} covering standard chess
 * rules in full: all piece moves, castling (with the "king doesn't pass
 * through check" rule), en passant, promotion (incl. underpromotion),
 * check/checkmate/stalemate detection, and SAN generation with proper
 * disambiguation.
 *
 * This exists so Module 4 compiles and runs standalone. If Modules 1-3 of
 * the project already have a board/move-generator, prefer wrapping that in
 * a {@link BoardAdapter} implementation instead of this class — see the
 * note on {@link BoardAdapter}. This class has NOT been perft-tested
 * against reference perft numbers; treat it as a working reference, run
 * your own perft suite before relying on it for anything beyond the
 * explorer's own move-tree traversal.
 */
public final class SimpleBoard implements BoardAdapter {

    // piece codes: 0 empty; 1=P 2=N 3=B 4=R 5=Q 6=K; white positive, black negative
    private final int[] sq; // 64 squares, a1=0 .. h8=63
    private final Color sideToMove;
    private final boolean whiteCastleK, whiteCastleQ, blackCastleK, blackCastleQ;
    private final int epSquare; // -1 if none
    private final int halfmoveClock;
    private final int fullmoveNumber;

    private List<Move> cachedLegalMoves; // lazily computed, this object is immutable so caching is safe

    private SimpleBoard(int[] sq, Color sideToMove, boolean wck, boolean wcq, boolean bck, boolean bcq,
                         int epSquare, int halfmoveClock, int fullmoveNumber) {
        this.sq = sq;
        this.sideToMove = sideToMove;
        this.whiteCastleK = wck;
        this.whiteCastleQ = wcq;
        this.blackCastleK = bck;
        this.blackCastleQ = bcq;
        this.epSquare = epSquare;
        this.halfmoveClock = halfmoveClock;
        this.fullmoveNumber = fullmoveNumber;
    }

    public static SimpleBoard startingPosition() {
        return fromFen("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1");
    }

    public static SimpleBoard fromFen(String fen) {
        String[] parts = fen.trim().split("\\s+");
        int[] board = new int[64];
        String[] ranks = parts[0].split("/");
        for (int r = 0; r < 8; r++) {
            String rankStr = ranks[7 - r]; // FEN rank 8 first
            int file = 0;
            for (char c : rankStr.toCharArray()) {
                if (Character.isDigit(c)) {
                    file += (c - '0');
                } else {
                    board[r * 8 + file] = codeFor(c);
                    file++;
                }
            }
        }
        Color stm = parts[1].equals("w") ? Color.WHITE : Color.BLACK;
        String castling = parts.length > 2 ? parts[2] : "-";
        boolean wck = castling.contains("K");
        boolean wcq = castling.contains("Q");
        boolean bck = castling.contains("k");
        boolean bcq = castling.contains("q");
        String epStr = parts.length > 3 ? parts[3] : "-";
        int ep = epStr.equals("-") ? -1 : Move.squareIndex(epStr);
        int half = parts.length > 4 ? Integer.parseInt(parts[4]) : 0;
        int full = parts.length > 5 ? Integer.parseInt(parts[5]) : 1;
        return new SimpleBoard(board, stm, wck, wcq, bck, bcq, ep, half, full);
    }

    private static int codeFor(char c) {
        int t = switch (Character.toLowerCase(c)) {
            case 'p' -> 1;
            case 'n' -> 2;
            case 'b' -> 3;
            case 'r' -> 4;
            case 'q' -> 5;
            case 'k' -> 6;
            default -> throw new IllegalArgumentException("bad FEN piece: " + c);
        };
        return Character.isUpperCase(c) ? t : -t;
    }

    private static char charFor(int code) {
        char c = switch (Math.abs(code)) {
            case 1 -> 'p'; case 2 -> 'n'; case 3 -> 'b'; case 4 -> 'r'; case 5 -> 'q'; case 6 -> 'k';
            default -> '?';
        };
        return code > 0 ? Character.toUpperCase(c) : c;
    }

    private static PieceType typeOf(int code) {
        return switch (Math.abs(code)) {
            case 1 -> PieceType.PAWN;
            case 2 -> PieceType.KNIGHT;
            case 3 -> PieceType.BISHOP;
            case 4 -> PieceType.ROOK;
            case 5 -> PieceType.QUEEN;
            case 6 -> PieceType.KING;
            default -> null;
        };
    }

    private static Color colorOf(int code) {
        return code > 0 ? Color.WHITE : Color.BLACK;
    }

    private static int file(int sq) { return sq % 8; }
    private static int rank(int sq) { return sq / 8; }
    private static boolean onBoard(int f, int r) { return f >= 0 && f < 8 && r >= 0 && r < 8; }

    @Override
    public Color sideToMove() { return sideToMove; }

    @Override
    public boolean isInCheck(Color side) {
        int kingCode = side == Color.WHITE ? 6 : -6;
        int kingSq = -1;
        for (int i = 0; i < 64; i++) if (sq[i] == kingCode) { kingSq = i; break; }
        if (kingSq == -1) return false; // no king on board (shouldn't happen in a real game)
        return isSquareAttacked(kingSq, side.opposite());
    }

    private boolean isSquareAttacked(int target, Color bySide) {
        for (int from = 0; from < 64; from++) {
            int code = sq[from];
            if (code == 0 || colorOf(code) != bySide) continue;
            if (attacks(from, target, code)) return true;
        }
        return false;
    }

    private boolean attacks(int from, int target, int pieceCode) {
        if (from == target) return false;
        int ff = file(from), fr = rank(from);
        int tf = file(target), tr = rank(target);
        int df = tf - ff, dr = tr - fr;
        PieceType pt = typeOf(pieceCode);
        Color side = colorOf(pieceCode);
        switch (pt) {
            case PAWN -> {
                int dir = side == Color.WHITE ? 1 : -1;
                return dr == dir && Math.abs(df) == 1;
            }
            case KNIGHT -> {
                int adf = Math.abs(df), adr = Math.abs(dr);
                return (adf == 1 && adr == 2) || (adf == 2 && adr == 1);
            }
            case KING -> {
                return Math.abs(df) <= 1 && Math.abs(dr) <= 1 && (df != 0 || dr != 0);
            }
            case BISHOP -> {
                return Math.abs(df) == Math.abs(dr) && df != 0 && pathClear(ff, fr, tf, tr);
            }
            case ROOK -> {
                return (df == 0 ^ dr == 0) && pathClear(ff, fr, tf, tr);
            }
            case QUEEN -> {
                boolean diag = Math.abs(df) == Math.abs(dr) && df != 0;
                boolean straight = (df == 0) ^ (dr == 0);
                return (diag || straight) && pathClear(ff, fr, tf, tr);
            }
        }
        return false;
    }

    private boolean pathClear(int ff, int fr, int tf, int tr) {
        int stepF = Integer.signum(tf - ff);
        int stepR = Integer.signum(tr - fr);
        int f = ff + stepF, r = fr + stepR;
        while (f != tf || r != tr) {
            if (sq[r * 8 + f] != 0) return false;
            f += stepF;
            r += stepR;
        }
        return true;
    }

    // ---------------------------------------------------------------- moves

    @Override
    public List<Move> legalMoves() {
        if (cachedLegalMoves != null) return cachedLegalMoves;
        List<Move> pseudo = pseudoLegalMoves();
        List<Move> legal = new ArrayList<>();
        for (Move m : pseudo) {
            SimpleBoard after = applyRaw(m);
            if (!after.isInCheck(sideToMove)) {
                legal.add(m);
            }
        }
        // assign SAN with proper disambiguation now that we know the full legal set
        for (Move m : legal) {
            m.setSan(sanFor(m, legal));
        }
        cachedLegalMoves = legal;
        return legal;
    }

    private List<Move> pseudoLegalMoves() {
        List<Move> moves = new ArrayList<>();
        int sign = sideToMove == Color.WHITE ? 1 : -1;
        for (int from = 0; from < 64; from++) {
            int code = sq[from];
            if (code == 0 || colorOf(code) != sideToMove) continue;
            PieceType pt = typeOf(code);
            int f = file(from), r = rank(from);
            switch (pt) {
                case PAWN -> genPawnMoves(from, f, r, sign, moves);
                case KNIGHT -> genOffsetMoves(from, f, r, KNIGHT_OFFSETS, moves);
                case KING -> { genOffsetMoves(from, f, r, KING_OFFSETS, moves); genCastling(moves); }
                case BISHOP -> genSlidingMoves(from, f, r, BISHOP_DIRS, moves);
                case ROOK -> genSlidingMoves(from, f, r, ROOK_DIRS, moves);
                case QUEEN -> genSlidingMoves(from, f, r, QUEEN_DIRS, moves);
            }
        }
        return moves;
    }

    private static final int[][] KNIGHT_OFFSETS = {{1,2},{2,1},{2,-1},{1,-2},{-1,-2},{-2,-1},{-2,1},{-1,2}};
    private static final int[][] KING_OFFSETS = {{1,0},{1,1},{0,1},{-1,1},{-1,0},{-1,-1},{0,-1},{1,-1}};
    private static final int[][] BISHOP_DIRS = {{1,1},{1,-1},{-1,1},{-1,-1}};
    private static final int[][] ROOK_DIRS = {{1,0},{-1,0},{0,1},{0,-1}};
    private static final int[][] QUEEN_DIRS = {{1,1},{1,-1},{-1,1},{-1,-1},{1,0},{-1,0},{0,1},{0,-1}};

    private void genOffsetMoves(int from, int f, int r, int[][] offsets, List<Move> out) {
        int mover = sq[from];
        for (int[] o : offsets) {
            int nf = f + o[0], nr = r + o[1];
            if (!onBoard(nf, nr)) continue;
            int to = nr * 8 + nf;
            int occ = sq[to];
            if (occ == 0 || colorOf(occ) != colorOf(mover)) {
                out.add(new Move(from, to, null, false, false));
            }
        }
    }

    private void genSlidingMoves(int from, int f, int r, int[][] dirs, List<Move> out) {
        int mover = sq[from];
        for (int[] d : dirs) {
            int nf = f + d[0], nr = r + d[1];
            while (onBoard(nf, nr)) {
                int to = nr * 8 + nf;
                int occ = sq[to];
                if (occ == 0) {
                    out.add(new Move(from, to, null, false, false));
                } else {
                    if (colorOf(occ) != colorOf(mover)) out.add(new Move(from, to, null, false, false));
                    break;
                }
                nf += d[0]; nr += d[1];
            }
        }
    }

    private void genPawnMoves(int from, int f, int r, int sign, List<Move> out) {
        int startRank = sign == 1 ? 1 : 6;
        int promoRank = sign == 1 ? 7 : 0;
        int oneR = r + sign;
        if (onBoard(f, oneR) && sq[oneR * 8 + f] == 0) {
            addPawnMoveWithPromotion(from, oneR * 8 + f, promoRank, oneR, false, out);
            int twoR = r + 2 * sign;
            if (r == startRank && sq[twoR * 8 + f] == 0) {
                out.add(new Move(from, twoR * 8 + f, null, false, false));
            }
        }
        for (int df : new int[]{-1, 1}) {
            int nf = f + df;
            if (!onBoard(nf, oneR)) continue;
            int to = oneR * 8 + nf;
            int occ = sq[to];
            if (occ != 0 && colorOf(occ) != colorOf(sq[from])) {
                addPawnMoveWithPromotion(from, to, promoRank, oneR, false, out);
            } else if (to == epSquare && occ == 0) {
                out.add(new Move(from, to, null, false, true));
            }
        }
    }

    private void addPawnMoveWithPromotion(int from, int to, int promoRank, int destRank, boolean epCap, List<Move> out) {
        if (destRank == promoRank) {
            out.add(new Move(from, to, PieceType.QUEEN, false, epCap));
            out.add(new Move(from, to, PieceType.ROOK, false, epCap));
            out.add(new Move(from, to, PieceType.BISHOP, false, epCap));
            out.add(new Move(from, to, PieceType.KNIGHT, false, epCap));
        } else {
            out.add(new Move(from, to, null, false, epCap));
        }
    }

    private void genCastling(List<Move> out) {
        Color opp = sideToMove.opposite();
        if (sideToMove == Color.WHITE) {
            if (whiteCastleK && sq[5] == 0 && sq[6] == 0 && sq[4] == 6 && sq[7] == 4
                    && !isSquareAttacked(4, opp) && !isSquareAttacked(5, opp) && !isSquareAttacked(6, opp)) {
                out.add(new Move(4, 6, null, true, false));
            }
            if (whiteCastleQ && sq[1] == 0 && sq[2] == 0 && sq[3] == 0 && sq[4] == 6 && sq[0] == 4
                    && !isSquareAttacked(4, opp) && !isSquareAttacked(3, opp) && !isSquareAttacked(2, opp)) {
                out.add(new Move(4, 2, null, true, false));
            }
        } else {
            if (blackCastleK && sq[61] == 0 && sq[62] == 0 && sq[60] == -6 && sq[63] == -4
                    && !isSquareAttacked(60, opp) && !isSquareAttacked(61, opp) && !isSquareAttacked(62, opp)) {
                out.add(new Move(60, 62, null, true, false));
            }
            if (blackCastleQ && sq[57] == 0 && sq[58] == 0 && sq[59] == 0 && sq[60] == -6 && sq[56] == -4
                    && !isSquareAttacked(60, opp) && !isSquareAttacked(59, opp) && !isSquareAttacked(58, opp)) {
                out.add(new Move(60, 58, null, true, false));
            }
        }
    }

    @Override
    public boolean isCheckmate() { return isInCheck(sideToMove) && legalMoves().isEmpty(); }

    @Override
    public boolean isStalemate() { return !isInCheck(sideToMove) && legalMoves().isEmpty(); }

    // ------------------------------------------------------------- applying

    @Override
    public BoardAdapter playMove(Move move) {
        // re-resolve against our own legal move list so we always apply a move
        // this exact board produced (and therefore has the correct SAN attached)
        for (Move m : legalMoves()) {
            if (m.equals(move)) return applyRaw(m);
        }
        throw new IllegalArgumentException("Illegal move for this position: " + move);
    }

    private SimpleBoard applyRaw(Move m) {
        int[] nb = sq.clone();
        int mover = nb[m.from()];
        boolean isPawn = Math.abs(mover) == 1;
        boolean isCapture = nb[m.to()] != 0 || m.isEnPassantCapture();

        if (m.isEnPassantCapture()) {
            int capturedSq = sideToMove == Color.WHITE ? m.to() - 8 : m.to() + 8;
            nb[capturedSq] = 0;
        }

        nb[m.from()] = 0;
        if (m.promotion() != null) {
            int promoCode = switch (m.promotion()) {
                case QUEEN -> 5; case ROOK -> 4; case BISHOP -> 3; case KNIGHT -> 2;
                default -> throw new IllegalStateException();
            };
            nb[m.to()] = sideToMove == Color.WHITE ? promoCode : -promoCode;
        } else {
            nb[m.to()] = mover;
        }

        boolean nwck = whiteCastleK, nwcq = whiteCastleQ, nbck = blackCastleK, nbcq = blackCastleQ;
        if (m.isCastle()) {
            if (m.to() == 6) { nb[7] = 0; nb[5] = 4; }       // white O-O: rook h1->f1
            else if (m.to() == 2) { nb[0] = 0; nb[3] = 4; }  // white O-O-O: rook a1->d1
            else if (m.to() == 62) { nb[63] = 0; nb[61] = -4; } // black O-O
            else if (m.to() == 58) { nb[56] = 0; nb[59] = -4; } // black O-O-O
        }
        if (mover == 6) { nwck = false; nwcq = false; }
        if (mover == -6) { nbck = false; nbcq = false; }
        if (m.from() == 0 || m.to() == 0) nwcq = false;
        if (m.from() == 7 || m.to() == 7) nwck = false;
        if (m.from() == 56 || m.to() == 56) nbcq = false;
        if (m.from() == 63 || m.to() == 63) nbck = false;

        int newEp = -1;
        if (isPawn && Math.abs(m.to() - m.from()) == 16) {
            newEp = (m.to() + m.from()) / 2;
        }

        int newHalf = (isPawn || isCapture) ? 0 : halfmoveClock + 1;
        int newFull = fullmoveNumber + (sideToMove == Color.BLACK ? 1 : 0);

        return new SimpleBoard(nb, sideToMove.opposite(), nwck, nwcq, nbck, nbcq, newEp, newHalf, newFull);
    }

    @Override
    public Move findMoveBySan(String san) {
        String normalized = normalizeSan(san);
        for (Move m : legalMoves()) {
            if (normalizeSan(m.san()).equals(normalized)) return m;
        }
        throw new IllegalArgumentException("No legal move matches SAN '" + san + "' in position " + toFen());
    }

    private static String normalizeSan(String s) {
        return s.replace("0-0-0", "O-O-O").replace("0-0", "O-O")
                .replace("+", "").replace("#", "").replace("!", "").replace("?", "").trim();
    }

    // --------------------------------------------------------------- SAN

    private String sanFor(Move m, List<Move> allLegal) {
        String base;
        if (m.isCastle()) {
            base = (file(m.to()) == 6) ? "O-O" : "O-O-O";
        } else {
            int mover = sq[m.from()];
            PieceType pt = typeOf(mover);
            boolean capture = sq[m.to()] != 0 || m.isEnPassantCapture();
            StringBuilder sb = new StringBuilder();
            if (pt == PieceType.PAWN) {
                if (capture) sb.append((char) ('a' + file(m.from()))).append('x');
                sb.append(Move.squareName(m.to()));
                if (m.promotion() != null) sb.append('=').append(m.promotion().sanLetter());
            } else {
                sb.append(pt.sanLetter());
                boolean sameFileExists = false, sameRankExists = false, anyAmbiguous = false;
                for (Move o : allLegal) {
                    if (o.equals(m) || o.isCastle()) continue;
                    if (typeOf(sq[o.from()]) != pt || o.to() != m.to()) continue;
                    anyAmbiguous = true;
                    if (file(o.from()) == file(m.from())) sameFileExists = true;
                    if (rank(o.from()) == rank(m.from())) sameRankExists = true;
                }
                if (anyAmbiguous) {
                    if (!sameFileExists) sb.append((char) ('a' + file(m.from())));
                    else if (!sameRankExists) sb.append((char) ('1' + rank(m.from())));
                    else sb.append((char) ('a' + file(m.from()))).append((char) ('1' + rank(m.from())));
                }
                if (capture) sb.append('x');
                sb.append(Move.squareName(m.to()));
            }
            base = sb.toString();
        }
        SimpleBoard after = applyRaw(m);
        if (after.isInCheck(after.sideToMove)) {
            base += after.legalMoves().isEmpty() ? "#" : "+";
        }
        return base;
    }

    // --------------------------------------------------------------- FEN

    @Override
    public String toFen() {
        StringBuilder sb = new StringBuilder();
        for (int r = 7; r >= 0; r--) {
            int empty = 0;
            for (int f = 0; f < 8; f++) {
                int code = sq[r * 8 + f];
                if (code == 0) { empty++; continue; }
                if (empty > 0) { sb.append(empty); empty = 0; }
                sb.append(charFor(code));
            }
            if (empty > 0) sb.append(empty);
            if (r > 0) sb.append('/');
        }
        sb.append(' ').append(sideToMove == Color.WHITE ? 'w' : 'b').append(' ');
        String castling = "" + (whiteCastleK ? "K" : "") + (whiteCastleQ ? "Q" : "")
                + (blackCastleK ? "k" : "") + (blackCastleQ ? "q" : "");
        sb.append(castling.isEmpty() ? "-" : castling).append(' ');
        sb.append(epSquare == -1 ? "-" : Move.squareName(epSquare)).append(' ');
        sb.append(halfmoveClock).append(' ').append(fullmoveNumber);
        return sb.toString();
    }

    @Override
    public String positionKey() {
        String fullFen = toFen();
        String[] parts = fullFen.split(" ");
        return parts[0] + " " + parts[1] + " " + parts[2] + " " + parts[3]; // drop halfmove/fullmove
    }

    @Override
    public String toString() { return toFen(); }
}
