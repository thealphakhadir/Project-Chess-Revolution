package org.openchess.explorer.datasource;

import org.openchess.explorer.board.BoardAdapter;
import org.openchess.explorer.model.DataSourceType;
import org.openchess.explorer.model.GameSample;
import org.openchess.explorer.model.MoveStat;
import org.openchess.explorer.model.QueryFilter;

import java.util.List;

/**
 * A pluggable statistics source. Implementations back one of the "tabs" in
 * a typical opening explorer (Masters / Online / Personal — see
 * {@link DataSourceType}). Query is always by exact board position (FEN),
 * which is what makes transposition merging automatic for statistics: two
 * different move orders into the same position are, by construction, the
 * same query.
 */
public interface StatsProvider {

    DataSourceType sourceType();

    /** Human-readable name for UI labeling, e.g. "Lichess Masters DB", "Lichess Online (all players)". */
    String displayName();

    /** Per-candidate-move statistics for this exact position, respecting whatever parts of {@code filter} this source supports. */
    List<MoveStat> statsForPosition(BoardAdapter position, QueryFilter filter);

    /** Sample real games that reached this exact position, most relevant first, capped at {@code limit}. */
    List<GameSample> sampleGames(BoardAdapter position, QueryFilter filter, int limit);
}
