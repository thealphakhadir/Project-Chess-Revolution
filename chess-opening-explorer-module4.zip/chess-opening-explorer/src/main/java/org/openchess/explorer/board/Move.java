package org.openchess.explorer.board;

import java.util.Objects;

/**
 * A single move. {@code from}/{@code to} are 0-63 square indices
 * (a1=0 ... h8=63, file = sq%8, rank = sq/8). {@code san} is filled in by
 * whichever BoardAdapter produced the move (SAN is position-dependent, so it
 * can't be computed from from/to alone without disambiguation context).
 */
public final class Move {

    private final int from;
    private final int to;
    private final PieceType promotion; // null unless a pawn promotion
    private final boolean castle;
    private final boolean enPassantCapture;
    private String san; // set by the board that generated this move
    private final String uci;

    public Move(int from, int to, PieceType promotion, boolean castle, boolean enPassantCapture) {
        this.from = from;
        this.to = to;
        this.promotion = promotion;
        this.castle = castle;
        this.enPassantCapture = enPassantCapture;
        this.uci = squareName(from) + squareName(to) + (promotion == null ? "" : Character.toLowerCase(promotion.sanLetter()));
    }

    public int from() { return from; }
    public int to() { return to; }
    public PieceType promotion() { return promotion; }
    public boolean isCastle() { return castle; }
    public boolean isEnPassantCapture() { return enPassantCapture; }
    public String uci() { return uci; }
    public String san() { return san; }
    public void setSan(String san) { this.san = san; }

    public static String squareName(int sq) {
        int file = sq % 8;
        int rank = sq / 8;
        return "" + (char) ('a' + file) + (char) ('1' + rank);
    }

    public static int squareIndex(String name) {
        int file = name.charAt(0) - 'a';
        int rank = name.charAt(1) - '1';
        return rank * 8 + file;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Move m)) return false;
        return from == m.from && to == m.to && promotion == m.promotion;
    }

    @Override
    public int hashCode() { return Objects.hash(from, to, promotion); }

    @Override
    public String toString() { return san != null ? san : uci; }
}
