package org.openchess.explorer.datasource;

import org.openchess.explorer.board.BoardAdapter;
import org.openchess.explorer.model.*;
import org.openchess.explorer.util.Json;

import java.io.IOException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * "My games" / opponent-prep source: statistics restricted to one specific
 * player's own games, via Lichess's {@code /player} explorer endpoint. Set
 * {@link QueryFilter.Builder#player(String)} and
 * {@link QueryFilter.Builder#color(Color)} before querying — both are
 * required by the underlying endpoint. Requires a color because a player's
 * white repertoire and black repertoire are different questions.
 *
 * For games that live only on your own disk (not on Lichess), see
 * {@link LocalPgnPersonalProvider} instead — same {@link StatsProvider}
 * contract, different backing store.
 */
public final class LichessPersonalProvider implements StatsProvider {

    private static final String BASE = "https://explorer.lichess.ovh";
    private static final Duration TIMEOUT = Duration.ofSeconds(10);
    private final HttpClient http = HttpClient.newBuilder().connectTimeout(TIMEOUT).build();

    @Override
    public DataSourceType sourceType() { return DataSourceType.PERSONAL; }

    @Override
    public String displayName() { return "Lichess Personal (player games)"; }

    @Override
    public List<MoveStat> statsForPosition(BoardAdapter position, QueryFilter filter) {
        requirePlayerAndColor(filter);
        Map<String, Object> json = fetch(position, filter);
        if (json == null) return List.of();
        List<MoveStat> out = new ArrayList<>();
        for (Object o : Json.listVal(json, "moves")) {
            @SuppressWarnings("unchecked")
            Map<String, Object> mv = (Map<String, Object>) o;
            String san = Json.str(mv, "san");
            String uci = Json.str(mv, "uci");
            long w = orZero(Json.longVal(mv, "white"));
            long d = orZero(Json.longVal(mv, "draws"));
            long b = orZero(Json.longVal(mv, "black"));
            Integer perf = Json.intVal(mv, "performance");
            Double avgOpp = Json.doubleVal(mv, "averageOpponentRating");
            Map<String, Object> opening = Json.mapVal(mv, "opening");
            String eco = opening == null ? null : Json.str(opening, "eco");
            String name = opening == null ? null : Json.str(opening, "name");
            out.add(new MoveStat(san, uci, DataSourceType.PERSONAL, w, d, b, avgOpp, null, perf, null, eco, name));
        }
        return out;
    }

    @Override
    public List<GameSample> sampleGames(BoardAdapter position, QueryFilter filter, int limit) {
        requirePlayerAndColor(filter);
        Map<String, Object> json = fetch(position, filter);
        if (json == null) return List.of();
        List<GameSample> out = new ArrayList<>();
        for (Object o : Json.listVal(json, "recentGames")) {
            @SuppressWarnings("unchecked")
            Map<String, Object> g = (Map<String, Object>) o;
            String id = Json.str(g, "id");
            out.add(new GameSample(id, filter.colorOfInterest() == Color.WHITE ? filter.playerName() : "opponent",
                    filter.colorOfInterest() == Color.BLACK ? filter.playerName() : "opponent",
                    null, null, GameSample.Result.ONGOING, null, null, DataSourceType.PERSONAL,
                    "https://lichess.org/" + id));
            if (out.size() >= limit) break;
        }
        return out;
    }

    private void requirePlayerAndColor(QueryFilter filter) {
        if (filter == null || filter.playerName() == null || filter.colorOfInterest() == null) {
            throw new IllegalArgumentException(
                    "LichessPersonalProvider requires QueryFilter.player(name) and .color(WHITE/BLACK)");
        }
    }

    private Map<String, Object> fetch(BoardAdapter position, QueryFilter filter) {
        String url = BASE + "/player?fen=" + encode(position.toFen())
                + "&player=" + encode(filter.playerName())
                + "&color=" + filter.colorOfInterest().token();
        try {
            HttpRequest req = HttpRequest.newBuilder(URI.create(url))
                    .timeout(TIMEOUT).header("Accept", "application/x-ndjson").GET().build();
            HttpResponse<String> resp = http.send(req, HttpResponse.BodyHandlers.ofString());
            if (resp.statusCode() != 200) return null;
            // The /player endpoint streams newline-delimited JSON as it indexes; the final
            // line is the completed result, which is sufficient for a one-shot query.
            String body = resp.body().trim();
            int lastNewline = body.lastIndexOf('\n');
            String lastLine = lastNewline >= 0 ? body.substring(lastNewline + 1) : body;
            return Json.parseObject(lastLine);
        } catch (IOException | InterruptedException e) {
            if (e instanceof InterruptedException) Thread.currentThread().interrupt();
            return null;
        }
    }

    private static long orZero(Long v) { return v == null ? 0L : v; }
    private static String encode(String s) { return URLEncoder.encode(s, StandardCharsets.UTF_8); }
}
