package org.openchess.explorer.board;

import org.openchess.explorer.model.Color;
import java.util.List;

/**
 * The seam between this module and the project's actual chess engine
 * (Modules 1-3: board representation, legal move generation, FEN/SAN).
 *
 * If Modules 1-3 already expose a Board/Position class with legal-move
 * generation, write a thin adapter implementing this interface around it
 * and use that everywhere instead of {@link org.openchess.explorer.board.fallback.SimpleBoard}.
 * SimpleBoard exists purely so this module compiles and runs standalone
 * for development/demo purposes without depending on the rest of the
 * project; it is a reference implementation, not a competitor to Module 1.
 *
 * Implementations should be immutable: {@link #playMove(Move)} returns a
 * NEW BoardAdapter for the resulting position rather than mutating this one.
 * That makes the move tree in the {@code tree} package trivial to build
 * and safe to explore concurrently.
 */
public interface BoardAdapter {

    Color sideToMove();

    /** All legal moves from this position, each with {@link Move#san()} already populated. */
    List<Move> legalMoves();

    /** Play a legal move (as returned by {@link #legalMoves()} or {@link #findMoveBySan}) and return the resulting position. */
    BoardAdapter playMove(Move move);

    /** Find the legal move matching a SAN string (e.g. "Nf3", "O-O", "exd5", "e8=Q+"). Throws if none matches. */
    Move findMoveBySan(String san);

    /** Full FEN of the current position. */
    String toFen();

    /**
     * A transposition key: piece placement + side to move + castling rights +
     * en-passant target, WITHOUT halfmove/fullmove counters. Two positions
     * reached by different move orders must produce the same key so the
     * move-tree layer can merge them (see {@code tree.MoveTreeService}).
     */
    String positionKey();

    boolean isInCheck(Color side);

    boolean isCheckmate();

    boolean isStalemate();
}
