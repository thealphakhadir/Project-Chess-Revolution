package org.openchess.explorer.datasource;

import org.openchess.explorer.board.BoardAdapter;
import org.openchess.explorer.board.Move;
import org.openchess.explorer.model.*;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.function.Supplier;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Personal / "my games" source backed by a local PGN file — for self-prep
 * or opponent-prep from a game collection that isn't (or isn't only) on
 * Lichess. Parses the whole file once at construction and indexes every
 * position reached by every game, so lookups afterward are in-memory and
 * instant. For an online player's Lichess account instead, see
 * {@link LichessPersonalProvider}.
 *
 * PGN parsing here handles standard single-line-movetext exports: headers,
 * SAN movetext with move numbers, {comments}, (variations — skipped
 * entirely, only the mainline is indexed), $NAGs, and a trailing result
 * token. It has not been fuzzed against every PGN dialect in the wild; if
 * you feed it exports from an unusual source and games silently fail to
 * parse, check {@link #skippedGameCount()}.
 */
public final class LocalPgnPersonalProvider implements StatsProvider {

    private static final Pattern HEADER = Pattern.compile("\\[(\\w+)\\s+\"([^\"]*)\"\\]");
    private static final Pattern COMMENT = Pattern.compile("\\{[^}]*\\}", Pattern.DOTALL);
    private static final Pattern NAG = Pattern.compile("\\$\\d+");
    private static final Pattern MOVE_NUMBER = Pattern.compile("^\\d+\\.(\\.\\.)?$");
    private static final Pattern RESULT_TOKEN = Pattern.compile("^(1-0|0-1|1/2-1/2|\\*)$");

    private final String playerNameHint;
    private final Map<String, Map<String, MutableStat>> statsByPositionThenMove = new HashMap<>();
    private final Map<String, List<GameSample>> samplesByPosition = new HashMap<>();
    private int skippedGames = 0;
    private int parsedGames = 0;

    public LocalPgnPersonalProvider(Path pgnFile, String playerNameHint, Supplier<BoardAdapter> startingPositionFactory) throws IOException {
        this.playerNameHint = playerNameHint;
        String content = Files.readString(pgnFile);
        for (String gameText : splitGames(content)) {
            try {
                indexGame(gameText, startingPositionFactory);
                parsedGames++;
            } catch (RuntimeException e) {
                skippedGames++;
            }
        }
    }

    public int parsedGameCount() { return parsedGames; }
    public int skippedGameCount() { return skippedGames; }

    @Override
    public DataSourceType sourceType() { return DataSourceType.PERSONAL; }

    @Override
    public String displayName() { return "Local PGN (" + playerNameHint + ", " + parsedGames + " games)"; }

    @Override
    public List<MoveStat> statsForPosition(BoardAdapter position, QueryFilter filter) {
        Map<String, MutableStat> byMove = statsByPositionThenMove.get(position.positionKey());
        if (byMove == null) return List.of();
        List<MoveStat> out = new ArrayList<>();
        for (MutableStat s : byMove.values()) {
            Double avg = s.ratingSamples == 0 ? null : (double) s.ratingSum / s.ratingSamples;
            out.add(new MoveStat(s.san, s.uci, DataSourceType.PERSONAL, s.whiteWins, s.draws, s.blackWins,
                    avg, s.maxRating == Integer.MIN_VALUE ? null : s.maxRating, null, s.lastPlayedIso, null, null));
        }
        return out;
    }

    @Override
    public List<GameSample> sampleGames(BoardAdapter position, QueryFilter filter, int limit) {
        List<GameSample> all = samplesByPosition.getOrDefault(position.positionKey(), List.of());
        return all.size() <= limit ? all : all.subList(0, limit);
    }

    // ------------------------------------------------------------ parsing

    private List<String> splitGames(String content) {
        List<String> games = new ArrayList<>();
        Matcher m = Pattern.compile("(?=\\[Event )").matcher(content);
        List<Integer> starts = new ArrayList<>();
        while (m.find()) starts.add(m.start());
        if (starts.isEmpty()) {
            if (!content.isBlank()) games.add(content);
            return games;
        }
        for (int i = 0; i < starts.size(); i++) {
            int from = starts.get(i);
            int to = (i + 1 < starts.size()) ? starts.get(i + 1) : content.length();
            games.add(content.substring(from, to));
        }
        return games;
    }

    private void indexGame(String gameText, Supplier<BoardAdapter> startingPositionFactory) {
        Map<String, String> headers = new HashMap<>();
        Matcher hm = HEADER.matcher(gameText);
        int movetextStart = 0;
        while (hm.find()) {
            headers.put(hm.group(1), hm.group(2));
            movetextStart = hm.end();
        }
        String movetext = gameText.substring(movetextStart);
        movetext = COMMENT.matcher(movetext).replaceAll(" ");
        movetext = stripVariations(movetext);
        movetext = NAG.matcher(movetext).replaceAll(" ");

        String white = headers.getOrDefault("White", "?");
        String black = headers.getOrDefault("Black", "?");
        Integer whiteElo = parseIntOrNull(headers.get("WhiteElo"));
        Integer blackElo = parseIntOrNull(headers.get("BlackElo"));
        String resultHeader = headers.getOrDefault("Result", "*");
        String date = headers.get("Date");
        String event = headers.get("Event");
        String gameId = white + "_vs_" + black + "_" + (date == null ? "" : date) + "_" + System.identityHashCode(gameText);

        GameSample.Result result = switch (resultHeader) {
            case "1-0" -> GameSample.Result.WHITE_WIN;
            case "0-1" -> GameSample.Result.BLACK_WIN;
            case "1/2-1/2" -> GameSample.Result.DRAW;
            default -> GameSample.Result.ONGOING;
        };

        BoardAdapter board = startingPositionFactory.get();
        for (String token : movetext.trim().split("\\s+")) {
            if (token.isBlank()) continue;
            if (MOVE_NUMBER.matcher(token).matches()) continue;
            if (RESULT_TOKEN.matcher(token).matches()) break;
            String san = token.replaceFirst("^\\d+\\.(\\.\\.)?", "");
            if (san.isBlank()) continue;

            String posKeyBefore = board.positionKey();
            Move move;
            try {
                move = board.findMoveBySan(san);
            } catch (RuntimeException e) {
                break; // stop indexing this game at the first move we can't resolve
            }
            boolean whiteToMove = board.sideToMove() == Color.WHITE;
            Integer moverRating = whiteToMove ? whiteElo : blackElo;

            recordMove(posKeyBefore, move, whiteToMove, result, moverRating, date);
            recordSample(posKeyBefore, gameId, white, black, whiteElo, blackElo, result, date, event);

            board = board.playMove(move);
        }
        // also record the final position reached, with no further move (useful for "games that reached exactly this line")
        recordSample(board.positionKey(), gameId, white, black, whiteElo, blackElo, result, date, event);
    }

    private String stripVariations(String movetext) {
        StringBuilder out = new StringBuilder();
        int depth = 0;
        for (char c : movetext.toCharArray()) {
            if (c == '(') { depth++; continue; }
            if (c == ')') { if (depth > 0) depth--; continue; }
            if (depth == 0) out.append(c);
        }
        return out.toString();
    }

    private void recordMove(String posKeyBefore, Move move, boolean whiteToMove, GameSample.Result result,
                             Integer moverRating, String date) {
        Map<String, MutableStat> byMove = statsByPositionThenMove.computeIfAbsent(posKeyBefore, k -> new LinkedHashMap<>());
        MutableStat stat = byMove.computeIfAbsent(move.san(), k -> new MutableStat(move.san(), move.uci()));
        switch (result) {
            case WHITE_WIN -> stat.whiteWins++;
            case BLACK_WIN -> stat.blackWins++;
            case DRAW -> stat.draws++;
            default -> { /* ongoing/unknown result: counted in games via totalGames() only if we add a bucket; skip */ }
        }
        if (moverRating != null) {
            stat.ratingSum += moverRating;
            stat.ratingSamples++;
            stat.maxRating = Math.max(stat.maxRating, moverRating);
        }
        if (date != null && (stat.lastPlayedIso == null || date.compareTo(stat.lastPlayedIso) > 0)) {
            stat.lastPlayedIso = date;
        }
    }

    private void recordSample(String posKey, String id, String white, String black, Integer whiteElo, Integer blackElo,
                               GameSample.Result result, String date, String event) {
        List<GameSample> list = samplesByPosition.computeIfAbsent(posKey, k -> new ArrayList<>());
        if (list.size() < 50) { // cap memory use per position
            list.add(new GameSample(id, white, black, whiteElo, blackElo, result, date, event, DataSourceType.PERSONAL, null));
        }
    }

    private static Integer parseIntOrNull(String s) {
        if (s == null) return null;
        try { return Integer.parseInt(s.trim()); } catch (NumberFormatException e) { return null; }
    }

    private static final class MutableStat {
        final String san;
        final String uci;
        long whiteWins, draws, blackWins;
        long ratingSum = 0;
        int ratingSamples = 0;
        int maxRating = Integer.MIN_VALUE;
        String lastPlayedIso;

        MutableStat(String san, String uci) { this.san = san; this.uci = uci; }
    }
}
