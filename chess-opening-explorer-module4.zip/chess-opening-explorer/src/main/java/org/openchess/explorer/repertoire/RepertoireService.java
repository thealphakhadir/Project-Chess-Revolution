package org.openchess.explorer.repertoire;

import org.openchess.explorer.model.Color;
import org.openchess.explorer.util.Json;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

/**
 * Personal repertoire storage: save lines you intend to play, tag them by
 * color, attach notes, and query "what do I have prepared here" / "what's
 * the next book move in my own repertoire" for a given position. Backed by
 * a flat JSON file (no database needed) — swap the load/save methods for a
 * real DB-backed store later without touching the rest of the module,
 * since everything else talks to this class only through its public API.
 */
public final class RepertoireService {

    private final Path storageFile;
    private final List<RepertoireEntry> entries = new ArrayList<>();

    public RepertoireService(Path storageFile) {
        this.storageFile = storageFile;
        load();
    }

    public synchronized List<RepertoireEntry> all() { return List.copyOf(entries); }

    public synchronized RepertoireEntry add(String label, Color forColor, List<String> sanMoves, String notes) {
        String id = UUID.randomUUID().toString();
        RepertoireEntry entry = new RepertoireEntry(id, label, forColor, sanMoves, notes);
        entries.add(entry);
        save();
        return entry;
    }

    public synchronized void remove(String id) {
        entries.removeIf(e -> e.id().equals(id));
        save();
    }

    /** Every saved line consistent with the moves played so far, for the given side (or either, if null). */
    public synchronized List<RepertoireEntry> matching(List<String> playedSoFar, Color forColor) {
        List<RepertoireEntry> out = new ArrayList<>();
        for (RepertoireEntry e : entries) {
            if (forColor != null && e.forColor() != forColor) continue;
            if (e.matches(playedSoFar)) out.add(e);
        }
        return out;
    }

    /** "Practice mode" helper: distinct next-book-moves your own repertoire recommends from this position. */
    public synchronized Set<String> recommendedNextMoves(List<String> playedSoFar, Color forColor) {
        Set<String> out = new LinkedHashSet<>();
        for (RepertoireEntry e : matching(playedSoFar, forColor)) {
            String next = e.nextMoveAfter(playedSoFar);
            if (next != null) out.add(next);
        }
        return out;
    }

    // -------------------------------------------------------------- I/O

    @SuppressWarnings("unchecked")
    private synchronized void load() {
        entries.clear();
        if (!Files.exists(storageFile)) return;
        try {
            String content = Files.readString(storageFile, StandardCharsets.UTF_8);
            if (content.isBlank()) return;
            Object parsed = Json.parse(content);
            for (Object o : (List<Object>) parsed) {
                Map<String, Object> m = (Map<String, Object>) o;
                String id = Json.str(m, "id");
                String label = Json.str(m, "label");
                Color color = Color.valueOf(Json.str(m, "forColor"));
                List<String> moves = new ArrayList<>();
                for (Object mv : Json.listVal(m, "sanMoves")) moves.add(String.valueOf(mv));
                String notes = Json.str(m, "notes");
                entries.add(new RepertoireEntry(id, label, color, moves, notes));
            }
        } catch (IOException e) {
            throw new RuntimeException("Failed to load repertoire from " + storageFile, e);
        }
    }

    private synchronized void save() {
        List<Map<String, Object>> out = new ArrayList<>();
        for (RepertoireEntry e : entries) {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("id", e.id());
            m.put("label", e.label());
            m.put("forColor", e.forColor().name());
            m.put("sanMoves", e.sanMoves());
            m.put("notes", e.notes());
            out.add(m);
        }
        try {
            StringBuilder sb = new StringBuilder("[");
            for (int i = 0; i < out.size(); i++) {
                if (i > 0) sb.append(',');
                sb.append(Json.writeObject(out.get(i)));
            }
            sb.append(']');
            if (storageFile.getParent() != null) Files.createDirectories(storageFile.getParent());
            Files.writeString(storageFile, sb.toString(), StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw new RuntimeException("Failed to save repertoire to " + storageFile, e);
        }
    }
}
