package org.openchess.explorer.datasource;

import org.openchess.explorer.board.BoardAdapter;
import org.openchess.explorer.model.DataSourceType;
import org.openchess.explorer.model.GameSample;
import org.openchess.explorer.model.MoveStat;
import org.openchess.explorer.model.QueryFilter;

import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Fans a query out to every registered {@link StatsProvider} in parallel
 * (masters / online / personal, and whatever else you register — nothing
 * here is hardcoded to Lichess) and either keeps the per-source breakdown
 * or blends it into one merged view, matching the "tabs vs combined" choice
 * real explorers offer.
 */
public final class AggregatingStatsProvider implements AutoCloseable {

    private static final Logger LOG = Logger.getLogger(AggregatingStatsProvider.class.getName());

    private final List<StatsProvider> providers;
    private final ExecutorService executor;

    public AggregatingStatsProvider(List<StatsProvider> providers) {
        this.providers = List.copyOf(providers);
        this.executor = Executors.newFixedThreadPool(Math.max(1, providers.size()));
    }

    public List<StatsProvider> providers() { return providers; }

    /** Per-source breakdown — what a tabbed UI ("Masters" | "Online" | "Personal") would show. */
    public Map<DataSourceType, List<MoveStat>> statsBySource(BoardAdapter position, QueryFilter filter) {
        List<CompletableFuture<Map.Entry<DataSourceType, List<MoveStat>>>> futures = new ArrayList<>();
        for (StatsProvider p : providers) {
            futures.add(CompletableFuture.supplyAsync(() -> {
                try {
                    return Map.entry(p.sourceType(), p.statsForPosition(position, filter));
                } catch (RuntimeException e) {
                    LOG.log(Level.WARNING, "Provider " + p.displayName() + " failed, treating as empty", e);
                    return Map.entry(p.sourceType(), List.<MoveStat>of());
                }
            }, executor));
        }
        Map<DataSourceType, List<MoveStat>> out = new EnumMap<>(DataSourceType.class);
        for (var f : futures) {
            var e = f.join();
            out.put(e.getKey(), e.getValue());
        }
        return out;
    }

    public Map<DataSourceType, List<GameSample>> samplesBySource(BoardAdapter position, QueryFilter filter, int limit) {
        List<CompletableFuture<Map.Entry<DataSourceType, List<GameSample>>>> futures = new ArrayList<>();
        for (StatsProvider p : providers) {
            futures.add(CompletableFuture.supplyAsync(() -> {
                try {
                    return Map.entry(p.sourceType(), p.sampleGames(position, filter, limit));
                } catch (RuntimeException e) {
                    LOG.log(Level.WARNING, "Provider " + p.displayName() + " failed, treating as empty", e);
                    return Map.entry(p.sourceType(), List.<GameSample>of());
                }
            }, executor));
        }
        Map<DataSourceType, List<GameSample>> out = new EnumMap<>(DataSourceType.class);
        for (var f : futures) {
            var e = f.join();
            out.put(e.getKey(), e.getValue());
        }
        return out;
    }

    /** All registered sources blended into one pool per move (same-SAN stats summed/averaged across sources). */
    public List<MoveStat> mergedStats(BoardAdapter position, QueryFilter filter) {
        Map<DataSourceType, List<MoveStat>> bySource = statsBySource(position, filter);
        Map<String, MoveStat> merged = new LinkedHashMap<>();
        for (List<MoveStat> list : bySource.values()) {
            for (MoveStat stat : list) {
                merged.merge(stat.sanMove(), stat, MoveStat::mergedWith);
            }
        }
        return new ArrayList<>(merged.values());
    }

    @Override
    public void close() { executor.shutdown(); }
}
