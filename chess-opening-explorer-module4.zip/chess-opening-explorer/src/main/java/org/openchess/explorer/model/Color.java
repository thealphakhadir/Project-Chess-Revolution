package org.openchess.explorer.model;

public enum Color {
    WHITE, BLACK;

    public Color opposite() {
        return this == WHITE ? BLACK : WHITE;
    }

    /** Lowercase token as used in query params / FEN side-to-move field. */
    public String token() {
        return this == WHITE ? "white" : "black";
    }
}
