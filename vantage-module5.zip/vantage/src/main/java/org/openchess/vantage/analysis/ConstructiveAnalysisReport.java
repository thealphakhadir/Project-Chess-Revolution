package org.openchess.vantage.analysis;

/**
 * Full report shape from Sagacious's constructiveAnalysis(). Broadcast
 * fan-out only ever forwards the "lightened" subset (evalBar,
 * kingSafetyBars, bestMoveSan, depthReached) to the shared audience — see
 * {@code broadcast.BroadcastChannel#lightenForBroadcast}. naturalMoveOverlaySummary
 * and aiCommentary are per-viewer-ELO concepts, only populated for a
 * personalized single-viewer request (Part 4 of the design doc), never for
 * the shared broadcast stream.
 */
public record ConstructiveAnalysisReport(EvalBar evalBar, KingSafetyBars kingSafetyBars, String bestMoveSan,
                                          int depthReached, String naturalMoveOverlaySummary, String aiCommentary) {

    /** The subset every spectator gets, regardless of viewer ELO or personalization requests. */
    public ConstructiveAnalysisReport lightenedForBroadcast() {
        return new ConstructiveAnalysisReport(evalBar, kingSafetyBars, bestMoveSan, depthReached, null, null);
    }
}
