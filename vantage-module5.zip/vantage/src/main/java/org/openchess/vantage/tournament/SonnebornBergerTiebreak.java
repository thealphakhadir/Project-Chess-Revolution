package org.openchess.vantage.tournament;

import org.openchess.vantage.model.StandingsRow;
import org.openchess.vantage.model.Tournament;

/**
 * Sonneborn-Berger: for each opponent you beat, add their current total
 * score; for each you drew, add half their score; losses contribute
 * nothing. Standard, well-defined tiebreak for round-robin events (used at
 * elite level, e.g. classical world championship tiebreak history) —
 * unlike Swiss's Buchholz family, there's no ambiguity here about which
 * "opponents" count, since round robin means everyone plays everyone.
 */
public final class SonnebornBergerTiebreak implements TiebreakStrategy {

    private static final String KEY = "sonnebornBerger";

    @Override
    public void recomputeTiebreaks(Tournament tournament) {
        for (StandingsRow row : tournament.standingsByPlayer().values()) {
            double sb = 0.0;
            for (String opponent : tournament.playerIds()) {
                if (opponent.equals(row.playerId())) continue;
                Double scoreAgainst = tournament.headToHead(row.playerId(), opponent);
                if (scoreAgainst == null) continue; // haven't played yet
                StandingsRow opponentRow = tournament.standingsByPlayer().get(opponent);
                if (opponentRow == null) continue;
                sb += scoreAgainst * opponentRow.points();
            }
            row.setTiebreak(KEY, sb);
        }
    }
}
