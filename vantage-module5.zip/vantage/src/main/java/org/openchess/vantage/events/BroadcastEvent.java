package org.openchess.vantage.events;

/**
 * Mirrors the design doc's {@code { type, gameId, payload }} shape exactly
 * — this is what {@code sendToConnection} pushes down whatever transport
 * (WebSocket, SSE, ...) a real {@code SpectatorConnection} wraps.
 * {@code payload} is intentionally untyped here (matching the doc); callers
 * on the wire side serialize it (e.g. to JSON) however their transport wants.
 */
public record BroadcastEvent(EventType type, String gameId, Object payload) {

    public enum EventType {
        GAME_SNAPSHOT, MOVE_PLAYED, EVAL_UPDATE, EVAL_FINAL,
        CHAT_MESSAGE, TOURNAMENT_BOARDS_UPDATE, GAME_FINISHED
    }
}
