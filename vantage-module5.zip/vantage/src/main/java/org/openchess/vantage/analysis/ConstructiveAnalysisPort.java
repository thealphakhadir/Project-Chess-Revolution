package org.openchess.vantage.analysis;

/**
 * The seam into Sagacious's constructiveAnalysis() — this module calls
 * ONLY through this interface and never re-implements evaluation itself
 * (Part 7 of the design doc: "REUSED AS-IS"). Wrap your real
 * constructiveAnalysis() entry point in an implementation of this and wire
 * it in at startup; {@code fallback.SimulatedConstructiveAnalysisPort}
 * exists solely so this module compiles and demos without Sagacious
 * present.
 */
public interface ConstructiveAnalysisPort {

    /** Async by contract — callbacks may fire on another thread; implementations here are thread-safe about it. */
    void analyze(ConstructiveAnalysisRequest request, AnalysisCallbacks callbacks);
}
