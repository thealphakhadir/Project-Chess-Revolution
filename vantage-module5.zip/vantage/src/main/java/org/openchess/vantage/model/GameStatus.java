package org.openchess.vantage.model;

public enum GameStatus { ONGOING, FINISHED }
