package org.openchess.vantage.broadcast;

import java.util.function.Predicate;

/**
 * Default {@link DelayPolicy}: delay tournament boards that have concurrent
 * siblings a player might be able to peek at (Part 3 of the design doc),
 * zero delay otherwise. Takes the "is this a tournament board with
 * concurrent siblings" check as a {@code Predicate} rather than a direct
 * reference to {@code tournament.TournamentService}, so the broadcast
 * package doesn't have to depend on the tournament package — wire the
 * actual check at the composition root ({@code service.VantageService}).
 */
public final class TournamentAwareDelayPolicy implements DelayPolicy {

    public static final int DEFAULT_TOURNAMENT_DELAY_SECONDS = 900; // 15 minutes, matching the doc's example

    private final Predicate<String> isPartOfTournamentWithConcurrentBoards;
    private final int tournamentDelaySeconds;

    public TournamentAwareDelayPolicy(Predicate<String> isPartOfTournamentWithConcurrentBoards) {
        this(isPartOfTournamentWithConcurrentBoards, DEFAULT_TOURNAMENT_DELAY_SECONDS);
    }

    public TournamentAwareDelayPolicy(Predicate<String> isPartOfTournamentWithConcurrentBoards, int tournamentDelaySeconds) {
        this.isPartOfTournamentWithConcurrentBoards = isPartOfTournamentWithConcurrentBoards;
        this.tournamentDelaySeconds = tournamentDelaySeconds;
    }

    @Override
    public int delaySecondsFor(String gameId) {
        return isPartOfTournamentWithConcurrentBoards.test(gameId) ? tournamentDelaySeconds : 0;
    }
}
