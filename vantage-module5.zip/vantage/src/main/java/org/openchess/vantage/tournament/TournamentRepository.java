package org.openchess.vantage.tournament;

import org.openchess.vantage.model.Tournament;

/** Persistence seam — {@code persistTournament} / {@code getTournament} from Part 5 of the design doc. */
public interface TournamentRepository {

    void persist(Tournament tournament);

    Tournament find(String tournamentId);
}
