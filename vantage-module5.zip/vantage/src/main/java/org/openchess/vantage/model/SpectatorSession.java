package org.openchess.vantage.model;

import org.openchess.vantage.transport.SpectatorConnection;

import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/** A connected viewer. Anonymous viewing is allowed (userId may be null) — matching the design doc's intent. */
public final class SpectatorSession {

    private final String sessionId;
    private final String userId; // nullable
    private final SpectatorConnection connection;
    private final Set<String> subscribedGameIds = ConcurrentHashMap.newKeySet();

    public SpectatorSession(String sessionId, String userId, SpectatorConnection connection) {
        this.sessionId = sessionId;
        this.userId = userId;
        this.connection = connection;
    }

    public String sessionId() { return sessionId; }
    public String userId() { return userId; }
    public boolean isAnonymous() { return userId == null; }
    public SpectatorConnection connection() { return connection; }
    public Set<String> subscribedGameIds() { return subscribedGameIds; }

    @Override
    public boolean equals(Object o) {
        return o instanceof SpectatorSession s && s.sessionId.equals(sessionId);
    }

    @Override
    public int hashCode() { return sessionId.hashCode(); }
}
