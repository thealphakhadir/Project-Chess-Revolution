package org.openchess.vantage.tournament;

/**
 * Seam to whatever module actually creates/runs games — Part 5's referenced
 * {@code createGame(white, black, timeControl)}. Vantage schedules and
 * broadcasts tournament games; it doesn't run them.
 */
public interface GameLifecyclePort {

    String createGame(String whitePlayer, String blackPlayer, long initialMs, long incrementMs);
}
