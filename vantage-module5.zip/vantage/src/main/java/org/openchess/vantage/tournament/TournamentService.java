package org.openchess.vantage.tournament;

import org.openchess.vantage.broadcast.BroadcastChannel;
import org.openchess.vantage.broadcast.BroadcastHub;
import org.openchess.vantage.model.*;

import java.time.Instant;
import java.util.*;

/**
 * Part 5 of the design doc. Pairing/tiebreak logic is delegated per-format
 * to {@link PairingStrategy}/{@link TiebreakStrategy} — only
 * {@code ROUND_ROBIN} has a registered strategy out of the box; requesting
 * another format throws a clear error rather than silently doing something
 * wrong (see the design doc's own "Honest note" on why Swiss et al. aren't
 * pseudocoded, let alone implemented, here).
 */
public final class TournamentService {

    private final TournamentRepository repository;
    private final BroadcastHub hub;
    private final GameLifecyclePort gameLifecycle;
    private final Map<TournamentFormat, PairingStrategy> pairingStrategies;
    private final Map<TournamentFormat, TiebreakStrategy> tiebreakStrategies;

    public TournamentService(TournamentRepository repository, BroadcastHub hub, GameLifecyclePort gameLifecycle,
                              Map<TournamentFormat, PairingStrategy> pairingStrategies,
                              Map<TournamentFormat, TiebreakStrategy> tiebreakStrategies) {
        this.repository = repository;
        this.hub = hub;
        this.gameLifecycle = gameLifecycle;
        this.pairingStrategies = pairingStrategies;
        this.tiebreakStrategies = tiebreakStrategies;
    }

    public Tournament createTournament(String name, TournamentFormat format, List<String> players) {
        if (!pairingStrategies.containsKey(format)) {
            throw new UnsupportedOperationException("No PairingStrategy registered for " + format
                    + " — see PairingStrategy's Javadoc on why only ROUND_ROBIN ships by default.");
        }
        Tournament tournament = new Tournament(UUID.randomUUID().toString(), name, format, players);
        repository.persist(tournament);
        return tournament;
    }

    public Round startRound(String tournamentId, int roundNumber) {
        Tournament tournament = requireTournament(tournamentId);
        PairingStrategy strategy = pairingStrategies.get(tournament.format());
        List<Pairing> generated = strategy.generatePairings(tournament, roundNumber);

        Round round = new Round(roundNumber);
        round.setStartTime(Instant.now());
        round.setStatus(RoundStatus.LIVE);

        List<String> boardGameIds = new ArrayList<>();
        int concurrentBoardCount = (int) generated.stream().filter(p -> p.blackPlayer() != null).count();

        for (Pairing pairing : generated) {
            if (pairing.blackPlayer() == null) {
                // bye — no opponent, no game, award the point directly
                StandingsRow row = tournament.standingsByPlayer().get(pairing.whitePlayer());
                if (row != null) { row.addPoints(1.0); row.incrementGamesPlayed(); }
                round.addPairing(pairing);
                continue;
            }
            String gameId = gameLifecycle.createGame(pairing.whitePlayer(), pairing.blackPlayer(),
                    tournament.timeControlInitialMs(), tournament.timeControlIncrementMs());
            Pairing withGame = new Pairing(pairing.whitePlayer(), pairing.blackPlayer(), gameId, pairing.boardNumber());
            round.addPairing(withGame);
            boardGameIds.add(gameId);

            // Auto-broadcast every tournament board (Part 5: "what makes a tournament page different from a list of private games")
            hub.subscribeChannelToTournamentPage(gameId, concurrentBoardCount > 1);
        }

        tournament.rounds().add(round);
        tournament.setBoards(boardGameIds);
        tournament.setStatus(TournamentStatus.LIVE);
        repository.persist(tournament);
        return round;
    }

    public void onTournamentGameFinished(String tournamentId, String gameId, GameResult result) {
        Tournament tournament = requireTournament(tournamentId);
        hub.onGameFinished(gameId, result);
        updateStandings(tournament, gameId, result);
        checkAndAdvanceRoundIfAllBoardsComplete(tournament, gameId);
        repository.persist(tournament);
    }

    private void updateStandings(Tournament tournament, String gameId, GameResult result) {
        Pairing pairing = findPairing(tournament, gameId);
        if (pairing == null) return;

        double whitePoints = switch (result) {
            case WHITE_WIN -> 1.0;
            case BLACK_WIN -> 0.0;
            case DRAW -> 0.5;
            case ONGOING -> 0.0;
        };
        double blackPoints = switch (result) {
            case WHITE_WIN -> 0.0;
            case BLACK_WIN -> 1.0;
            case DRAW -> 0.5;
            case ONGOING -> 0.0;
        };

        StandingsRow whiteRow = tournament.standingsByPlayer().get(pairing.whitePlayer());
        StandingsRow blackRow = tournament.standingsByPlayer().get(pairing.blackPlayer());
        if (whiteRow != null) { whiteRow.addPoints(whitePoints); whiteRow.incrementGamesPlayed(); }
        if (blackRow != null) { blackRow.addPoints(blackPoints); blackRow.incrementGamesPlayed(); }

        tournament.recordHeadToHead(pairing.whitePlayer(), pairing.blackPlayer(), whitePoints);
        tournament.recordHeadToHead(pairing.blackPlayer(), pairing.whitePlayer(), blackPoints);

        TiebreakStrategy tiebreak = tiebreakStrategies.get(tournament.format());
        if (tiebreak != null) tiebreak.recomputeTiebreaks(tournament);

        assignRanks(tournament);
    }

    private void assignRanks(Tournament tournament) {
        List<StandingsRow> rows = new ArrayList<>(tournament.standingsByPlayer().values());
        rows.sort((a, b) -> {
            int byPoints = Double.compare(b.points(), a.points());
            if (byPoints != 0) return byPoints;
            double aTb = a.tiebreakScores().values().stream().mapToDouble(Double::doubleValue).sum();
            double bTb = b.tiebreakScores().values().stream().mapToDouble(Double::doubleValue).sum();
            return Double.compare(bTb, aTb);
        });
        for (int i = 0; i < rows.size(); i++) rows.get(i).setRank(i + 1);
    }

    private void checkAndAdvanceRoundIfAllBoardsComplete(Tournament tournament, String gameId) {
        Round round = tournament.currentRound();
        if (round == null) return;
        round.gameIdsWithResults().add(gameId);

        long realGamesThisRound = round.pairings().stream().filter(p -> p.gameId() != null).count();
        if (round.gameIdsWithResults().size() >= realGamesThisRound) {
            round.setStatus(RoundStatus.COMPLETE);
            // Deliberately NOT auto-starting the next round or auto-finishing the tournament here —
            // that's a scheduling decision (how many rounds, break between rounds, manual pairing
            // review) that belongs to whatever's driving the event, not this module. Call
            // startRound() again for the next round, or mark the tournament FINISHED, explicitly.
        }
    }

    public Map<String, Object> getTournamentPageData(String tournamentId) {
        Tournament tournament = requireTournament(tournamentId);
        Round current = tournament.currentRound();

        List<Map<String, Object>> boards = new ArrayList<>();
        for (String gameId : tournament.boards()) {
            BroadcastChannel channel = hub.channelFor(gameId);
            Map<String, Object> board = new LinkedHashMap<>();
            board.put("gameId", gameId);
            board.put("snapshot", channel == null ? null : channel.lastBroadcastState());
            board.put("evalBar", channel == null || channel.latestConstructiveAnalysis() == null
                    ? null : channel.latestConstructiveAnalysis().evalBar());
            boards.add(board);
        }

        Map<String, Object> info = new LinkedHashMap<>();
        info.put("name", tournament.name());
        info.put("format", tournament.format());
        info.put("status", tournament.status());

        Map<String, Object> page = new LinkedHashMap<>();
        page.put("info", info);
        page.put("currentRound", current);
        page.put("boards", boards);
        page.put("standings", tournament.standingsSorted());
        return page;
    }

    private Pairing findPairing(Tournament tournament, String gameId) {
        for (Round round : tournament.rounds()) {
            for (Pairing p : round.pairings()) {
                if (gameId.equals(p.gameId())) return p;
            }
        }
        return null;
    }

    private Tournament requireTournament(String tournamentId) {
        Tournament t = repository.find(tournamentId);
        if (t == null) throw new IllegalArgumentException("No tournament with id " + tournamentId);
        return t;
    }
}
