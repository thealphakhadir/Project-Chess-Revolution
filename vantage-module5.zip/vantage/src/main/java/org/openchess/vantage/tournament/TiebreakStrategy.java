package org.openchess.vantage.tournament;

import org.openchess.vantage.model.Tournament;

/**
 * Pluggable tiebreak computation. {@link SonnebornBergerTiebreak} ships as
 * the reference implementation, appropriate for round robin. Swiss events
 * conventionally use Buchholz/median-Buchholz instead — a natural
 * extension point once a Swiss {@link PairingStrategy} exists to pair
 * against.
 */
public interface TiebreakStrategy {

    void recomputeTiebreaks(Tournament tournament);
}
