package org.openchess.vantage.model;

import java.util.Collections;
import java.util.List;

/**
 * Vantage's own view of a game's broadcast-relevant state. Position is
 * carried as FEN, not a board object — Vantage doesn't own game truth or
 * chess rules; it receives updates from whatever module does (see
 * {@code broadcast.GameStateSource}), which is exactly the "fan-out, not
 * re-derivation" boundary the design doc draws.
 */
public record LiveGame(String gameId, String whitePlayer, String blackPlayer, String currentPositionFen,
                        List<String> moveHistorySan, ClockState clock, GameStatus status, GameResult result,
                        int broadcastDelaySeconds) {

    public LiveGame {
        moveHistorySan = List.copyOf(moveHistorySan);
    }

    public LiveGame withMovePlayed(String sanMove, String newPositionFen, ClockState newClock) {
        List<String> updated = new java.util.ArrayList<>(moveHistorySan);
        updated.add(sanMove);
        return new LiveGame(gameId, whitePlayer, blackPlayer, newPositionFen,
                Collections.unmodifiableList(updated), newClock, status, result, broadcastDelaySeconds);
    }

    public LiveGame withFinished(GameResult finalResult) {
        return new LiveGame(gameId, whitePlayer, blackPlayer, currentPositionFen,
                moveHistorySan, clock, GameStatus.FINISHED, finalResult, broadcastDelaySeconds);
    }
}
