package org.openchess.vantage.tournament;

import org.openchess.vantage.model.Pairing;
import org.openchess.vantage.model.Tournament;

import java.util.List;

/**
 * Pluggable pairing algorithm, one per {@code TournamentFormat}. Only
 * {@link RoundRobinPairingStrategy} ships fully implemented — see the
 * design doc's own "Honest note": Swiss pairing (color balancing, avoiding
 * repeat pairings, byes, FIDE's multi-page rulebook) is a real,
 * self-contained problem that deserves its own design pass rather than a
 * bolt-on here. Implement {@code SwissPairingStrategy} /
 * {@code KnockoutPairingStrategy} / {@code ArenaPairingStrategy} the same
 * way when you're ready to give each the attention it needs.
 */
public interface PairingStrategy {

    /** A sentinel opponent id meaning "this player sits out the round" (odd player count). */
    String BYE = null;

    List<Pairing> generatePairings(Tournament tournament, int roundNumber);
}
