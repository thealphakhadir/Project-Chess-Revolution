package org.openchess.vantage.moderation;

public record ModerationVerdict(Outcome outcome, String reason) {

    public enum Outcome { ALLOW, FLAGGED_FOR_REVIEW, BLOCKED }

    public static ModerationVerdict allow() { return new ModerationVerdict(Outcome.ALLOW, null); }
    public boolean isBlocked() { return outcome == Outcome.BLOCKED; }
}
