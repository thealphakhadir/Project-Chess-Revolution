package org.openchess.vantage.model;

public enum RoundStatus { SCHEDULED, LIVE, COMPLETE }
