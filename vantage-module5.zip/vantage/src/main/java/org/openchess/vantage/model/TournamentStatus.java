package org.openchess.vantage.model;

public enum TournamentStatus { UPCOMING, LIVE, FINISHED }
