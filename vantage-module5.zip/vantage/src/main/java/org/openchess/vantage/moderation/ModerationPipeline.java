package org.openchess.vantage.moderation;

/**
 * The seam into Vanguard's moderation intake. Spectator chat routes
 * through the SAME pipeline as player chat (Part 4 / Part 7 of the design
 * doc: "not a parallel system") — wrap Vanguard's real intake/triage/
 * human-review gate in an implementation of this rather than building a
 * second moderation system here. {@code fallback.PassthroughModerationPipeline}
 * is a placeholder for standalone demo purposes only — it is NOT a
 * moderation system and must not be used for anything a real user sees.
 */
public interface ModerationPipeline {

    ModerationVerdict screen(ChatMessageEvent event);
}
