package org.openchess.vantage.broadcast;

/**
 * Part 0.2 / Part 3's {@code determineDelay}: a first-class integrity
 * concern, not an afterthought. Pluggable so you can layer in more rules
 * (explicit "sensitive" flag on a broadcast, per-organizer override, etc.)
 * without touching {@link BroadcastHub}.
 */
public interface DelayPolicy {

    int delaySecondsFor(String gameId);
}
