package org.openchess.vantage.analysis;

import java.util.function.Consumer;

public interface AnalysisCallbacks {

    void onStreamUpdate(ConstructiveAnalysisReport partial);

    void onComplete(ConstructiveAnalysisReport finalReport);

    static AnalysisCallbacks of(Consumer<ConstructiveAnalysisReport> streamUpdateHandler,
                                 Consumer<ConstructiveAnalysisReport> completeHandler) {
        return new AnalysisCallbacks() {
            @Override public void onStreamUpdate(ConstructiveAnalysisReport partial) { streamUpdateHandler.accept(partial); }
            @Override public void onComplete(ConstructiveAnalysisReport finalReport) { completeHandler.accept(finalReport); }
        };
    }
}
