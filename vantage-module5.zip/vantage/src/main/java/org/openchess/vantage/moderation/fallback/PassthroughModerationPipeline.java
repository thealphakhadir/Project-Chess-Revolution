package org.openchess.vantage.moderation.fallback;

import org.openchess.vantage.moderation.ChatMessageEvent;
import org.openchess.vantage.moderation.ModerationPipeline;
import org.openchess.vantage.moderation.ModerationVerdict;

import java.util.Set;

/**
 * Standalone-demo placeholder ONLY. This is a trivial blocklist check, not
 * a moderation system, and exists purely so {@code Main} has something to
 * call so the module runs without Vanguard present. Wire in the real
 * {@link ModerationPipeline} backed by Vanguard before any real user's
 * chat message reaches this module.
 */
public final class PassthroughModerationPipeline implements ModerationPipeline {

    // A handful of placeholder terms so the demo can show a BLOCKED path — not remotely
    // representative of what real moderation needs to catch. Do not extend this list;
    // replace this whole class with the real Vanguard integration instead.
    private static final Set<String> DEMO_BLOCKLIST = Set.of("cheater", "idiot");

    @Override
    public ModerationVerdict screen(ChatMessageEvent event) {
        String lower = event.message().toLowerCase();
        for (String term : DEMO_BLOCKLIST) {
            if (lower.contains(term)) {
                return new ModerationVerdict(ModerationVerdict.Outcome.BLOCKED, "demo blocklist match: " + term);
            }
        }
        return ModerationVerdict.allow();
    }
}
