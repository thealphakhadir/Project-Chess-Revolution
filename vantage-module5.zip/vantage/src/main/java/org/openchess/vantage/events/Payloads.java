package org.openchess.vantage.events;

import org.openchess.vantage.analysis.ConstructiveAnalysisReport;
import org.openchess.vantage.model.ClockState;
import org.openchess.vantage.model.LiveGame;

public final class Payloads {

    private Payloads() {}

    /** Sent immediately on subscribe (Part 3) so a new viewer doesn't wait for the next move to see the board. */
    public record GameSnapshotPayload(LiveGame game, ConstructiveAnalysisReport analysis) {}

    public record MovePlayedPayload(String sanMove, String positionFen, ClockState clock) {}

    /** Used for both EVAL_UPDATE (streaming) and EVAL_FINAL — same shape, different point in the search. */
    public record EvalPayload(ConstructiveAnalysisReport report) {}

    public record ChatMessagePayload(String userId, String message, long timestampEpochMs) {}

    public record GameFinishedPayload(LiveGame finalGame) {}
}
