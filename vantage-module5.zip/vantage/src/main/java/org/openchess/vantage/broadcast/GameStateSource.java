package org.openchess.vantage.broadcast;

import org.openchess.vantage.model.LiveGame;

/**
 * Vantage doesn't own game truth — it broadcasts it. Wire this to whatever
 * module actually runs live games (the real-time play server discussed
 * alongside this module) to fetch a game's current state when a broadcast
 * channel is first created (Part 3's {@code fetchGameState}).
 */
public interface GameStateSource {

    LiveGame fetchGameState(String gameId);
}
