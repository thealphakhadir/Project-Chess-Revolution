package org.openchess.vantage.analysis;

/** BACKGROUND/STANDARD are what a broadcast fan-out asks for (Part 2 of the design doc: appropriate for a shared feed, not a per-user deep dive); DEEP is for personalized per-viewer requests (Part 4). */
public enum AnalysisTier { BACKGROUND, STANDARD, DEEP }
