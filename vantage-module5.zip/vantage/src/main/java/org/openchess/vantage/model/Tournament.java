package org.openchess.vantage.model;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Mutable aggregate root, matching the doc's Part 5 (rounds/standings/boards all fill in over the tournament's life). */
public final class Tournament {

    private final String tournamentId;
    private final String name;
    private final TournamentFormat format;
    private final List<String> playerIds;
    private final List<Round> rounds = new ArrayList<>();
    private final Map<String, StandingsRow> standingsByPlayer = new LinkedHashMap<>();
    private List<String> boards = new ArrayList<>(); // active gameIds for the current round
    private TournamentStatus status;
    private long timeControlInitialMs = 600_000;
    private long timeControlIncrementMs = 5_000;
    private final Map<String, Map<String, Double>> headToHeadPoints = new LinkedHashMap<>();

    public void recordHeadToHead(String player, String opponent, double pointsScoredAgainstOpponent) {
        headToHeadPoints.computeIfAbsent(player, k -> new LinkedHashMap<>()).put(opponent, pointsScoredAgainstOpponent);
    }

    /** Points {@code player} scored against {@code opponent} this tournament, or null if they haven't played. */
    public Double headToHead(String player, String opponent) {
        Map<String, Double> row = headToHeadPoints.get(player);
        return row == null ? null : row.get(opponent);
    }

    public Tournament(String tournamentId, String name, TournamentFormat format, List<String> playerIds) {
        this.tournamentId = tournamentId;
        this.name = name;
        this.format = format;
        this.playerIds = List.copyOf(playerIds);
        this.status = TournamentStatus.UPCOMING;
        for (String p : playerIds) standingsByPlayer.put(p, new StandingsRow(p));
    }

    public String tournamentId() { return tournamentId; }
    public String name() { return name; }
    public TournamentFormat format() { return format; }
    public List<String> playerIds() { return playerIds; }
    public List<Round> rounds() { return rounds; }
    public Map<String, StandingsRow> standingsByPlayer() { return standingsByPlayer; }
    public List<StandingsRow> standingsSorted() {
        List<StandingsRow> rows = new ArrayList<>(standingsByPlayer.values());
        // Sort by the rank TournamentService.assignRanks() computed (points + tiebreaks) — this
        // method itself doesn't know about tiebreaks, so it defers to whatever rank was last
        // assigned rather than re-deriving a cruder points-only order. Rows with rank 0 (never
        // assigned yet, e.g. before any result is reported) sort last.
        rows.sort((a, b) -> Integer.compare(a.rank() == 0 ? Integer.MAX_VALUE : a.rank(),
                b.rank() == 0 ? Integer.MAX_VALUE : b.rank()));
        return rows;
    }
    public List<String> boards() { return boards; }
    public void setBoards(List<String> boards) { this.boards = boards; }
    public TournamentStatus status() { return status; }
    public void setStatus(TournamentStatus status) { this.status = status; }
    public Round currentRound() { return rounds.isEmpty() ? null : rounds.get(rounds.size() - 1); }
    public long timeControlInitialMs() { return timeControlInitialMs; }
    public long timeControlIncrementMs() { return timeControlIncrementMs; }
    public void setTimeControl(long initialMs, long incrementMs) {
        this.timeControlInitialMs = initialMs;
        this.timeControlIncrementMs = incrementMs;
    }
}
