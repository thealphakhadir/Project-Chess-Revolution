package org.openchess.vantage.analysis;

/** Mirrors Sagacious's evaluation output shape. Vantage treats these as opaque display values it forwards, not something it computes. */
public record EvalBar(int centipawns, Integer mateIn) {
    public boolean isMateScore() { return mateIn != null; }
}
