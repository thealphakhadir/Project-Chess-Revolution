package org.openchess.vantage.moderation;

import java.time.Instant;

public record ChatMessageEvent(String userId, String gameId, String message, Instant timestamp) {
}
