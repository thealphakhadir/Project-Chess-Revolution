package org.openchess.vantage.tournament;

import org.openchess.vantage.model.Tournament;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/** Reference implementation. Swap for a real DB-backed one (Postgres, etc.) without touching TournamentService. */
public final class InMemoryTournamentRepository implements TournamentRepository {

    private final Map<String, Tournament> store = new ConcurrentHashMap<>();

    @Override
    public void persist(Tournament tournament) { store.put(tournament.tournamentId(), tournament); }

    @Override
    public Tournament find(String tournamentId) { return store.get(tournamentId); }
}
