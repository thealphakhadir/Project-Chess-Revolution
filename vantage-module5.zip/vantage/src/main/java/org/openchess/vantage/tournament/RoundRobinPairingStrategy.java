package org.openchess.vantage.tournament;

import org.openchess.vantage.model.Pairing;
import org.openchess.vantage.model.Tournament;

import java.util.ArrayList;
import java.util.List;

/**
 * The standard "circle method" for round-robin scheduling: fix one player,
 * rotate the rest around them each round. With N players this produces
 * N-1 rounds (N rounds if N is odd, with one bye per round via a phantom
 * seat). Color assignment alternates by a simple, documented rule below —
 * this is a working reference, not a claim of matching any specific
 * federation's exact color-allocation tie-break rules.
 */
public final class RoundRobinPairingStrategy implements PairingStrategy {

    @Override
    public List<Pairing> generatePairings(Tournament tournament, int roundNumber) {
        List<String> players = new ArrayList<>(tournament.playerIds());
        boolean hasPhantomBye = players.size() % 2 != 0;
        if (hasPhantomBye) players.add(PairingStrategy.BYE);

        int n = players.size();
        int totalRounds = n - 1;
        int r = ((roundNumber - 1) % totalRounds); // 0-indexed rotation offset for this round

        // Apply the circle-method rotation r times: seat 0 fixed, the rest rotate.
        List<String> seats = new ArrayList<>(players);
        for (int step = 0; step < r; step++) {
            String last = seats.remove(n - 1);
            seats.add(1, last);
        }

        List<Pairing> pairings = new ArrayList<>();
        int boardNumber = 1;
        for (int i = 0; i < n / 2; i++) {
            String a = seats.get(i);
            String b = seats.get(n - 1 - i);
            if (a == PairingStrategy.BYE || b == PairingStrategy.BYE) {
                String bye = (a == PairingStrategy.BYE) ? b : a;
                // blackPlayer == null is the bye marker TournamentService checks for; gameId stays
                // null too since a bye never gets a game either way.
                pairings.add(new Pairing(bye, null, null, boardNumber++));
                continue;
            }
            // Alternate colors round to round for the fixed-seat pairing (i==0 involves seat 0);
            // for the rest, alternate by seat index parity — a simple, documented, not-federation-certified rule.
            boolean swap = (roundNumber % 2 == 0) == (i % 2 == 0);
            String white = swap ? b : a;
            String black = swap ? a : b;
            // gameId is null here on purpose — TournamentService creates the real game via
            // GameLifecyclePort and fills it in; a PairingStrategy schedules WHO plays, not
            // how a game gets created.
            pairings.add(new Pairing(white, black, null, boardNumber++));
        }
        return pairings;
    }

    /** Total rounds a full round-robin among these players requires. */
    public static int totalRoundsFor(int playerCount) {
        int n = playerCount % 2 == 0 ? playerCount : playerCount + 1;
        return n - 1;
    }
}
