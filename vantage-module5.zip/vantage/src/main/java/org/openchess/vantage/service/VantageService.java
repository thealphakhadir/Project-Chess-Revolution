package org.openchess.vantage.service;

import org.openchess.vantage.broadcast.BroadcastHub;
import org.openchess.vantage.model.ClockState;
import org.openchess.vantage.model.GameResult;
import org.openchess.vantage.model.SpectatorSession;
import org.openchess.vantage.moderation.ModerationVerdict;
import org.openchess.vantage.multiboard.MultiBoardOverviewService;
import org.openchess.vantage.personalization.PersonalizationService;
import org.openchess.vantage.tournament.TournamentService;

import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

/**
 * MODULE 5 — Vantage (spectator / broadcast layer).
 *
 * Top-level entry point. Everything else in this module is a supporting
 * service this class composes — the real-time play server (or whatever
 * owns live games) and the web/Android UI should talk to this class, not
 * to {@code BroadcastHub}/{@code TournamentService} directly, the same way
 * Module 4's UI talks to {@code OpeningExplorerService} rather than its
 * internals.
 */
public final class VantageService implements AutoCloseable {

    private final BroadcastHub hub;
    private final PersonalizationService personalization;
    private final TournamentService tournaments;
    private final MultiBoardOverviewService multiBoard;

    public VantageService(BroadcastHub hub, PersonalizationService personalization,
                           TournamentService tournaments, MultiBoardOverviewService multiBoard) {
        this.hub = hub;
        this.personalization = personalization;
        this.tournaments = tournaments;
        this.multiBoard = multiBoard;
    }

    // ----------------------------------------------------- live viewing

    public void connect(SpectatorSession session) { hub.registerSession(session); }

    public void disconnect(String sessionId) { hub.deregisterSession(sessionId); }

    public void watch(String sessionId, String gameId) { hub.subscribeToGame(sessionId, gameId); }

    public void stopWatching(String sessionId, String gameId) { hub.unsubscribeFromGame(sessionId, gameId); }

    /** Call when a move is played in ANY broadcast-eligible game (tournament or not) — a no-op if nobody's watching it. */
    public void onMovePlayed(String gameId, String sanMove, String resultingPositionFen, ClockState clock, Instant playedAt) {
        hub.onGameMovePlayed(gameId, sanMove, resultingPositionFen, clock, playedAt);
    }

    /** For a non-tournament game. For a tournament game, call {@link #reportTournamentResult} instead — it handles both. */
    public void onGameFinished(String gameId, GameResult result) { hub.onGameFinished(gameId, result); }

    // ------------------------------------------------------ per-viewer

    public CompletableFuture<?> requestPersonalizedOverlay(String sessionId, String gameId, int viewerElo) {
        return personalization.requestPersonalizedOverlay(sessionId, gameId, viewerElo);
    }

    public ModerationVerdict sendChatMessage(String sessionId, String gameId, String message) {
        return personalization.requestGameChat(sessionId, gameId, message);
    }

    // ------------------------------------------------------- multi-board

    public void watchTournamentOverview(String sessionId, String tournamentId) {
        multiBoard.subscribeToTournamentOverview(sessionId, tournamentId);
    }

    public void focusBoard(String sessionId, String gameId) {
        multiBoard.promoteToFullBoardView(sessionId, gameId);
    }

    // -------------------------------------------------------- tournament

    public org.openchess.vantage.model.Tournament createTournament(String name,
            org.openchess.vantage.model.TournamentFormat format, List<String> players) {
        return tournaments.createTournament(name, format, players);
    }

    public org.openchess.vantage.model.Round startRound(String tournamentId, int roundNumber) {
        return tournaments.startRound(tournamentId, roundNumber);
    }

    public void reportTournamentResult(String tournamentId, String gameId, GameResult result) {
        tournaments.onTournamentGameFinished(tournamentId, gameId, result);
    }

    public Map<String, Object> getTournamentPageData(String tournamentId) {
        return tournaments.getTournamentPageData(tournamentId);
    }

    @Override
    public void close() { hub.close(); }
}
