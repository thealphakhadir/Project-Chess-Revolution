package org.openchess.vantage.transport;

import org.openchess.vantage.events.BroadcastEvent;

/**
 * The transport seam: {@code connectionHandle} from the design doc. Wrap a
 * real WebSocket session (or SSE stream) in an implementation of this —
 * pick whatever library fits your web app (Java-WebSocket, Jetty, Spring's
 * WebSocket support...); this module deliberately doesn't bundle one, the
 * same way it doesn't bundle a JSON library, to stay dependency-free.
 * {@code fallback.InMemorySpectatorConnection} is for the standalone demo
 * and tests only.
 */
public interface SpectatorConnection {

    void send(BroadcastEvent event);

    String connectionId();

    boolean isOpen();
}
