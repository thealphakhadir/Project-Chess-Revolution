package org.openchess.vantage.broadcast;

import org.openchess.vantage.analysis.*;
import org.openchess.vantage.events.BroadcastEvent;
import org.openchess.vantage.events.Payloads;
import org.openchess.vantage.model.ClockState;
import org.openchess.vantage.model.GameResult;
import org.openchess.vantage.model.LiveGame;
import org.openchess.vantage.model.SpectatorSession;

import java.time.Instant;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Parts 2-3 of the design doc, translated directly: ONE broadcast channel
 * per game (never per spectator), delayed release for integrity, and
 * subscription management that catches new viewers up immediately.
 *
 * Thread-safety: this class is built to be called concurrently (moves
 * arriving, viewers subscribing/unsubscribing, all at once, potentially
 * from many games at once) — {@code activeBroadcasts} and each channel's
 * subscriber set are concurrent collections, and channel state fields are
 * volatile. It has not been load-tested; if you push this hard, profile it.
 */
public final class BroadcastHub implements AutoCloseable {

    private static final Logger LOG = Logger.getLogger(BroadcastHub.class.getName());

    private final Map<String, BroadcastChannel> activeBroadcasts = new ConcurrentHashMap<>();
    private final Map<String, SpectatorSession> sessionsById = new ConcurrentHashMap<>();

    private final GameStateSource gameStateSource;
    private final DelayPolicy delayPolicy;
    private final ConstructiveAnalysisPort analysisPort;
    private final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(2);
    private final long broadcastAnalysisTimeBudgetMs;

    public BroadcastHub(GameStateSource gameStateSource, DelayPolicy delayPolicy,
                         ConstructiveAnalysisPort analysisPort, long broadcastAnalysisTimeBudgetMs) {
        this.gameStateSource = gameStateSource;
        this.delayPolicy = delayPolicy;
        this.analysisPort = analysisPort;
        this.broadcastAnalysisTimeBudgetMs = broadcastAnalysisTimeBudgetMs;
    }

    // --------------------------------------------------------- sessions

    public void registerSession(SpectatorSession session) {
        sessionsById.put(session.sessionId(), session);
    }

    public void deregisterSession(String sessionId) {
        SpectatorSession session = sessionsById.remove(sessionId);
        if (session == null) return;
        for (String gameId : Set.copyOf(session.subscribedGameIds())) {
            unsubscribeFromGame(sessionId, gameId);
        }
    }

    public SpectatorSession getSession(String sessionId) { return sessionsById.get(sessionId); }

    // ---------------------------------------------------- subscriptions

    /** Part 3's subscribeToGame — creates the channel if this is the first subscriber to this game. */
    public void subscribeToGame(String sessionId, String gameId) {
        SpectatorSession session = requireSession(sessionId);
        BroadcastChannel channel = activeBroadcasts.computeIfAbsent(gameId, this::createBroadcastChannel);

        channel.subscribers().add(session);
        session.subscribedGameIds().add(gameId);

        // Catch the new subscriber up immediately — don't make them wait for the next move.
        session.connection().send(new BroadcastEvent(BroadcastEvent.EventType.GAME_SNAPSHOT, gameId,
                new Payloads.GameSnapshotPayload(channel.lastBroadcastState(),
                        lightenForBroadcast(channel.latestConstructiveAnalysis()))));
    }

    /** Part 6's overview subscribe — attaches ONLY to a channel that already exists; never creates one. */
    public boolean attachSessionToExistingChannel(String sessionId, String gameId) {
        SpectatorSession session = requireSession(sessionId);
        BroadcastChannel channel = activeBroadcasts.get(gameId);
        if (channel == null) return false;
        channel.subscribers().add(session);
        session.subscribedGameIds().add(gameId);
        return true;
    }

    public void unsubscribeFromGame(String sessionId, String gameId) {
        BroadcastChannel channel = activeBroadcasts.get(gameId);
        if (channel == null) return;
        SpectatorSession session = sessionsById.get(sessionId);
        if (session == null) return;

        channel.subscribers().remove(session);
        session.subscribedGameIds().remove(gameId);

        if (channel.subscribers().isEmpty() && !channel.isGameFinished()) {
            // Keep the channel alive but pause analysis compute if nobody's watching.
            pauseAnalysisForChannel(channel);
        }
    }

    /** Ensures a channel exists for this tournament board and sets it up in overview mode (Part 5's referenced-but-undefined subscribeChannelToTournamentPage). */
    public BroadcastChannel subscribeChannelToTournamentPage(String gameId, boolean hasConcurrentSiblingBoards) {
        BroadcastChannel channel = activeBroadcasts.computeIfAbsent(gameId, this::createBroadcastChannel);
        channel.setStreamingTier(BroadcastChannel.StreamingTier.OVERVIEW);
        channel.setTournamentBoardWithConcurrentSiblings(hasConcurrentSiblingBoards);
        // Computed directly from what the caller already knows (TournamentService knows exactly how
        // many boards are live this round) rather than round-tripping through the general DelayPolicy
        // seam, which exists for the organic single-game-subscribe path in createBroadcastChannel()
        // below, where the hub does NOT already know whether a game is tournament-related.
        channel.setDelayBufferSeconds(hasConcurrentSiblingBoards ? TournamentAwareDelayPolicy.DEFAULT_TOURNAMENT_DELAY_SECONDS : 0);
        return channel;
    }

    private BroadcastChannel createBroadcastChannel(String gameId) {
        LiveGame game = gameStateSource.fetchGameState(gameId);
        int delay = delayPolicy.delaySecondsFor(gameId);
        return new BroadcastChannel(gameId, game, delay, BroadcastChannel.StreamingTier.FULL_LIVE);
    }

    private void pauseAnalysisForChannel(BroadcastChannel channel) {
        channel.setAnalysisEnabled(false);
    }

    private SpectatorSession requireSession(String sessionId) {
        SpectatorSession session = sessionsById.get(sessionId);
        if (session == null) {
            throw new IllegalStateException("No registered spectator session for id " + sessionId
                    + " — call registerSession() when the viewer connects, before subscribing them to anything.");
        }
        return session;
    }

    // ------------------------------------------------------- move fan-out

    /**
     * Part 2's onGameMovePlayed. Vantage doesn't compute chess rules, so
     * the caller (whatever owns real game state) supplies the resulting
     * position/clock along with the move — see {@link GameStateSource}.
     */
    public void onGameMovePlayed(String gameId, String sanMove, String resultingPositionFen,
                                  ClockState resultingClock, Instant playedAt) {
        BroadcastChannel channel = activeBroadcasts.get(gameId);
        if (channel == null) return; // not being broadcast

        // Re-enable analysis if a subscriber returned while paused.
        if (!channel.subscribers().isEmpty()) channel.setAnalysisEnabled(true);

        if (channel.delayBufferSeconds() == 0) {
            broadcastMoveNow(channel, sanMove, resultingPositionFen, resultingClock);
        } else {
            BroadcastChannel.DelayedMove delayed =
                    new BroadcastChannel.DelayedMove(sanMove, resultingPositionFen, resultingClock, playedAt);
            channel.delayedMoveQueue().add(delayed);
            scheduleDelayedRelease(channel, delayed);
        }
    }

    private void scheduleDelayedRelease(BroadcastChannel channel, BroadcastChannel.DelayedMove delayed) {
        long releaseAtMs = delayed.playedAt().toEpochMilli() + (channel.delayBufferSeconds() * 1000L);
        long delayMs = Math.max(0, releaseAtMs - Instant.now().toEpochMilli());
        scheduler.schedule(() -> {
            try {
                broadcastMoveNow(channel, delayed.sanMove(), delayed.resultingPositionFen(), delayed.resultingClock());
                channel.delayedMoveQueue().removeIf(m -> m.sanMove().equals(delayed.sanMove())
                        && m.playedAt().equals(delayed.playedAt()));
            } catch (RuntimeException e) {
                LOG.log(Level.SEVERE, "Delayed broadcast release failed for game " + channel.gameId(), e);
            }
        }, delayMs, TimeUnit.MILLISECONDS);
    }

    private void broadcastMoveNow(BroadcastChannel channel, String sanMove, String resultingPositionFen, ClockState clock) {
        LiveGame updated = channel.lastBroadcastState().withMovePlayed(sanMove, resultingPositionFen, clock);
        channel.setLastBroadcastState(updated);

        if (channel.analysisEnabled()) {
            AnalysisTier tier = channel.streamingTier() == BroadcastChannel.StreamingTier.OVERVIEW
                    ? AnalysisTier.BACKGROUND : AnalysisTier.STANDARD;
            ConstructiveAnalysisRequest request = new ConstructiveAnalysisRequest(
                    resultingPositionFen, tier, null, broadcastAnalysisTimeBudgetMs, "broadcast-" + channel.gameId());

            boolean streamUpdatesWanted = channel.streamingTier() == BroadcastChannel.StreamingTier.FULL_LIVE;

            analysisPort.analyze(request, AnalysisCallbacks.of(
                    partial -> {
                        if (streamUpdatesWanted) {
                            pushToAllSubscribers(channel, BroadcastEvent.EventType.EVAL_UPDATE,
                                    new Payloads.EvalPayload(lightenForBroadcast(partial)));
                        }
                    },
                    finalReport -> {
                        channel.setLatestConstructiveAnalysis(finalReport);
                        pushToAllSubscribers(channel, BroadcastEvent.EventType.EVAL_FINAL,
                                new Payloads.EvalPayload(lightenForBroadcast(finalReport)));
                    }
            ));
        }

        pushToAllSubscribers(channel, BroadcastEvent.EventType.MOVE_PLAYED,
                new Payloads.MovePlayedPayload(sanMove, resultingPositionFen, clock));
    }

    public void onGameFinished(String gameId, GameResult result) {
        BroadcastChannel channel = activeBroadcasts.get(gameId);
        if (channel == null) return;
        channel.setGameFinished(true);
        LiveGame finished = channel.lastBroadcastState().withFinished(result);
        channel.setLastBroadcastState(finished);
        pushToAllSubscribers(channel, BroadcastEvent.EventType.GAME_FINISHED, new Payloads.GameFinishedPayload(finished));
    }

    /** Spectators get eval bar + king safety bar + best move — not the per-viewer-ELO fields (Part 2's lightenForBroadcast). */
    private ConstructiveAnalysisReport lightenForBroadcast(ConstructiveAnalysisReport report) {
        return report == null ? null : report.lightenedForBroadcast();
    }

    private void pushToAllSubscribers(BroadcastChannel channel, BroadcastEvent.EventType type, Object payload) {
        BroadcastEvent event = new BroadcastEvent(type, channel.gameId(), payload);
        for (SpectatorSession session : channel.subscribers()) {
            try {
                session.connection().send(event);
            } catch (RuntimeException e) {
                LOG.log(Level.WARNING, "Failed to push to spectator " + session.sessionId() + ", dropping silently", e);
            }
        }
    }

    // ------------------------------------------------------------ reads

    public BroadcastChannel channelFor(String gameId) { return activeBroadcasts.get(gameId); }

    /**
     * Generic push to every subscriber of a channel, for features layered on
     * top of the core move fan-out (e.g. chat — see personalization.PersonalizationService)
     * without those features needing their own subscriber-iteration logic.
     */
    public boolean pushCustomEvent(String gameId, BroadcastEvent.EventType type, Object payload) {
        BroadcastChannel channel = activeBroadcasts.get(gameId);
        if (channel == null) return false;
        pushToAllSubscribers(channel, type, payload);
        return true;
    }

    @Override
    public void close() { scheduler.shutdown(); }
}
