package org.openchess.vantage.analysis;

/**
 * Request shape matching the design doc's call into constructiveAnalysis():
 * {@code { type: "SINGLE_POSITION", position, tier, userElo, timeLimit, uiSlot } }.
 * {@code uiSlot} namespaces this request within Sagacious's shared worker
 * pool (Part 7 of the doc: broadcast analysis competes for the same
 * throttled concurrency budget as personal analysis, under its own
 * "broadcast-&lt;gameId&gt;" slot, rather than an unbounded separate pool).
 */
public record ConstructiveAnalysisRequest(String positionFen, AnalysisTier tier, Integer userElo,
                                           long timeLimitMs, String uiSlot) {

    public static ConstructiveAnalysisRequest forBroadcast(String positionFen, String gameId, long timeLimitMs) {
        return new ConstructiveAnalysisRequest(positionFen, AnalysisTier.STANDARD, null, timeLimitMs, "broadcast-" + gameId);
    }

    public static ConstructiveAnalysisRequest forPersonalizedOverlay(String positionFen, int viewerElo, String uiSlot) {
        return new ConstructiveAnalysisRequest(positionFen, AnalysisTier.DEEP, viewerElo, 5_000, uiSlot);
    }
}
