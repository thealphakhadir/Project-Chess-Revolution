package org.openchess.vantage.multiboard;

import org.openchess.vantage.broadcast.BroadcastChannel;
import org.openchess.vantage.broadcast.BroadcastHub;
import org.openchess.vantage.model.SpectatorSession;
import org.openchess.vantage.model.Tournament;
import org.openchess.vantage.tournament.TournamentRepository;

/**
 * Part 6 of the design doc: the "many games at once" UI need. Lightweight
 * subscription — a viewer scanning a grid of boards gets position + final
 * eval per board, not a full streaming analysis per board, until they
 * click into one (see {@link #promoteToFullBoardView}).
 */
public final class MultiBoardOverviewService {

    private final BroadcastHub hub;
    private final TournamentRepository tournamentRepository;

    public MultiBoardOverviewService(BroadcastHub hub, TournamentRepository tournamentRepository) {
        this.hub = hub;
        this.tournamentRepository = tournamentRepository;
    }

    public void subscribeToTournamentOverview(String sessionId, String tournamentId) {
        Tournament tournament = tournamentRepository.find(tournamentId);
        if (tournament == null) {
            throw new IllegalArgumentException("No tournament with id " + tournamentId);
        }
        for (String gameId : tournament.boards()) {
            boolean attached = hub.attachSessionToExistingChannel(sessionId, gameId);
            if (attached) {
                BroadcastChannel channel = hub.channelFor(gameId);
                channel.setAnalysisEnabled(true); // final-eval only is enough for a grid; per-depth streaming is unnecessary here
            }
        }
    }

    /** Viewer clicks into one board from the grid — upgrade just that channel, leave the rest in overview mode. */
    public void promoteToFullBoardView(String sessionId, String gameId) {
        BroadcastChannel channel = hub.channelFor(gameId);
        if (channel == null) {
            throw new IllegalArgumentException("Game " + gameId + " is not currently being broadcast");
        }
        SpectatorSession session = hub.getSession(sessionId);
        if (session == null || !session.subscribedGameIds().contains(gameId)) {
            hub.subscribeToGame(sessionId, gameId); // not yet subscribed via the overview — subscribe them directly
        }
        channel.setStreamingTier(BroadcastChannel.StreamingTier.FULL_LIVE);
    }
}
