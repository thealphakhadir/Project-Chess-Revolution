package org.openchess.vantage.personalization;

import org.openchess.vantage.analysis.*;
import org.openchess.vantage.broadcast.BroadcastChannel;
import org.openchess.vantage.broadcast.BroadcastHub;
import org.openchess.vantage.events.BroadcastEvent;
import org.openchess.vantage.events.Payloads;
import org.openchess.vantage.model.SpectatorSession;
import org.openchess.vantage.moderation.ChatMessageEvent;
import org.openchess.vantage.moderation.ModerationPipeline;
import org.openchess.vantage.moderation.ModerationVerdict;

import java.time.Instant;
import java.util.concurrent.CompletableFuture;

/**
 * Part 4 of the design doc: features an individual viewer opts into, kept
 * separate from the shared broadcast fan-out in {@link BroadcastHub} so a
 * popular game's shared analysis stream never turns into N personal ones.
 */
public final class PersonalizationService {

    public static final class RateLimitedException extends RuntimeException {
        public final long retryAfterMs;
        public RateLimitedException(long retryAfterMs) {
            super("Rate limited; retry after " + retryAfterMs + "ms");
            this.retryAfterMs = retryAfterMs;
        }
    }

    private final BroadcastHub hub;
    private final ConstructiveAnalysisPort analysisPort;
    private final ModerationPipeline moderationPipeline;
    private final RateLimiter overlayRateLimiter;

    public PersonalizationService(BroadcastHub hub, ConstructiveAnalysisPort analysisPort,
                                   ModerationPipeline moderationPipeline, RateLimiter overlayRateLimiter) {
        this.hub = hub;
        this.analysisPort = analysisPort;
        this.moderationPipeline = moderationPipeline;
        this.overlayRateLimiter = overlayRateLimiter;
    }

    /**
     * A single viewer's natural-move-vs-best-move overlay, at their own
     * ELO. This is a personalized request to Sagacious (DEEP tier, this
     * viewer's ELO), never part of the shared broadcast payload.
     */
    public CompletableFuture<ConstructiveAnalysisReport> requestPersonalizedOverlay(String sessionId, String gameId, int viewerElo) {
        if (overlayRateLimiter.exceedsLimit(sessionId)) {
            throw new RateLimitedException(overlayRateLimiter.windowMs());
        }
        BroadcastChannel channel = hub.channelFor(gameId);
        if (channel == null) {
            throw new IllegalArgumentException("Game " + gameId + " is not currently being broadcast");
        }
        String uiSlot = "personal-" + sessionId + "-" + gameId;
        ConstructiveAnalysisRequest request = ConstructiveAnalysisRequest.forPersonalizedOverlay(
                channel.lastBroadcastState().currentPositionFen(), viewerElo, uiSlot);

        CompletableFuture<ConstructiveAnalysisReport> future = new CompletableFuture<>();
        analysisPort.analyze(request, AnalysisCallbacks.of(
                partial -> { /* personal requests don't need a stream update path for this use case */ },
                future::complete));
        return future;
    }

    /** Spectator chat — same moderation pipeline as player chat (Part 4/7: "not a separate unmoderated surface"). */
    public ModerationVerdict requestGameChat(String sessionId, String gameId, String message) {
        SpectatorSession session = hub.getSession(sessionId);
        if (session == null) {
            throw new IllegalStateException("No registered spectator session for id " + sessionId);
        }
        ChatMessageEvent chatEvent = new ChatMessageEvent(session.userId(), gameId, message, Instant.now());
        ModerationVerdict verdict = moderationPipeline.screen(chatEvent);

        if (!verdict.isBlocked()) {
            hub.pushCustomEvent(gameId, BroadcastEvent.EventType.CHAT_MESSAGE,
                    new Payloads.ChatMessagePayload(chatEvent.userId(), chatEvent.message(),
                            chatEvent.timestamp().toEpochMilli()));
        }
        return verdict;
    }
}
