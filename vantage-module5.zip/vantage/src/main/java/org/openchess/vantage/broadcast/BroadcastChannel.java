package org.openchess.vantage.broadcast;

import org.openchess.vantage.analysis.ConstructiveAnalysisReport;
import org.openchess.vantage.model.ClockState;
import org.openchess.vantage.model.LiveGame;
import org.openchess.vantage.model.SpectatorSession;

import java.time.Instant;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * One server-side analysis/broadcast stream per game — the design doc's
 * core constraint (Part 0.1): however many thousands of spectators are
 * watching, this class exists exactly once per game, not once per viewer.
 */
public final class BroadcastChannel {

    /**
     * OVERVIEW: lightweight, final-eval-only — what a tournament multi-board
     * grid gets by default (Part 6). FULL_LIVE: full streaming analysis
     * updates — what a directly-subscribed single-game viewer gets. This is
     * a per-CHANNEL setting (shared across all its subscribers), matching
     * the design doc as given; if you need genuinely per-viewer streaming
     * detail on a shared channel later, that's a real extension, not
     * something this class does today.
     */
    public enum StreamingTier { OVERVIEW, FULL_LIVE }

    public record DelayedMove(String sanMove, String resultingPositionFen, ClockState resultingClock, Instant playedAt) {}

    private final String gameId;
    private final Set<SpectatorSession> subscribers = ConcurrentHashMap.newKeySet();
    private volatile int delayBufferSeconds;
    private final ConcurrentLinkedQueue<DelayedMove> delayedMoveQueue = new ConcurrentLinkedQueue<>();
    private volatile LiveGame lastBroadcastState;
    private volatile ConstructiveAnalysisReport latestConstructiveAnalysis;
    private volatile boolean analysisEnabled;
    private volatile StreamingTier streamingTier;
    private volatile boolean gameFinished;
    private volatile boolean tournamentBoardWithConcurrentSiblings; // feeds DelayPolicy — see broadcast.DelayPolicy

    public BroadcastChannel(String gameId, LiveGame initialState, int delayBufferSeconds, StreamingTier initialTier) {
        this.gameId = gameId;
        this.lastBroadcastState = initialState;
        this.delayBufferSeconds = delayBufferSeconds;
        this.streamingTier = initialTier;
        this.analysisEnabled = true;
    }

    public String gameId() { return gameId; }
    public Set<SpectatorSession> subscribers() { return subscribers; }
    public int delayBufferSeconds() { return delayBufferSeconds; }
    public void setDelayBufferSeconds(int seconds) { this.delayBufferSeconds = seconds; }
    public ConcurrentLinkedQueue<DelayedMove> delayedMoveQueue() { return delayedMoveQueue; }
    public LiveGame lastBroadcastState() { return lastBroadcastState; }
    public void setLastBroadcastState(LiveGame state) { this.lastBroadcastState = state; }
    public ConstructiveAnalysisReport latestConstructiveAnalysis() { return latestConstructiveAnalysis; }
    public void setLatestConstructiveAnalysis(ConstructiveAnalysisReport report) { this.latestConstructiveAnalysis = report; }
    public boolean analysisEnabled() { return analysisEnabled; }
    public void setAnalysisEnabled(boolean enabled) { this.analysisEnabled = enabled; }
    public StreamingTier streamingTier() { return streamingTier; }
    public void setStreamingTier(StreamingTier tier) { this.streamingTier = tier; }
    public boolean isGameFinished() { return gameFinished; }
    public void setGameFinished(boolean finished) { this.gameFinished = finished; }
    public boolean isTournamentBoardWithConcurrentSiblings() { return tournamentBoardWithConcurrentSiblings; }
    public void setTournamentBoardWithConcurrentSiblings(boolean value) { this.tournamentBoardWithConcurrentSiblings = value; }
}
