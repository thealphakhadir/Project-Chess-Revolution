package org.openchess.vantage.model;

public record Pairing(String whitePlayer, String blackPlayer, String gameId, int boardNumber) {
}
