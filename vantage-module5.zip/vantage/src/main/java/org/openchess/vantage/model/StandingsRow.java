package org.openchess.vantage.model;

import java.util.LinkedHashMap;
import java.util.Map;

/** Mutable by design — points and tiebreak scores accumulate round over round, then the table is re-sorted. */
public final class StandingsRow {

    private final String playerId;
    private double points;
    private final Map<String, Double> tiebreakScores = new LinkedHashMap<>();
    private int rank; // 1-based; assigned by TournamentService after sorting, 0 until then
    private int gamesPlayed;

    public StandingsRow(String playerId) {
        this.playerId = playerId;
    }

    public String playerId() { return playerId; }
    public double points() { return points; }
    public void addPoints(double delta) { this.points += delta; }
    public int gamesPlayed() { return gamesPlayed; }
    public void incrementGamesPlayed() { gamesPlayed++; }
    public Map<String, Double> tiebreakScores() { return tiebreakScores; }
    public void setTiebreak(String name, double value) { tiebreakScores.put(name, value); }
    public int rank() { return rank; }
    public void setRank(int rank) { this.rank = rank; }

    @Override
    public String toString() {
        return String.format("#%d %s — %.1f pts (%s)", rank, playerId, points, tiebreakScores);
    }
}
