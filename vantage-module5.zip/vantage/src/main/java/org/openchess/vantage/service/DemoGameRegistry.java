package org.openchess.vantage.service;

import org.openchess.vantage.broadcast.GameStateSource;
import org.openchess.vantage.model.ClockState;
import org.openchess.vantage.model.GameResult;
import org.openchess.vantage.model.GameStatus;
import org.openchess.vantage.model.LiveGame;
import org.openchess.vantage.tournament.GameLifecyclePort;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Standalone-demo-only stand-in for "whatever module actually runs live
 * games" (the real-time play server). Vantage's real deployment wires
 * {@link GameStateSource} and {@link GameLifecyclePort} to that module
 * instead of this in-memory registry.
 */
public final class DemoGameRegistry implements GameStateSource, GameLifecyclePort {

    private static final String STARTING_FEN = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1";

    private final Map<String, LiveGame> games = new ConcurrentHashMap<>();
    private final AtomicInteger idCounter = new AtomicInteger(1);

    public String registerGame(String gameId, String white, String black) {
        games.put(gameId, new LiveGame(gameId, white, black, STARTING_FEN, List.of(),
                new ClockState(600_000, 600_000, 5_000), GameStatus.ONGOING, GameResult.ONGOING, 0));
        return gameId;
    }

    @Override
    public LiveGame fetchGameState(String gameId) {
        LiveGame g = games.get(gameId);
        if (g == null) throw new IllegalArgumentException("Unknown demo game: " + gameId);
        return g;
    }

    @Override
    public String createGame(String whitePlayer, String blackPlayer, long initialMs, long incrementMs) {
        String gameId = "tourney-game-" + idCounter.getAndIncrement();
        games.put(gameId, new LiveGame(gameId, whitePlayer, blackPlayer, STARTING_FEN, List.of(),
                new ClockState(initialMs, initialMs, incrementMs), GameStatus.ONGOING, GameResult.ONGOING, 0));
        return gameId;
    }
}
