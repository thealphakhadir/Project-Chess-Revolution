package org.openchess.vantage.model;

/**
 * SWISS, KNOCKOUT, and ARENA are modeled throughout this module but their
 * pairing/tiebreak algorithms are NOT implemented here — see
 * {@code tournament.PairingStrategy} and the project note on why (Swiss
 * pairing in particular has real FIDE-rulebook edge cases that deserve
 * their own design pass). ROUND_ROBIN is fully implemented end-to-end as
 * the reference/default so the module has a real, working tournament path
 * out of the box.
 */
public enum TournamentFormat { SWISS, ROUND_ROBIN, KNOCKOUT, ARENA }
