package org.openchess.vantage.model;

public enum BroadcastVisibility { PUBLIC, UNLISTED, DELAYED }
