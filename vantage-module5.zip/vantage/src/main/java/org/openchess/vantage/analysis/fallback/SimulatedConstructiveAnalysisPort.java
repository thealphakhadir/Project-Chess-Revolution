package org.openchess.vantage.analysis.fallback;

import org.openchess.vantage.analysis.*;

import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

/**
 * Demo/standalone-only stand-in for Sagacious. Produces a plausible-looking
 * but NOT REAL evaluation (deterministic from the FEN's hash, so repeated
 * calls on the same position are at least stable within one run) purely so
 * {@code Main}'s demo has something to show. Replace with a real
 * {@link ConstructiveAnalysisPort} wrapping Sagacious before this touches
 * anything a spectator actually sees.
 */
public final class SimulatedConstructiveAnalysisPort implements ConstructiveAnalysisPort {

    private final Executor executor = Executors.newCachedThreadPool();

    @Override
    public void analyze(ConstructiveAnalysisRequest request, AnalysisCallbacks callbacks) {
        executor.execute(() -> {
            ConstructiveAnalysisReport partial = fabricate(request, request.tier() == AnalysisTier.DEEP ? 12 : 8);
            callbacks.onStreamUpdate(partial);
            try {
                Thread.sleep(Math.min(300, request.timeLimitMs()));
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            ConstructiveAnalysisReport finalReport = fabricate(request, request.tier() == AnalysisTier.DEEP ? 20 : 14);
            callbacks.onComplete(finalReport);
        });
    }

    private ConstructiveAnalysisReport fabricate(ConstructiveAnalysisRequest request, int depth) {
        int hash = request.positionFen().hashCode();
        int cp = (hash % 300); // a deterministic-but-arbitrary "eval", NOT a real evaluation
        double whiteSafety = 0.5 + ((hash / 7) % 100) / 200.0;
        double blackSafety = 0.5 + ((hash / 13) % 100) / 200.0;
        String simulatedBestMove = "Nf3"; // placeholder — real port returns the engine's actual choice
        String overlay = request.tier() == AnalysisTier.DEEP
                ? "(simulated) roughly matches what a " + request.userElo() + "-rated player would consider here"
                : null;
        return new ConstructiveAnalysisReport(new EvalBar(cp, null), new KingSafetyBars(whiteSafety, blackSafety),
                simulatedBestMove, depth, overlay, null);
    }
}
