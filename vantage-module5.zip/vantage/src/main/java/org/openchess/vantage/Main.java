package org.openchess.vantage;

import org.openchess.vantage.analysis.ConstructiveAnalysisPort;
import org.openchess.vantage.analysis.fallback.SimulatedConstructiveAnalysisPort;
import org.openchess.vantage.broadcast.BroadcastHub;
import org.openchess.vantage.broadcast.DelayPolicy;
import org.openchess.vantage.events.BroadcastEvent;
import org.openchess.vantage.model.*;
import org.openchess.vantage.moderation.ModerationPipeline;
import org.openchess.vantage.moderation.fallback.PassthroughModerationPipeline;
import org.openchess.vantage.multiboard.MultiBoardOverviewService;
import org.openchess.vantage.personalization.PersonalizationService;
import org.openchess.vantage.personalization.RateLimiter;
import org.openchess.vantage.service.DemoGameRegistry;
import org.openchess.vantage.service.VantageService;
import org.openchess.vantage.tournament.*;
import org.openchess.vantage.transport.fallback.InMemorySpectatorConnection;

import java.time.Instant;
import java.util.List;
import java.util.Map;

/**
 * Runnable demo / smoke test for Module 5. Two scenarios: a single live
 * game fanned out to three spectators (showing ONE analysis stream serving
 * all of them, plus a delayed-broadcast tournament board), and a 4-player
 * round-robin tournament run to completion with standings printed each
 * round. Not a UI — same role as Module 4's {@code Main}: prove the wiring
 * works end to end from a terminal.
 *
 * Build & run:
 *   mvn package
 *   java -jar target/vantage.jar
 */
public final class Main {

    public static void main(String[] args) {
        DemoGameRegistry registry = new DemoGameRegistry();
        ConstructiveAnalysisPort analysisPort = new SimulatedConstructiveAnalysisPort();
        // Organic (non-tournament) direct-subscribe path: no delay in this demo. Tournament boards
        // get their delay computed directly in BroadcastHub.subscribeChannelToTournamentPage instead.
        DelayPolicy organicDelayPolicy = gameId -> 0;
        BroadcastHub hub = new BroadcastHub(registry, organicDelayPolicy, analysisPort, 800);

        ModerationPipeline moderation = new PassthroughModerationPipeline();
        RateLimiter overlayRateLimiter = new RateLimiter(5, 60_000);
        PersonalizationService personalization = new PersonalizationService(hub, analysisPort, moderation, overlayRateLimiter);

        TournamentRepository tournamentRepo = new InMemoryTournamentRepository();
        Map<TournamentFormat, PairingStrategy> pairingStrategies = Map.of(
                TournamentFormat.ROUND_ROBIN, new RoundRobinPairingStrategy());
        Map<TournamentFormat, TiebreakStrategy> tiebreakStrategies = Map.of(
                TournamentFormat.ROUND_ROBIN, new SonnebornBergerTiebreak());
        TournamentService tournamentService = new TournamentService(
                tournamentRepo, hub, registry, pairingStrategies, tiebreakStrategies);

        MultiBoardOverviewService multiBoard = new MultiBoardOverviewService(hub, tournamentRepo);

        try (VantageService vantage = new VantageService(hub, personalization, tournamentService, multiBoard)) {
            runLiveBroadcastDemo(vantage, hub, registry);
            System.out.println();
            runTournamentDemo(vantage);
        }
    }

    // ------------------------------------------------- Scenario 1: live broadcast fan-out

    private static void runLiveBroadcastDemo(VantageService vantage, BroadcastHub hub, DemoGameRegistry registry) {
        System.out.println("=== Scenario 1: one game, three spectators, one shared analysis stream ===");
        String gameId = registry.registerGame("live-demo-1", "Alice", "Bob");

        InMemorySpectatorConnection alexConn = new InMemorySpectatorConnection("conn-alex",
                e -> System.out.println("  [alex sees]  " + describe(e)));
        InMemorySpectatorConnection priyaConn = new InMemorySpectatorConnection("conn-priya",
                e -> System.out.println("  [priya sees] " + describe(e)));
        InMemorySpectatorConnection samConn = new InMemorySpectatorConnection("conn-sam",
                e -> System.out.println("  [sam sees]   " + describe(e)));

        vantage.connect(new SpectatorSession("sess-alex", "u-alex", alexConn));
        vantage.connect(new SpectatorSession("sess-priya", "u-priya", priyaConn));
        vantage.connect(new SpectatorSession("sess-sam", null, samConn)); // anonymous viewer allowed

        System.out.println("-- alex and priya subscribe; sam joins a move later --");
        vantage.watch("sess-alex", gameId);
        vantage.watch("sess-priya", gameId);

        vantage.onMovePlayed(gameId, "e4", "rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR b KQkq e3 0 1",
                new ClockState(598_000, 600_000, 5_000), Instant.now());

        System.out.println("-- sam joins now and gets an immediate snapshot, not a wait for the next move --");
        vantage.watch("sess-sam", gameId);

        vantage.onMovePlayed(gameId, "e5", "rnbqkbnr/pppp1ppp/8/4p3/4P3/8/PPPP1PPP/RNBQKBNR w KQkq e6 0 2",
                new ClockState(598_000, 597_000, 5_000), Instant.now());

        System.out.println("-- priya sends a chat message (routed through the moderation seam) --");
        var verdict = vantage.sendChatMessage("sess-priya", gameId, "nice opening!");
        System.out.println("  moderation verdict: " + verdict.outcome());

        System.out.println("-- alex leaves; hub pauses analysis for this channel since it's now down to 2 viewers, "
                + "not zero — pause only triggers when the LAST viewer leaves --");
        vantage.stopWatching("sess-alex", gameId);
        System.out.println("  channel.analysisEnabled = " + hub.channelFor(gameId).analysisEnabled());

        vantage.disconnect("sess-alex");
        vantage.disconnect("sess-priya");
        vantage.disconnect("sess-sam");
    }

    // ------------------------------------------------- Scenario 2: tournament

    private static void runTournamentDemo(VantageService vantage) {
        System.out.println("=== Scenario 2: 4-player round-robin tournament ===");
        List<String> players = List.of("Alice", "Bob", "Carol", "Dave");
        Tournament tournament = vantage.createTournament("Demo Quad", TournamentFormat.ROUND_ROBIN, players);
        System.out.println("Created tournament " + tournament.tournamentId() + " (" + RoundRobinPairingStrategy
                .totalRoundsFor(players.size()) + " rounds needed for " + players.size() + " players)");

        int totalRounds = RoundRobinPairingStrategy.totalRoundsFor(players.size());
        GameResult[] scriptedResults = { GameResult.WHITE_WIN, GameResult.DRAW }; // cycled through, just for demo variety

        for (int roundNum = 1; roundNum <= totalRounds; roundNum++) {
            Round round = vantage.startRound(tournament.tournamentId(), roundNum);
            System.out.println("-- Round " + roundNum + " --");
            int i = 0;
            for (Pairing pairing : round.pairings()) {
                if (pairing.gameId() == null) {
                    System.out.println("  " + pairing.whitePlayer() + " has the bye");
                    continue;
                }
                GameResult result = scriptedResults[i % scriptedResults.length];
                System.out.println("  Board " + pairing.boardNumber() + ": " + pairing.whitePlayer() + " vs "
                        + pairing.blackPlayer() + " (" + pairing.gameId() + ") -> " + result.pgnToken());
                vantage.reportTournamentResult(tournament.tournamentId(), pairing.gameId(), result);
                i++;
            }
        }

        System.out.println("-- Final standings --");
        for (StandingsRow row : tournament.standingsSorted()) {
            System.out.println("  " + row);
        }
    }

    private static String describe(BroadcastEvent e) {
        return e.type() + " (game " + e.gameId() + "): " + e.payload();
    }
}
