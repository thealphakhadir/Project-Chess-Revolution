package org.openchess.vantage.model;

/** Deliberately independent of Module 4's result type — Vantage is self-contained and pluggable, not coupled to the explorer module. */
public enum GameResult {
    WHITE_WIN, BLACK_WIN, DRAW, ONGOING;

    public String pgnToken() {
        return switch (this) {
            case WHITE_WIN -> "1-0";
            case BLACK_WIN -> "0-1";
            case DRAW -> "1/2-1/2";
            case ONGOING -> "*";
        };
    }
}
