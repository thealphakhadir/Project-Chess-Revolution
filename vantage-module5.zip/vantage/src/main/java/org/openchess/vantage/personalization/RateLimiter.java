package org.openchess.vantage.personalization;

import java.util.Deque;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedDeque;

/**
 * Part 4's rate limit on personalized-overlay requests: "stop a popular
 * broadcast from silently becoming N full analyses." Simple sliding window
 * per key (session ID) — swap for a distributed limiter (Redis, etc.) if
 * you run multiple Vantage instances behind a load balancer.
 */
public final class RateLimiter {

    private final int maxRequestsPerWindow;
    private final long windowMs;
    private final Map<String, Deque<Long>> requestTimestamps = new ConcurrentHashMap<>();

    public RateLimiter(int maxRequestsPerWindow, long windowMs) {
        this.maxRequestsPerWindow = maxRequestsPerWindow;
        this.windowMs = windowMs;
    }

    /** Returns true if the caller has exceeded their limit (and should be rejected); otherwise records this attempt and returns false. */
    public boolean exceedsLimit(String key) {
        long now = System.currentTimeMillis();
        Deque<Long> timestamps = requestTimestamps.computeIfAbsent(key, k -> new ConcurrentLinkedDeque<>());
        synchronized (timestamps) {
            while (!timestamps.isEmpty() && now - timestamps.peekFirst() > windowMs) {
                timestamps.pollFirst();
            }
            if (timestamps.size() >= maxRequestsPerWindow) {
                return true;
            }
            timestamps.addLast(now);
            return false;
        }
    }

    public long windowMs() { return windowMs; }
}
