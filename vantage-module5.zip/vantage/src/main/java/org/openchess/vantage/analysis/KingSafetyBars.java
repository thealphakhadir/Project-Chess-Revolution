package org.openchess.vantage.analysis;

/** Scale is whatever Constructive Analysis defines (e.g. 0.0-1.0, higher = safer) — Vantage forwards it verbatim. */
public record KingSafetyBars(double whiteSafety, double blackSafety) {
}
