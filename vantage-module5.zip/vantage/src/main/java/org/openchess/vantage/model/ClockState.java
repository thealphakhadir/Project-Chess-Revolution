package org.openchess.vantage.model;

public record ClockState(long whiteRemainingMs, long blackRemainingMs, long incrementMs) {

    public ClockState withMoveApplied(boolean whiteJustMoved, long msSpent) {
        long w = whiteJustMoved ? Math.max(0, whiteRemainingMs - msSpent + incrementMs) : whiteRemainingMs;
        long b = whiteJustMoved ? blackRemainingMs : Math.max(0, blackRemainingMs - msSpent + incrementMs);
        return new ClockState(w, b, incrementMs);
    }
}
