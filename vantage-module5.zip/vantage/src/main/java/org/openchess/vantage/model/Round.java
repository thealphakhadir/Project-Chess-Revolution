package org.openchess.vantage.model;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

/** Mutable: pairings/status fill in as the round is generated and played out. */
public final class Round {

    private final int roundNumber;
    private final List<Pairing> pairings = new ArrayList<>();
    private final java.util.Set<String> gameIdsWithResults = java.util.concurrent.ConcurrentHashMap.newKeySet();
    private Instant startTime;
    private RoundStatus status;

    public Round(int roundNumber) {
        this.roundNumber = roundNumber;
        this.status = RoundStatus.SCHEDULED;
    }

    public int roundNumber() { return roundNumber; }
    public List<Pairing> pairings() { return pairings; }
    public void addPairing(Pairing p) { pairings.add(p); }
    public java.util.Set<String> gameIdsWithResults() { return gameIdsWithResults; }
    public Instant startTime() { return startTime; }
    public void setStartTime(Instant t) { this.startTime = t; }
    public RoundStatus status() { return status; }
    public void setStatus(RoundStatus status) { this.status = status; }
}
