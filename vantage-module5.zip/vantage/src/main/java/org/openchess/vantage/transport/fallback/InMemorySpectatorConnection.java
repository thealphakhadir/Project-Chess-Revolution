package org.openchess.vantage.transport.fallback;

import org.openchess.vantage.events.BroadcastEvent;
import org.openchess.vantage.transport.SpectatorConnection;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Consumer;

/** Captures every event it receives (for demo printing / test assertions) instead of writing to a real socket. */
public final class InMemorySpectatorConnection implements SpectatorConnection {

    private final String connectionId;
    private final List<BroadcastEvent> received = new CopyOnWriteArrayList<>();
    private final Consumer<BroadcastEvent> onReceive; // e.g. System.out::println for the demo
    private volatile boolean open = true;

    public InMemorySpectatorConnection(String connectionId, Consumer<BroadcastEvent> onReceive) {
        this.connectionId = connectionId;
        this.onReceive = onReceive;
    }

    @Override
    public void send(BroadcastEvent event) {
        if (!open) return;
        received.add(event);
        if (onReceive != null) onReceive.accept(event);
    }

    @Override
    public String connectionId() { return connectionId; }

    @Override
    public boolean isOpen() { return open; }

    public void close() { open = false; }

    public List<BroadcastEvent> received() { return received; }
}
