# Module 5 — Vantage (Spectator / Broadcast)

Built directly from `spectator_broadcast_mode.md`'s pseudocode. Every
`FUNCTION` in that doc has a corresponding method here; every `STRUCT` has
a corresponding class. Where the doc referenced a function without
defining it (`subscribeChannelToTournamentPage`, `createGame`,
`checkAndAdvanceRoundIfAllBoardsComplete`), I implemented a reasonable
version and flagged it in that method's Javadoc — search this codebase for
"design doc" in comments to find every place I made a judgment call versus
places that are a direct, unambiguous translation.

Self-contained on purpose: zero external Maven dependencies, and it does
**not** depend on Module 4's jar (a couple of small overlapping concepts —
`GameResult`, board-state-as-FEN — are duplicated locally rather than
creating a cross-module dependency, matching the "pluggable module" spirit
of the whole project).

## Where this sits — the three seams

Vantage does one job: fan out one game's state/analysis to many viewers,
plus schedule and broadcast tournaments. It deliberately does **not**:

| It doesn't... | Because that's... | The seam |
|---|---|---|
| Run chess rules or own game truth | the live-play server's job | `broadcast.GameStateSource`, `tournament.GameLifecyclePort` |
| Compute evaluation | Sagacious's job | `analysis.ConstructiveAnalysisPort` |
| Moderate chat | Vanguard's job | `moderation.ModerationPipeline` |

Each has a `fallback` package with a standalone-demo-only implementation
(`SimulatedConstructiveAnalysisPort` fabricates a plausible-looking but
fake eval; `PassthroughModerationPipeline` is a five-word blocklist, not a
moderation system; `DemoGameRegistry` is an in-memory game store). Wire the
real modules in at your composition root — see `Main.java` for exactly
where each seam gets plugged.

## What's fully implemented vs. deliberately scoped out

**Fully implemented, real logic, not stubs:**
- The whole fan-out pipeline (Part 2): one `BroadcastChannel` per game, move
  arrives once, one analysis call, pushed to every subscriber
- Broadcast delay for integrity (Part 3), via a real `ScheduledExecutorService`
- Subscription management incl. immediate catch-up snapshot on subscribe,
  and pausing analysis when the last viewer leaves
- Personalized per-viewer overlay + rate limiting, spectator chat routed
  through the moderation seam (Part 4)
- Full round-robin tournament: circle-method pairing (byes included),
  standings, Sonneborn-Berger tiebreaks, page-data assembly (Part 5)
- Multi-board overview mode + promote-to-full-view (Part 6)

**Deliberately not implemented — matching the design doc's own "Honest
note":** Swiss/Knockout/Arena pairing and Buchholz-family tiebreaks.
`tournament.PairingStrategy` and `TiebreakStrategy` are the extension
points; `TournamentService` throws a clear `UnsupportedOperationException`
if you ask for a format with no registered strategy, rather than
pretending to support it. Swiss pairing in particular (color balancing,
no-repeat-pairing, bye handling under FIDE's actual rules) is a genuine
multi-day problem on its own — give it its own design pass when you're
ready, the same call the original doc made.

## Build & run

```bash
mvn package
java -jar target/vantage.jar
```

Or plain `javac`/`java`, no Maven needed (zero dependencies):

```bash
find src/main/java -name "*.java" > sources.txt
javac -d out @sources.txt
java -cp out org.openchess.vantage.Main
```

`Main` runs two scenarios end to end: a single game fanned out to three
spectators (showing one shared analysis stream, immediate-snapshot
catch-up, moderated chat, and analysis pausing when a viewer leaves), then
a 4-player round-robin tournament run to completion with standings printed
after every round.

## Plugging into the real modules

1. **Sagacious** — implement `analysis.ConstructiveAnalysisPort` wrapping
   your real `constructiveAnalysis()`. The request/report shapes here
   mirror the design doc's own field names exactly, so this should be a
   thin pass-through, not a translation layer.
2. **Vanguard** — implement `moderation.ModerationPipeline` wrapping your
   real chat intake. One method: `screen(ChatMessageEvent) -> ModerationVerdict`.
3. **Live-play server** — implement `broadcast.GameStateSource` (fetch a
   game's current state) and `tournament.GameLifecyclePort` (create a game
   for a pairing). Call `VantageService.onMovePlayed(...)` every time a
   broadcast-eligible game gets a move, and `onGameFinished`/
   `reportTournamentResult` when one ends.
4. **Transport** — implement `transport.SpectatorConnection` around
   whatever WebSocket/SSE library your web app uses (none is bundled here,
   same reasoning as Module 4 not bundling a JSON library: stay
   dependency-free, let the app layer pick).

`service.VantageService` is the only class the rest of the app should
talk to — same pattern as Module 4's `OpeningExplorerService`.

## A design choice worth knowing about

`BroadcastChannel.streamingTier` (OVERVIEW vs. FULL_LIVE) is a
**per-channel**, not per-viewer, setting — matching the design doc as
given. In practice that means: if Viewer A is scanning a tournament grid
and Viewer B clicks into board 3 for a deep look, board 3's channel
upgrades to full streaming detail for *everyone* watching it, including
Viewer A if they're also subscribed to it via the grid. That's a real
simplification, not a bug — genuinely per-viewer streaming detail on a
shared channel is a bigger change (the fan-out would need to branch by
viewer inside `broadcastMoveNow`) and wasn't in the doc's scope. Flagging
it here so it's a known trade-off, not a surprise.

## No compiler in this sandbox

Same situation as Module 4: no JDK and no network to install one here. I
ran a full structural pass instead — every one of the 48 files' braces/
parens/brackets balance, and every internal `import org.openchess.vantage...`
statement resolves to a file that actually exists (checked by script, not
by eye). I also traced every constructor call site in `Main.java` against
its declared constructor by hand. That's real verification, but it's not
`javac`. Run `mvn package` first and treat any error it finds as the
priority fix.
