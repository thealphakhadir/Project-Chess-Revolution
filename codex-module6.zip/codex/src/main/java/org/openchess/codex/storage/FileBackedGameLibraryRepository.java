package org.openchess.codex.storage;

import org.openchess.codex.model.GameRecord;
import org.openchess.codex.util.Json;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Instant;
import java.util.*;

/**
 * Persists the whole library to one local JSON file — no database needed
 * for a personal collection. Rewrites the whole file on every save, same
 * trade-off Module 4's RepertoireService makes: simple and correct beats
 * clever for a library sized for one person's games. Swap for a real
 * DB-backed {@link GameLibraryRepository} if this ever needs to scale past
 * "one person's PGN collection."
 */
public final class FileBackedGameLibraryRepository implements GameLibraryRepository {

    private final Path storageFile;
    private final Map<String, GameRecord> store = new LinkedHashMap<>();

    public FileBackedGameLibraryRepository(Path storageFile) {
        this.storageFile = storageFile;
        load();
    }

    @Override
    public synchronized void save(GameRecord game) {
        store.put(game.id(), game);
        persist();
    }

    @Override
    public synchronized Optional<GameRecord> findById(String id) { return Optional.ofNullable(store.get(id)); }

    @Override
    public synchronized List<GameRecord> findAll() { return new ArrayList<>(store.values()); }

    @Override
    public synchronized void delete(String id) {
        store.remove(id);
        persist();
    }

    @SuppressWarnings("unchecked")
    private synchronized void load() {
        store.clear();
        if (!Files.exists(storageFile)) return;
        try {
            String content = Files.readString(storageFile, StandardCharsets.UTF_8);
            if (content.isBlank()) return;
            List<Object> array = (List<Object>) Json.parse(content);
            for (Object o : array) {
                Map<String, Object> m = (Map<String, Object>) o;
                String id = Json.str(m, "id");
                Map<String, String> headers = new LinkedHashMap<>();
                Map<String, Object> rawHeaders = Json.mapVal(m, "headers");
                if (rawHeaders != null) for (var e : rawHeaders.entrySet()) headers.put(e.getKey(), String.valueOf(e.getValue()));
                List<String> mainline = new ArrayList<>();
                for (Object mv : Json.listVal(m, "mainlineSan")) mainline.add(String.valueOf(mv));
                String rawPgn = Json.str(m, "rawPgn");
                Instant importedAt = Instant.parse(Json.str(m, "importedAt"));

                GameRecord game = new GameRecord(id, headers, mainline, rawPgn, importedAt);
                for (Object lbl : Json.listVal(m, "labels")) game.addLabel(String.valueOf(lbl));
                Object validated = m.get("validated");
                if (Boolean.TRUE.equals(validated)) {
                    game.markValidated(Json.str(m, "validationError"));
                }
                store.put(id, game);
            }
        } catch (IOException e) {
            throw new RuntimeException("Failed to load game library from " + storageFile, e);
        }
    }

    private synchronized void persist() {
        List<Map<String, Object>> array = new ArrayList<>();
        for (GameRecord g : store.values()) {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("id", g.id());
            m.put("headers", g.headers());
            m.put("mainlineSan", g.mainlineSan());
            m.put("rawPgn", g.rawPgn());
            m.put("labels", g.labels());
            m.put("importedAt", g.importedAt().toString());
            m.put("validated", g.isValidated());
            m.put("validationError", g.validationError());
            array.add(m);
        }
        try {
            if (storageFile.getParent() != null) Files.createDirectories(storageFile.getParent());
            Files.writeString(storageFile, Json.writeObject(array), StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw new RuntimeException("Failed to save game library to " + storageFile, e);
        }
    }
}
