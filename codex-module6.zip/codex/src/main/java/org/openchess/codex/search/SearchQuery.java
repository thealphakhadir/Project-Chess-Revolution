package org.openchess.codex.search;

public final class SearchQuery {

    public static final SearchQuery ANY = new Builder().build();

    private final String playerContains;   // matches White OR Black, case-insensitive substring
    private final String resultEquals;     // "1-0" / "0-1" / "1/2-1/2" / "*"
    private final String dateFrom;         // PGN date format "YYYY.MM.DD" — lexicographic compare works directly
    private final String dateTo;
    private final String ecoPrefix;        // e.g. "B9" matches B90-B99
    private final String openingContains;
    private final String label;
    private final String freeText;         // substring match across headers + rawPgn
    private final Boolean onlyValid;       // null = don't filter on validity

    private SearchQuery(Builder b) {
        this.playerContains = b.playerContains;
        this.resultEquals = b.resultEquals;
        this.dateFrom = b.dateFrom;
        this.dateTo = b.dateTo;
        this.ecoPrefix = b.ecoPrefix;
        this.openingContains = b.openingContains;
        this.label = b.label;
        this.freeText = b.freeText;
        this.onlyValid = b.onlyValid;
    }

    public String playerContains() { return playerContains; }
    public String resultEquals() { return resultEquals; }
    public String dateFrom() { return dateFrom; }
    public String dateTo() { return dateTo; }
    public String ecoPrefix() { return ecoPrefix; }
    public String openingContains() { return openingContains; }
    public String label() { return label; }
    public String freeText() { return freeText; }
    public Boolean onlyValid() { return onlyValid; }

    public static Builder builder() { return new Builder(); }

    public static final class Builder {
        private String playerContains;
        private String resultEquals;
        private String dateFrom;
        private String dateTo;
        private String ecoPrefix;
        private String openingContains;
        private String label;
        private String freeText;
        private Boolean onlyValid;

        public Builder player(String s) { this.playerContains = s; return this; }
        public Builder result(String s) { this.resultEquals = s; return this; }
        public Builder dateFrom(String s) { this.dateFrom = s; return this; }
        public Builder dateTo(String s) { this.dateTo = s; return this; }
        public Builder ecoPrefix(String s) { this.ecoPrefix = s; return this; }
        public Builder opening(String s) { this.openingContains = s; return this; }
        public Builder label(String s) { this.label = s; return this; }
        public Builder freeText(String s) { this.freeText = s; return this; }
        public Builder onlyValid(boolean b) { this.onlyValid = b; return this; }

        public SearchQuery build() { return new SearchQuery(this); }
    }
}
