package org.openchess.codex;

import org.openchess.codex.board.fallback.SimpleBoard;
import org.openchess.codex.model.GameRecord;
import org.openchess.codex.pgn.PgnParser;
import org.openchess.codex.pgn.PgnWriter;
import org.openchess.codex.replay.GameReplayService;
import org.openchess.codex.replay.ImportValidator;
import org.openchess.codex.search.GameSearchService;
import org.openchess.codex.search.SearchQuery;
import org.openchess.codex.service.GameLibraryService;
import org.openchess.codex.storage.FileBackedGameLibraryRepository;
import org.openchess.codex.storage.GameLibraryRepository;

import java.nio.file.Path;
import java.util.List;

/**
 * Runnable demo / smoke test for Module 6. Imports a tiny 3-game PGN
 * database (two clean games, one with a deliberately illegal move to show
 * validation catching it), then walks through tagging, search, replay,
 * and export. Same role as Modules 4 and 5's {@code Main}: prove the
 * wiring works end to end from a terminal.
 *
 * Build & run:
 *   mvn package
 *   java -jar target/codex.jar
 */
public final class Main {

    private static final String DEMO_PGN = """
            [Event "Demo Club Championship"]
            [Site "Springfield"]
            [Date "2026.03.01"]
            [Round "1"]
            [White "Alice Chen"]
            [Black "Bob Diaz"]
            [Result "1-0"]
            [ECO "C50"]
            [Opening "Italian Game"]
            [WhiteElo "1850"]
            [BlackElo "1790"]

            1. e4 e5 2. Nf3 Nc6 3. Bc4 Bc5 4. c3 Nf6 5. d3 d6 6. O-O O-O 1-0

            [Event "Demo Club Championship"]
            [Site "Springfield"]
            [Date "2026.03.02"]
            [Round "2"]
            [White "Carol Nunez"]
            [Black "Dave Okafor"]
            [Result "0-1"]
            [ECO "B90"]
            [Opening "Sicilian Defense, Najdorf Variation"]
            [WhiteElo "2010"]
            [BlackElo "2055"]

            1. e4 c5 2. Nf3 d6 3. d4 cxd4 4. Nxd4 Nf6 5. Nc3 a6 {the Najdorf} 6. Be2 (6. Bg5 e6 7. f4) e5 0-1

            [Event "Demo Corrupted Import"]
            [Site "?"]
            [Date "2026.03.03"]
            [Round "3"]
            [White "Erin Foster"]
            [Black "Frank Grant"]
            [Result "1-0"]

            1. e4 e5 2. Qh5 Nf6 3. Qxh8 1-0
            """;

    public static void main(String[] args) {
        PgnParser parser = new PgnParser();
        PgnWriter writer = new PgnWriter();
        GameLibraryRepository repository = new FileBackedGameLibraryRepository(Path.of("codex-library-demo.json"));
        GameSearchService searchService = new GameSearchService(repository);
        ImportValidator validator = new ImportValidator(SimpleBoard::startingPosition, SimpleBoard::fromFen);
        GameReplayService replayService = new GameReplayService(SimpleBoard::startingPosition, SimpleBoard::fromFen);
        GameLibraryService library = new GameLibraryService(parser, writer, repository, searchService, validator, replayService);

        System.out.println("=== Importing a 3-game PGN database (one deliberately corrupted) ===");
        GameLibraryService.ImportResult result = library.importPgn(DEMO_PGN, true);
        System.out.println("Imported " + result.imported().size() + " games, "
                + result.invalidCount() + " failed validation.");
        for (GameRecord g : result.imported()) {
            String status = g.isValidated() ? (g.isLegal() ? "OK" : "INVALID: " + g.validationError()) : "unvalidated";
            System.out.println("  " + g + " -> " + status);
        }

        System.out.println();
        System.out.println("=== Tagging ===");
        GameRecord italian = result.imported().get(0);
        GameRecord najdorf = result.imported().get(1);
        library.addLabel(italian.id(), "favorites");
        library.addLabel(italian.id(), "club-games");
        library.addLabel(najdorf.id(), "club-games");
        library.addLabel(najdorf.id(), "sicilian-study");
        System.out.println("Tagged '" + italian.white() + " vs " + italian.black() + "' with: " + italian.labels());
        System.out.println("Tagged '" + najdorf.white() + " vs " + najdorf.black() + "' with: " + najdorf.labels());

        System.out.println();
        System.out.println("=== Search ===");
        System.out.println("By label 'club-games': " + names(library.search(SearchQuery.builder().label("club-games").build())));
        System.out.println("By ECO prefix 'B9' (Najdorf range): " + names(library.search(SearchQuery.builder().ecoPrefix("B9").build())));
        System.out.println("By player 'Carol': " + names(library.search(SearchQuery.builder().player("Carol").build())));
        System.out.println("Only legal games: " + names(library.search(SearchQuery.builder().onlyValid(true).build())));

        System.out.println();
        System.out.println("=== Replay ===");
        System.out.println("Italian game, FEN after move 3 (ply 6): " + library.fenAtPly(italian.id(), 6));
        System.out.println("Full replay of the Italian game:");
        for (GameReplayService.ReplayStep step : library.replay(italian.id())) {
            System.out.println("  ply " + step.ply() + ": " + step.san() + "  -> " + step.fen());
        }

        System.out.println();
        System.out.println("=== Export ===");
        System.out.println("-- Lossless export of the Sicilian game (original text, comments/variations intact) --");
        System.out.println(library.exportGame(najdorf.id(), false, false));
        System.out.println("-- Canonical export of the same game (mainline only, labels embedded) --");
        System.out.println(library.exportGame(najdorf.id(), true, true));
        System.out.println("-- Export everything tagged 'club-games' as one PGN database file --");
        System.out.println(library.exportByLabel("club-games", false, false));

        System.out.println("(Library persisted to codex-library-demo.json — rerun this program and the labels/games are still there.)");
    }

    private static List<String> names(List<GameRecord> games) {
        return games.stream().map(g -> g.white() + " vs " + g.black()).toList();
    }
}
