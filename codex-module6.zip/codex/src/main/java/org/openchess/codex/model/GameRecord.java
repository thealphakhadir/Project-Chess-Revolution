package org.openchess.codex.model;

import java.time.Instant;
import java.util.*;

/**
 * One game in the library. Deliberately keeps two representations side by
 * side rather than one "clever" one:
 *
 *   - {@code rawPgn}: the original, untouched PGN text for this game —
 *     guarantees lossless export (comments, variations, NAGs, exact
 *     formatting) even though nothing else here parses those.
 *   - {@code headers} + {@code mainlineSan}: a flattened, structured view
 *     (tag pairs as a map, mainline moves as a plain SAN list with
 *     comments/variations/NAGs stripped) — used for search, tagging, and
 *     replay.
 *
 * {@code labels} are the user's own organization (favorites, "vs 1.e4",
 * a tournament name...) — distinct from PGN's own tag pairs, and mutable
 * after import.
 */
public final class GameRecord {

    private final String id;
    private final Map<String, String> headers; // insertion-ordered, as parsed from [Tag "Value"] pairs
    private final List<String> mainlineSan;
    private final String rawPgn;
    private final Set<String> labels = new LinkedHashSet<>();
    private final Instant importedAt;
    private boolean validated;
    private String validationError; // null if valid or not yet validated

    public GameRecord(String id, Map<String, String> headers, List<String> mainlineSan, String rawPgn, Instant importedAt) {
        this.id = id;
        this.headers = new LinkedHashMap<>(headers);
        this.mainlineSan = List.copyOf(mainlineSan);
        this.rawPgn = rawPgn;
        this.importedAt = importedAt;
    }

    public String id() { return id; }
    public Map<String, String> headers() { return Collections.unmodifiableMap(headers); }
    public String header(String tag) { return headers.get(tag); }
    public List<String> mainlineSan() { return mainlineSan; }
    public String rawPgn() { return rawPgn; }
    public Instant importedAt() { return importedAt; }
    public Set<String> labels() { return labels; }
    public void addLabel(String label) { labels.add(label); }
    public void removeLabel(String label) { labels.remove(label); }

    public boolean isValidated() { return validated; }
    public String validationError() { return validationError; }
    public void markValidated(String error) { this.validated = true; this.validationError = error; }
    public boolean isLegal() { return validated && validationError == null; }

    // Convenience accessors over the Seven Tag Roster + common extras — all null-safe.
    public String event() { return headers.get("Event"); }
    public String site() { return headers.get("Site"); }
    public String date() { return headers.get("Date"); }
    public String round() { return headers.get("Round"); }
    public String white() { return headers.get("White"); }
    public String black() { return headers.get("Black"); }
    public String result() { return headers.get("Result"); }
    public String eco() { return headers.get("ECO"); }
    public String opening() { return headers.get("Opening"); }
    public Integer whiteElo() { return parseIntOrNull(headers.get("WhiteElo")); }
    public Integer blackElo() { return parseIntOrNull(headers.get("BlackElo")); }
    public String timeControl() { return headers.get("TimeControl"); }
    /** Non-standard starting position, if the game used one (chess960, a puzzle position, etc.). */
    public String startingFen() { return headers.get("FEN"); }

    private static Integer parseIntOrNull(String s) {
        if (s == null) return null;
        try { return Integer.parseInt(s.trim()); } catch (NumberFormatException e) { return null; }
    }

    @Override
    public String toString() {
        return String.format("%s vs %s, %s (%s) [%s]", white(), black(),
                event() == null ? "?" : event(), result(), id);
    }
}
