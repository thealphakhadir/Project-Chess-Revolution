package org.openchess.codex.storage;

import org.openchess.codex.model.GameRecord;

import java.util.List;
import java.util.Optional;

public interface GameLibraryRepository {

    void save(GameRecord game);

    Optional<GameRecord> findById(String id);

    List<GameRecord> findAll();

    void delete(String id);
}
