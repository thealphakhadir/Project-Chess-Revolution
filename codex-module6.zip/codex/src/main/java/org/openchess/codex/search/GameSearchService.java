package org.openchess.codex.search;

import org.openchess.codex.model.GameRecord;
import org.openchess.codex.storage.GameLibraryRepository;

import java.util.List;
import java.util.Locale;

/**
 * In-memory filtering over the whole library — appropriate for a personal
 * collection (hundreds to low thousands of games). A library sized for a
 * whole site's game history would want an indexed/DB-backed search
 * instead; swap this class out rather than the {@link GameLibraryRepository}
 * seam if that day comes, since the query shape ({@link SearchQuery}) can
 * stay the same either way.
 */
public final class GameSearchService {

    private final GameLibraryRepository repository;

    public GameSearchService(GameLibraryRepository repository) {
        this.repository = repository;
    }

    public List<GameRecord> search(SearchQuery query) {
        return repository.findAll().stream().filter(g -> matches(g, query)).toList();
    }

    private boolean matches(GameRecord g, SearchQuery q) {
        if (q.playerContains() != null) {
            String needle = q.playerContains().toLowerCase(Locale.ROOT);
            boolean whiteMatch = g.white() != null && g.white().toLowerCase(Locale.ROOT).contains(needle);
            boolean blackMatch = g.black() != null && g.black().toLowerCase(Locale.ROOT).contains(needle);
            if (!whiteMatch && !blackMatch) return false;
        }
        if (q.resultEquals() != null && !q.resultEquals().equals(g.result())) return false;
        if (q.dateFrom() != null && (g.date() == null || g.date().compareTo(q.dateFrom()) < 0)) return false;
        if (q.dateTo() != null && (g.date() == null || g.date().compareTo(q.dateTo()) > 0)) return false;
        if (q.ecoPrefix() != null && (g.eco() == null || !g.eco().startsWith(q.ecoPrefix()))) return false;
        if (q.openingContains() != null) {
            String needle = q.openingContains().toLowerCase(Locale.ROOT);
            if (g.opening() == null || !g.opening().toLowerCase(Locale.ROOT).contains(needle)) return false;
        }
        if (q.label() != null && !g.labels().contains(q.label())) return false;
        if (q.onlyValid() != null && q.onlyValid() && !g.isLegal()) return false;
        if (q.freeText() != null) {
            String needle = q.freeText().toLowerCase(Locale.ROOT);
            boolean inHeaders = g.headers().values().stream().anyMatch(v -> v.toLowerCase(Locale.ROOT).contains(needle));
            boolean inRaw = g.rawPgn() != null && g.rawPgn().toLowerCase(Locale.ROOT).contains(needle);
            if (!inHeaders && !inRaw) return false;
        }
        return true;
    }
}
