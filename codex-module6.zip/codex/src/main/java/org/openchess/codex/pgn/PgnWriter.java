package org.openchess.codex.pgn;

import org.openchess.codex.model.GameRecord;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Exports {@link GameRecord}s back to PGN text. {@link #write} is
 * lossless (returns the original rawPgn untouched — comments, variations,
 * exact formatting all survive a round trip). {@link #writeCanonical}
 * regenerates a clean PGN from headers + mainline only (no comments/
 * variations), useful for a sanitized export. Either can optionally embed
 * this library's own labels as a custom {@code [Labels "..."]} tag pair —
 * that's Codex's own convention, not part of the PGN standard, so strip it
 * on import elsewhere if it would confuse another tool.
 */
public final class PgnWriter {

    private static final Pattern LAST_HEADER_LINE = Pattern.compile("(\\[\\w+\\s+\"[^\"]*\"\\]\\s*)(?!.*\\[\\w+\\s+\"[^\"]*\"\\])",
            Pattern.DOTALL);

    private static final List<String> SEVEN_TAG_ROSTER =
            List.of("Event", "Site", "Date", "Round", "White", "Black", "Result");

    /** Exact original text — the lossless path. Ignores labels unless {@code embedLabels} is true. */
    public String write(GameRecord game, boolean embedLabels) {
        if (!embedLabels || game.labels().isEmpty()) return game.rawPgn();
        return insertLabelsTag(game.rawPgn(), game.labels());
    }

    private String insertLabelsTag(String rawPgn, java.util.Set<String> labels) {
        String labelsTag = "[Labels \"" + String.join(",", labels) + "\"]\n";
        Matcher m = LAST_HEADER_LINE.matcher(rawPgn);
        if (m.find()) {
            return rawPgn.substring(0, m.end()) + labelsTag + rawPgn.substring(m.end());
        }
        return labelsTag + rawPgn; // no existing header block found — just prepend
    }

    /** Regenerates PGN from headers + mainline SAN only — no comments, no variations, no NAGs. */
    public String writeCanonical(GameRecord game, boolean embedLabels) {
        StringBuilder sb = new StringBuilder();

        Map<String, String> headers = new LinkedHashMap<>();
        for (String tag : SEVEN_TAG_ROSTER) {
            headers.put(tag, game.header(tag) != null ? game.header(tag) : "?");
        }
        for (Map.Entry<String, String> e : game.headers().entrySet()) {
            headers.putIfAbsent(e.getKey(), e.getValue());
        }
        if (embedLabels && !game.labels().isEmpty()) {
            headers.put("Labels", String.join(",", game.labels()));
        }
        for (Map.Entry<String, String> e : headers.entrySet()) {
            sb.append('[').append(e.getKey()).append(" \"").append(escapeTagValue(e.getValue())).append("\"]\n");
        }
        sb.append('\n');

        int col = 0;
        List<String> moves = game.mainlineSan();
        for (int i = 0; i < moves.size(); i++) {
            String token = (i % 2 == 0) ? ((i / 2) + 1) + ". " + moves.get(i) : moves.get(i);
            if (col + token.length() + 1 > 80) { sb.append('\n'); col = 0; }
            sb.append(token).append(' ');
            col += token.length() + 1;
        }
        String result = game.result() != null ? game.result() : "*";
        sb.append(result).append('\n');
        return sb.toString();
    }

    private String escapeTagValue(String value) {
        return value.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    /** Standard PGN database format: games separated by a blank line. */
    public String writeDatabase(List<GameRecord> games, boolean canonical, boolean embedLabels) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < games.size(); i++) {
            GameRecord g = games.get(i);
            sb.append(canonical ? writeCanonical(g, embedLabels) : write(g, embedLabels));
            if (i < games.size() - 1) sb.append("\n\n");
        }
        return sb.toString();
    }
}
