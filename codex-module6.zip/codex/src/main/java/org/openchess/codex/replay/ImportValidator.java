package org.openchess.codex.replay;

import org.openchess.codex.board.BoardAdapter;
import org.openchess.codex.board.Move;
import org.openchess.codex.model.GameRecord;

import java.util.function.Function;
import java.util.function.Supplier;

/**
 * Replays a {@link GameRecord}'s mainline through {@link BoardAdapter} to
 * confirm every move is legal — catches corrupted files, OCR'd game
 * scores with a wrong move, hand-typed PGNs with a typo, etc. Not run
 * automatically on import (parsing and validating are separate concerns);
 * {@code service.GameLibraryService} calls this explicitly so a caller can
 * choose to import first and validate later, or skip validation for a
 * trusted bulk import.
 */
public final class ImportValidator {

    private final Supplier<BoardAdapter> startingPositionFactory;
    private final Function<String, BoardAdapter> fenParser;

    public ImportValidator(Supplier<BoardAdapter> startingPositionFactory, Function<String, BoardAdapter> fenParser) {
        this.startingPositionFactory = startingPositionFactory;
        this.fenParser = fenParser;
    }

    public void validate(GameRecord game) {
        try {
            BoardAdapter board = game.startingFen() != null
                    ? fenParser.apply(game.startingFen())
                    : startingPositionFactory.get();
            for (String san : game.mainlineSan()) {
                Move move = board.findMoveBySan(san);
                board = board.playMove(move);
            }
            game.markValidated(null);
        } catch (RuntimeException e) {
            game.markValidated("Illegal or unparseable move in mainline: " + e.getMessage());
        }
    }
}
