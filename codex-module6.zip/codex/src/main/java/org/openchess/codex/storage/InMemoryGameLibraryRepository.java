package org.openchess.codex.storage;

import org.openchess.codex.model.GameRecord;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

public final class InMemoryGameLibraryRepository implements GameLibraryRepository {

    private final Map<String, GameRecord> store = new ConcurrentHashMap<>();

    @Override
    public void save(GameRecord game) { store.put(game.id(), game); }

    @Override
    public Optional<GameRecord> findById(String id) { return Optional.ofNullable(store.get(id)); }

    @Override
    public List<GameRecord> findAll() { return new ArrayList<>(store.values()); }

    @Override
    public void delete(String id) { store.remove(id); }
}
