package org.openchess.codex.replay;

import org.openchess.codex.board.BoardAdapter;
import org.openchess.codex.board.Move;
import org.openchess.codex.model.GameRecord;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;
import java.util.function.Supplier;

/** Turns a stored game's SAN mainline into actual positions, for a UI to step through or jump into. */
public final class GameReplayService {

    public record ReplayStep(int ply, String san, String fen) {}

    private final Supplier<BoardAdapter> startingPositionFactory;
    private final Function<String, BoardAdapter> fenParser;

    public GameReplayService(Supplier<BoardAdapter> startingPositionFactory, Function<String, BoardAdapter> fenParser) {
        this.startingPositionFactory = startingPositionFactory;
        this.fenParser = fenParser;
    }

    /** Every move of the game, each paired with the FEN reached right after it. */
    public List<ReplayStep> replay(GameRecord game) {
        BoardAdapter board = rootPosition(game);
        List<ReplayStep> steps = new ArrayList<>();
        int ply = 0;
        for (String san : game.mainlineSan()) {
            Move move = board.findMoveBySan(san);
            board = board.playMove(move);
            ply++;
            steps.add(new ReplayStep(ply, move.san(), board.toFen()));
        }
        return steps;
    }

    /** The FEN after exactly {@code targetPly} half-moves (0 = starting position). */
    public String fenAtPly(GameRecord game, int targetPly) {
        if (targetPly == 0) return rootPosition(game).toFen();
        BoardAdapter board = rootPosition(game);
        int ply = 0;
        for (String san : game.mainlineSan()) {
            board = board.playMove(board.findMoveBySan(san));
            ply++;
            if (ply == targetPly) return board.toFen();
        }
        throw new IllegalArgumentException("Game only has " + ply + " plies; requested ply " + targetPly);
    }

    private BoardAdapter rootPosition(GameRecord game) {
        return game.startingFen() != null ? fenParser.apply(game.startingFen()) : startingPositionFactory.get();
    }
}
