package org.openchess.codex.pgn;

import org.openchess.codex.model.GameRecord;

import java.time.Instant;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Parses standard PGN text — one game or a whole multi-game database file
 * — into {@link GameRecord}s. Handles the Seven Tag Roster plus any extra
 * tag pairs, {comments}, (variations — stripped from the mainline SAN list
 * but the original text is preserved verbatim in each record's rawPgn),
 * $NAGs, and move-number tokens in either "12." or "12..." form. Does not
 * itself validate legality — see {@code replay.ImportValidator} for that.
 */
public final class PgnParser {

    private static final Pattern HEADER = Pattern.compile("\\[(\\w+)\\s+\"([^\"]*)\"\\]");
    private static final Pattern COMMENT = Pattern.compile("\\{[^}]*\\}", Pattern.DOTALL);
    private static final Pattern NAG = Pattern.compile("\\$\\d+");
    private static final Pattern MOVE_NUMBER_TOKEN = Pattern.compile("^\\d+\\.(\\.\\.)?$");
    private static final Pattern RESULT_TOKEN = Pattern.compile("^(1-0|0-1|1/2-1/2|\\*)$");

    /** Parses a whole file's worth of PGN text — any number of games, back to back. */
    public List<GameRecord> parseDatabase(String content) {
        List<GameRecord> out = new ArrayList<>();
        for (String gameText : splitGames(content)) {
            if (gameText.isBlank()) continue;
            out.add(parseSingleGame(gameText));
        }
        return out;
    }

    /** Parses exactly one game's PGN text (headers + movetext). */
    public GameRecord parseSingleGame(String gameText) {
        String trimmed = gameText.strip();
        Map<String, String> headers = new LinkedHashMap<>();
        Matcher hm = HEADER.matcher(trimmed);
        int movetextStart = 0;
        while (hm.find()) {
            headers.put(hm.group(1), hm.group(2));
            movetextStart = hm.end();
        }

        String movetext = trimmed.substring(movetextStart);
        List<String> mainline = extractMainlineSan(movetext);

        String id = UUID.randomUUID().toString();
        return new GameRecord(id, headers, mainline, trimmed, Instant.now());
    }

    private List<String> extractMainlineSan(String movetext) {
        String cleaned = COMMENT.matcher(movetext).replaceAll(" ");
        cleaned = stripVariations(cleaned);
        cleaned = NAG.matcher(cleaned).replaceAll(" ");

        List<String> moves = new ArrayList<>();
        for (String token : cleaned.trim().split("\\s+")) {
            if (token.isBlank()) continue;
            if (MOVE_NUMBER_TOKEN.matcher(token).matches()) continue;
            if (RESULT_TOKEN.matcher(token).matches()) break;
            String san = token.replaceFirst("^\\d+\\.(\\.\\.)?", "");
            san = san.replaceAll("[!?]+$", ""); // strip trailing annotation glyphs like "!!" or "?!"
            if (san.isBlank()) continue;
            moves.add(san);
        }
        return moves;
    }

    private String stripVariations(String movetext) {
        StringBuilder out = new StringBuilder();
        int depth = 0;
        for (char c : movetext.toCharArray()) {
            if (c == '(') { depth++; continue; }
            if (c == ')') { if (depth > 0) depth--; continue; }
            if (depth == 0) out.append(c);
        }
        return out.toString();
    }

    private List<String> splitGames(String content) {
        List<String> games = new ArrayList<>();
        Matcher m = Pattern.compile("(?=\\[Event )").matcher(content);
        List<Integer> starts = new ArrayList<>();
        while (m.find()) starts.add(m.start());
        if (starts.isEmpty()) {
            if (!content.isBlank()) games.add(content);
            return games;
        }
        for (int i = 0; i < starts.size(); i++) {
            int from = starts.get(i);
            int to = (i + 1 < starts.size()) ? starts.get(i + 1) : content.length();
            games.add(content.substring(from, to));
        }
        return games;
    }
}
