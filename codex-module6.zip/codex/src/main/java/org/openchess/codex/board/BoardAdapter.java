package org.openchess.codex.board;

import org.openchess.codex.model.Color;
import java.util.List;

/**
 * Same seam pattern as Module 4's opening explorer: this module doesn't
 * own chess rules, it just needs SOME way to (a) validate that an imported
 * PGN's moves are legal and (b) compute the FEN at any ply for replay. If
 * the project's real board/move-generator (Module 2) already implements
 * something like this, wrap it instead of using {@code fallback.SimpleBoard}.
 * Everything above the board layer here (pgn, replay, search, service)
 * only talks to this interface and {@link Move}, never to the fallback
 * implementation directly.
 */
public interface BoardAdapter {

    Color sideToMove();

    List<Move> legalMoves();

    BoardAdapter playMove(Move move);

    Move findMoveBySan(String san);

    String toFen();

    boolean isInCheck(Color side);

    boolean isCheckmate();

    boolean isStalemate();
}
