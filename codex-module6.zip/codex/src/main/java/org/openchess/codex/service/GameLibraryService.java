package org.openchess.codex.service;

import org.openchess.codex.model.GameRecord;
import org.openchess.codex.pgn.PgnParser;
import org.openchess.codex.pgn.PgnWriter;
import org.openchess.codex.replay.GameReplayService;
import org.openchess.codex.replay.ImportValidator;
import org.openchess.codex.search.GameSearchService;
import org.openchess.codex.search.SearchQuery;
import org.openchess.codex.storage.GameLibraryRepository;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

/**
 * MODULE 6 — Codex (PGN library).
 *
 * Top-level entry point: import PGN text, search/tag the resulting
 * library, replay a stored game move by move, export back out. This is
 * the class the web/Android UI should talk to — same pattern as Module
 * 4's OpeningExplorerService and Module 5's VantageService.
 */
public final class GameLibraryService {

    public record ImportResult(List<GameRecord> imported, int invalidCount) {}

    private final PgnParser parser;
    private final PgnWriter writer;
    private final GameLibraryRepository repository;
    private final GameSearchService search;
    private final ImportValidator validator;
    private final GameReplayService replay;

    public GameLibraryService(PgnParser parser, PgnWriter writer, GameLibraryRepository repository,
                               GameSearchService search, ImportValidator validator, GameReplayService replay) {
        this.parser = parser;
        this.writer = writer;
        this.repository = repository;
        this.search = search;
        this.validator = validator;
        this.replay = replay;
    }

    /** Parses (and optionally validates) any number of games from PGN text, saving each to the library. */
    public ImportResult importPgn(String pgnText, boolean validateOnImport) {
        List<GameRecord> parsed = parser.parseDatabase(pgnText);
        int invalidCount = 0;
        for (GameRecord game : parsed) {
            if (validateOnImport) {
                validator.validate(game);
                if (!game.isLegal()) invalidCount++;
            }
            repository.save(game);
        }
        return new ImportResult(parsed, invalidCount);
    }

    public Optional<GameRecord> get(String gameId) { return repository.findById(gameId); }

    public List<GameRecord> all() { return repository.findAll(); }

    public List<GameRecord> search(SearchQuery query) { return search.search(query); }

    public void addLabel(String gameId, String label) {
        GameRecord game = require(gameId);
        game.addLabel(label);
        repository.save(game);
    }

    public void removeLabel(String gameId, String label) {
        GameRecord game = require(gameId);
        game.removeLabel(label);
        repository.save(game);
    }

    public void delete(String gameId) { repository.delete(gameId); }

    /** Explicitly re-run legality validation for a game already in the library (e.g. after a rules-engine upgrade). */
    public void revalidate(String gameId) {
        GameRecord game = require(gameId);
        validator.validate(game);
        repository.save(game);
    }

    public List<GameReplayService.ReplayStep> replay(String gameId) { return replay.replay(require(gameId)); }

    public String fenAtPly(String gameId, int ply) { return replay.fenAtPly(require(gameId), ply); }

    /** {@code canonical=false} is lossless (exact original text); {@code true} regenerates a clean, comment-free PGN. */
    public String exportGame(String gameId, boolean canonical, boolean embedLabels) {
        GameRecord game = require(gameId);
        return canonical ? writer.writeCanonical(game, embedLabels) : writer.write(game, embedLabels);
    }

    public String exportByLabel(String label, boolean canonical, boolean embedLabels) {
        List<GameRecord> games = search.search(SearchQuery.builder().label(label).build());
        return writer.writeDatabase(games, canonical, embedLabels);
    }

    public String exportAll(boolean canonical, boolean embedLabels) {
        return writer.writeDatabase(repository.findAll(), canonical, embedLabels);
    }

    private GameRecord require(String gameId) {
        return repository.findById(gameId)
                .orElseThrow(() -> new NoSuchElementException("No game with id " + gameId));
    }
}
