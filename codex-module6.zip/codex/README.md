# Module 6 — Codex (PGN Library)

"Codex" is a working name — rename freely, same as every module name in
this project started as a placeholder.

Self-contained, like every module in this project: zero external Maven
dependencies, no dependency on any other module's jar. The board/rules
layer (`board/`) is a ported copy of Module 4's already-reviewed reference
implementation, not a shared dependency — see "Reused code" below.

## What it does

Import PGN (one game or a whole database file), search and tag what you
imported, replay any stored game move by move, export back out — losslessly
or as a clean regenerated file.

| Concern | Class |
|---|---|
| Parse PGN text → structured games | `pgn.PgnParser` |
| Write games back to PGN | `pgn.PgnWriter` |
| Validate imported moves are actually legal | `replay.ImportValidator` |
| Compute the position at any point in a game | `replay.GameReplayService` |
| Store the library | `storage.GameLibraryRepository` (+ in-memory and file-backed implementations) |
| Search by player/date/ECO/result/label/free text | `search.GameSearchService` |
| Everything above, as one API | `service.GameLibraryService` |

`service.GameLibraryService` is the only class the rest of the app should
talk to — same pattern as every other module's top-level facade
(`OpeningExplorerService`, `VantageService`).

## The two-representation design

Every `GameRecord` keeps **both**:

- `rawPgn` — the exact original text, untouched. Exporting this back out
  (`exportGame(id, canonical=false, ...)`) is byte-for-byte lossless:
  comments, variations, annotation glyphs, whatever formatting the source
  file had, all survive a round trip.
- `headers` + `mainlineSan` — a flattened, structured view (tag pairs as a
  map, moves as a plain SAN list with comments/variations/NAGs stripped) —
  used for search, tagging, and replay.

This means search and replay never have to re-parse comments or navigate
variation trees, while export never has to reconstruct formatting it threw
away. `exportGame(id, canonical=true, ...)` regenerates a clean PGN from
just the structured view when you want a sanitized copy instead.

## Validation is explicit, not automatic

Importing a game (`importPgn(text, validateOnImport)`) does NOT silently
skip or reject anything — even a game with a garbled or illegal move gets
imported and stored, just flagged `isLegal() == false` with a
`validationError()` explaining why (see `Main`'s demo: one of the three
sample games has a queen move that's blocked by its own pawn — looks like
valid SAN syntax, isn't actually legal in that position, and the validator
catches it by actually replaying the game through real chess rules rather
than just checking the text format). This matters for a PGN library
specifically: real-world PGN files — hand-transcribed scoresheets, OCR'd
game scores, files from less careful tools — do contain corrupted games,
and silently dropping them (or silently importing something wrong without
telling you) are both worse than flagging it and letting you decide.

## Build & run

```bash
mvn package
java -jar target/codex.jar
```

Or plain `javac`/`java`, no Maven needed:

```bash
find src/main/java -name "*.java" > sources.txt
javac -d out @sources.txt
java -cp out org.openchess.codex.Main
```

`Main` imports a 3-game demo PGN (two clean games, one with the
deliberately-illegal move described above), then walks through tagging,
search by several criteria, full move-by-move replay with FEN at each ply,
and both export modes. It persists to `codex-library-demo.json` in the
working directory — run it twice and the second run starts with the first
run's library already loaded.

## Reused code

`board/` (BoardAdapter, Move, PieceType, `fallback.SimpleBoard`) is the
same reference chess-rules implementation from Module 4's opening
explorer, copied rather than shared as a jar — this project's modules
don't depend on each other's jars, matching Modules 4 and 5. If Module 4's
copy ever gets replaced by the project's real board engine (Module 2),
replace this one the same way; they're meant to move together even though
they're not technically linked.

Codex only needs this for two things: confirming an imported game's moves
are legal, and computing the FEN at any ply for replay. It does not need
(and doesn't have) a transposition table or move-tree navigation the way
Module 4 does — a PGN library plays back ONE game linearly, it doesn't
explore a tree of possible continuations.

## What's a reasonable scope decision, not a limitation to "fix" later

- **In-memory search** (`search.GameSearchService`) scans the whole
  library per query. Fine for a personal collection; a library sized for
  a whole site's game history would want indexed/DB-backed search instead
  — swap `GameLibraryRepository`'s implementation, the `SearchQuery` shape
  can stay the same.
- **No named folders/collections** — `labels` (a flexible many-to-many tag
  set) cover that need without a separate rigid hierarchy. "Show me my
  Sicilian folder" is just `search(SearchQuery.builder().label("sicilian").build())`.
- **Variations aren't parsed into a tree** — they're stripped from
  `mainlineSan` (though preserved verbatim in `rawPgn`). Building a real
  variation tree (for a study/annotation tool, say) is a genuinely
  different, bigger feature — a natural extension point if you want it,
  not something this module quietly does half of today.

## No compiler in this sandbox

Same situation as every module before this one: no JDK, no network to get
one. I did a full structural pass — this time with a proper single-pass
lexical scanner (respecting Java's actual string/char-literal escaping
rules) rather than the cruder regex pipeline used earlier, since that
regex approach had already produced a couple of false alarms on char
literals containing quote characters in this project. All 18 files
balance cleanly under the correct scanner, every internal import resolves
to a real file, and every constructor call in `Main.java` was traced by
hand against its declared signature. That's real verification, but it
isn't `javac`. Run `mvn package` first and treat any error it finds as the
priority fix.
